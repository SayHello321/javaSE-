import java.io.IOException;
import java.util.Date;
import java.util.Iterator;

import accessPermission.Math.uart;
import accessPermission.System.print.printable;

public class demo2 extends demo1{
	private static int changevalue(double value) {
		// TODO Auto-generated method stub
 return (int)value>>>1;
	}
	
@Override
	void eat() {
		System.out.println("apple");
	}

public static void main(String[] args) throws Exception {
long l1 =System.currentTimeMillis();
for (int i = 0; i < 10000; i++) {
//	System.out.println(i);
}
Date d =new Date();

long l2 =System.currentTimeMillis();
//System.out.println("程序运行时间："+(l2-l1)+"ms");
//Runtime.getRuntime().exec(System.getenv("windir")+"\\system32\\shutdown.exe -r -t 30");
}
	

}
