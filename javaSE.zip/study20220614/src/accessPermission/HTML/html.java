package accessPermission.HTML;
/*1.软件架构：
 *  ① C/S:Client service
 *  ② B/S:Browser service
 *    (1)静态资源：使用静态网页技术开发的资源
 *       所有用户访问的结果是一样的，如：图片、文本、音频、视频、HTML、CSS、JavaScript
 *       HTML:展示页面
 *       CSS:美化、布局网络页面
 *       JavaScript:控制页面元素，让页面有一些动态效果
 *    (2)动态资源：使用动态网络技术开发发布的资源
 *       所有用户访问的资源可能不一样，如：jsp、servlet、php、asp   
 *       如果用户请求动态资源，服务器会将其转换成静态资源，再发给浏览器
 * 2.html：后缀为 .html 或 .htm
 *    (1)标签：
 *      围堵标签：又开始和结束标签：，如<html>和</html>
 *      自闭和标签，如<br/>
 *    (2)标签可以嵌套
 *    (3)在开始变迁中可以定义属性，属性由键值对组成，值用引号（单引/双引）引起来
 *    (5)html不区分大小写
 * 3.标签学习 
 *    (1)文件标签：最基本的标签
 *        <html> 根标签
 *        <head> 头标签，定义html属性，引入外部资源
 *        <title>标题标签
 *        <body>体标签
 *        <!DOCTYPE html>html5中定义的html文档
 *    (2)文本标签：
 *        <!-- 注释内容 -->
 *        <h1>to<h6>  标题标签，h1到h6字号逐渐减小
 *        <p>         段落标签
 *        <br>        自闭合，换行
 *        <hr>        显示一条水平线，
 *              属性： 
 *                     color 颜色
 *                     align(center/left/right)
 *                     size:高度
 *                     width:宽度
 *                         wide="30",数值的单位默认式px(像素)
 *                         数值%：相对父元素的百分比
 *                     noshade：颜色纯色
 *        <b>         字体加粗
 *        <i>         字体斜体
 *        <font>      字体标签，
 *             属性：
 *                  color="颜色"  
 *                        red/green/blue
 *                        rgb(value1,value2,value3),value(0~255),比如rgb(0,100,0)表示浅绿色，RGB颜色对照表，多数浏览器不支持
 *                        #value1value2value3 ,00~FF 如color="#00FF00"
 *                  size="5" 文本的尺寸
 *                  face="宋体" 字体
 *                 
 *       <center>     居中显示
 *       特殊字符
 *       
 *    (3)图片标签：
 *    (4)列表标签：
 *    (5)链接标签
 *    (6)表格标签
 *    */
public class html {

}
