package accessPermission.E_Generic;
/*定义含有泛型的方法： 泛型定义在修饰符和返回值类型之间
 * 修饰符<泛型> 返回值类型 方法名（参数列表（使用泛型））{ 方法体}
 * 传递什么参数，泛型就是什么数据类型*/
public class E_method {
    
	public <fanxing> void method1(fanxing fan) {
		System.out.println(fan);
	}
	
	//含有泛型的静态方法
	public static<F>void method2(F f){
		System.out.println("静态泛型数据："+f);
	}
	
	
	public static void main(String[] args) {
		E_method e =new E_method();
		e.method1(1);
		e.method1("hello!");
		e.method1(true);
		
		//静态可以用 类名.方法名调用
		E_method.method2(1011);
	}
}
