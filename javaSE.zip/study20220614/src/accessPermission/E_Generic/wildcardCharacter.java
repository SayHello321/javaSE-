package accessPermission.E_Generic;

import java.util.ArrayList;
import java.util.Iterator;

/*1.泛型的通配符：
 * ？代表任意的数据类型
 *2.使用方式：泛型没有继承概念，不能用Object作为泛型数据类型，Object只能做接受对象使用
 *   不能创建对象使用
 *   只能作为方法的参数使用
 * 3.泛型的上下限
 *    上限：<？ extends E>   //代表泛型只能是子类或本身
 *    下限：<？ super   E>     //代表泛型的父类或者本身
 *   Integer extends number extends Object */
public class wildcardCharacter {

	//当不知道ArrayList使用的什么数据类型，可以用通配符？接受数据类型
	public static void printAnyArrayList(ArrayList<?> list) {
		Iterator<?>it=list.iterator();
		while(it.hasNext()) {
			Object obj =it.next();
			System.out.println("anyType:"+obj);
		}
	} 
	
	public static void main(String[] args) {
		ArrayList<String>list1=new ArrayList<>();
		ArrayList<Integer>list2=new ArrayList<>();
		//ArrayList<?>list2=new ArrayList<>();//错误，只能在传递时用？，定义时候不能用
		list1.add("a");
		list1.add("b");
		list2.add(11);
		list2.add(12);
		System.out.println(list1);
		System.out.println(list2);
		printAnyArrayList(list1);
		printAnyArrayList(list2);
	}
	
}
