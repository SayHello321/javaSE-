package accessPermission.E_Generic;
/* 泛型：未知的类型，创建集合对象的时候会将数据类型当作参数传递给泛型e
 * E e  element 元素；
 *T t  type    类型；
 * */
public class E_class<E> {
private E name;
	
public E_class() {
	super();
	// TODO Auto-generated constructor stub
}

public E_class(E name) {
	super();
	this.name = name;
}

public E getName() {
	return name;
}

public void setName(E name) {
	this.name = name;
}

public static void main(String[] args) {
	
	//不使用泛型，默认为object类
	E_class e1 =new E_class();
	e1.setName("object类，这里只能写字符串");
	Object obj=e1.getName();
	System.out.println("<obj>:"+obj);
	
	//创建泛型类对象，泛型使用Integer类
	E_class<Integer> e2 =new E_class<>();
	e2.setName(15);
	Integer Int =e2.getName();
	System.out.println("<Integer>:"+Int);
	
	
	//创建泛型类对象,使用String类
	E_class<String> e3 =new E_class<>();
	e3.setName("李明");
	String s =e3.getName();
	System.out.println("<String>:"+s);
}
}
