package accessPermission.E_Generic.E_Interface;
/*泛型接口使用方式一： 定义接口实现类，实现接口，指定接口的泛型
 * public interface Iterator<E>{
 *    E next();
 *   }
 *   Scanner 实现了Iterator接口 ，并重写next()方法默认就是String
 *  Public final class Scanner implements Iterator<String>{} 
 * */
public class GenericInterfaceImp1/*这里默认<String>*/ implements GenericInterface<String>{

	@Override
	public  void method(String s) {
		System.out.println(s);
		
	}
   
	
	public static void main(String[] args) {
		
		GenericInterfaceImp1 GI1 =new GenericInterfaceImp1();
		GI1.method("ok");
		
	}
}
