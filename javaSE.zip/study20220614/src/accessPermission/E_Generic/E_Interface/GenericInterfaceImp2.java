package accessPermission.E_Generic.E_Interface;
/*泛型接口使用方式二： 接口使用什么泛型，实现类就用什么泛型，类跟着接口走
 * public interface  list <E>{
 *   boolean add(E e);
 *   E get(int index); 
 *   } 
 *   public class ArrayList <E> implements list<E>;
 * */
public class GenericInterfaceImp2<I> implements GenericInterface<I> {

	@Override
	public void method(I i) {
		System.out.println(i);
		
	}

	public static void main(String[] args) {
		GenericInterfaceImp2<String> GI2 =new GenericInterfaceImp2<>();	
		GI2.method("hello");
		GenericInterfaceImp2<Double> GI3 =new GenericInterfaceImp2<>();	
		GI3.method(3.1425926);
	}
}
