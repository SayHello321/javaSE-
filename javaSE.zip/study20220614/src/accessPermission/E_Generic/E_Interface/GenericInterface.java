package accessPermission.E_Generic.E_Interface;
/*定义含有泛型的接口*/
public interface GenericInterface <I>{
	
    public abstract void method(I i); //<I>可以隐藏

}
