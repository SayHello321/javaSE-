package accessPermission.System;

import java.util.Arrays;
import java.util.Iterator;

/*java.lang.System下方法：
 *  1.public static long CurrentTimeMillis(); 返回毫秒为单位的值
 *  2.public static void arraycopy(Object src ,int srcPos,Object dest, int destPos,int length) 
 *    将数组中指定的数据拷贝到另外一个数组
 *    src      源数组
 *    srcPos   源数组起始位
 *    dest     目标数组
 *    destPos  目标数组起始位置
 *    length   复制数组元素的数量
 *         */
public class demoSystem {
	
  private static void system1() {
	//计算程序运行的时间
  long startTime = System.currentTimeMillis();
  int i=0;
  do {	  
	  i+=1;
	  
  }while(i<1000000);
  System.out.println(i);
  long endTime = System.currentTimeMillis();
  long usedTime=(endTime-startTime);
  System.out.println("ProgramTime:"+usedTime+"ms");
}
  
  private static void system2() {
	// 数组复制
	  int[] src= {1,2,3,4,5,6};
	  int[] dest= {7,8,9,10,11,12};
      System.out.println("dest复制前："+Arrays.toString(dest));
      System.arraycopy(src, 2, dest, 2, 3);
      System.out.println("dest复制后："+Arrays.toString(dest));
}
  
 
  public static void main(String[] args) {
	  system1();
	  system2();
	  
}
  
  
}
