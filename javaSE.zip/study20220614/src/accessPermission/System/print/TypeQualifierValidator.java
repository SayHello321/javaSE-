package accessPermission.System.print;

import java.lang.annotation.Annotation;

public interface TypeQualifierValidator<A extends Annotation> {
/* give a qualifier check to see if a known specific constant 
 * value is an instance of  the set of values denoted by the qualifier
 * @ param annotation the qualifier
 * @ param value    is or not the member of the value denoted by the qualifierx
 *  */
   public @Nonnull
   
   When forConstantValue(@Nonnull A annotation, Object value);
}
