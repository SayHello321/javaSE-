package accessPermission.System.print;

public class printable {
	
	 //重写打印
	  public static void println(@Nullable Object arg) {
		  System.out.println(arg);
	  }
	  
	  public static void println() {
		  System.out.println();
	  }
	  public static void print(@Nullable Object arg) {
		  System.out.print(arg);
	  }
	  
	  
}
