package accessPermission.System.print;

public enum When {
/*S is  a  subset of T*/
	ALWAYS,
/*nothing is definative is known about the relation between S and T*/
	UNKNOWN,
/*S intersection  T is non empty and S - T is non empty*/
	MAYBE,
/*S intersection T is empty*/
	NEVER
	
}
