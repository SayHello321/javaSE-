package accessPermission.Lamda;

public interface Calculator {
 abstract int  calculate(int a ,int b);
}
