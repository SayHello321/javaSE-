package accessPermission.Lamda;

public class demoCalculate {

	private static void invokeCalculate(int a,int b,Calculator cal) {
		//调用接口中的方法进行计算
		int sum =cal.calculate(a, b);
		System.out.println("a+b="+sum);
    
	}
	public static void main(String[] args) {
		
		//1.可以使用匿名内部类
		invokeCalculate(10,20,new Calculator() {		
			@Override
			public int calculate(int a, int b) {	
				return a+b;
			}
		}
		);
		
		//2.参数有接口，可以使用Lambda表达式
		invokeCalculate(10,20,(int a,int b)->{return a+b;});	//数据类型可省略为(a,b)->{return a+b;}
		
	}
	
}
