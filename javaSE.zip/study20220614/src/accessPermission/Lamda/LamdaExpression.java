package accessPermission.Lamda;
/*1.Lambda表达式：和面向对象思想是怎么做，Lambda编程思想是做什么
 *   格式： (参数列表)->{重写方法的代码}
 *   ():接口中抽象方法的参数列表，没有就空着，有多个用逗号分开
 *   ->:传递的动作
 *   {}：重写接口对的抽象方法的方法体,里面是重写接口方法的代码
 *2.Lambda表达式使用前提：
 *   ①使用Lambda必须具有接口，且接口中有且仅有一个抽象方法，不管是内置的Runnable、Comparator还是自定义的抽象方法必须是抽象方法只有一个。
 *   ②使用Lambda必须具有上下文推断，也就是方法的参数或者局部变量为Lambda对应的接口类型，才能用Lambda作为接口实例  
 *3.Lambda省略式
 *  ①数据类型可以省略、
 *  ②如果参数只有一个数据类型和参数都可以省略
 *  ③如果{}中代码只有一行，要求{}，return,分号一起省略*/
public class LamdaExpression {
public static void main(String[] args) {
	//下面用两种方法展示Lambda与普通方法差异
	
	//1.用匿名内部类执行线程任务
	new Thread(new Runnable() {
		@Override
		public void run() {
			System.out.println(Thread.currentThread().getName()+"线程任务正在执行！");	
		}
	}).start();
	
	//2.用Lambda表达式执行线程任务
	new Thread(()->{
	
			System.out.println(Thread.currentThread().getName()+"线程任务正在执行！");
		}
	).start();
	
	//3.Lambda的省略式
	new Thread(()->System.out.println(Thread.currentThread().getName()+"线程任务正在执行！") ).start();
	
	
}
}
