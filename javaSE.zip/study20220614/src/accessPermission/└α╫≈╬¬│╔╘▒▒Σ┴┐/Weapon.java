package accessPermission.类作为成员变量;

public class Weapon {
private String code;

public Weapon() {
	
}
public Weapon(String code) {
	super();
	this.code = code;
}

public String getcode() {
	return code;
}

public void setcode(String code) {
	this.code = code;
}


}
