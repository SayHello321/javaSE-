package accessPermission.类作为成员变量;

public class demoMain {
public static void main(String[] args) {
	Weapon weapon = new Weapon("金箍棒");

	Hero hero =new Hero();
	hero.setWeapon(weapon);
	hero.setAge(25);
	hero.setName("孙悟空");
	hero.attack();
}
}
