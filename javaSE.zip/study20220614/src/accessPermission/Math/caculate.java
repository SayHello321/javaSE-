package accessPermission.Math;

import java.text.DecimalFormat;
import java.util.Random;

public class caculate {
	//可变参数
	public static void add(int a,int... args) {
		int x = a;
		for (int num : args) {
			x += num;

		}
		System.out.println("可变参数求和："+x);
	}

	public static int Add(int a, int b, int c) {
		return a + b + c;
	}

	public static boolean judge(int array1, int array2) {
		return array1 == array2;
	}

	public static void main(String[] args) {
        add(1,2,3,4);
		/* 随机获取1~n之间的随机数 */
		for (int i = 0; i < 10; i++) {
			Random sr = new Random();
			int num = sr.nextInt(5) + 1;
			System.out.println(num);
		}

		int x = 5 << 2 | 3;// (5*4+3)
		System.out.println("x计算结果：" + x);
		int sum = Add(1, 2, 3);
		int a = (int) 5L;
		double d = 113.234567;
//	int array1 =1;
//	int array2 =2;
		DecimalFormat df = new DecimalFormat("#.00");
		// df.format(d);

		System.out.println(Double.valueOf(sum));
		System.out.println(a);
		System.out.println("d保留两位小数为：" + df.format(d));
		System.out.println("布尔返回值为：" + judge(1, 1));
	}

}