package accessPermission.Math;

public class logDemo {
private static void lg() {
	double p1=Math.pow(10,2);
	double p2=Math.pow(10,1);
	double log1=Math.log10(p1);
	double log2=Math.log10(p2);
    System.out.println(p1);
    System.out.println(p2);
    System.out.println(log1);
    System.out.println(log2);
}
public static void main(String[] args) {
	lg();
}
}
