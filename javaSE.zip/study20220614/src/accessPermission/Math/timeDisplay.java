package accessPermission.Math;
import java.util.Scanner;
import java.util.Date;
import java.text.*;
public class timeDisplay {
static int n;
public static void main (String[]args) {
			
			Date date=new Date();
			System.out.println(date.toString());//显示格式
			SimpleDateFormat myformat =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			System.out.println("当前时间为："+myformat.format(date)); 
			System.out.printf("全部日期和时间信息：%tc%n",date);
		}

boolean usersel;
}
