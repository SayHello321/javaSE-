package accessPermission.Math;
public class reverseArray {
	private static int []arraya= {1,2,3};
	public static void main(String[]args) {
	int[]arrayx = reverseArray(arraya);
	new FLASH_method().printArray(arrayx);	
	
	}
	
	public static int[] reverseArray(int []array) {	
		for(int min=0,max=array.length-1;min<=max;min++,max--) {
			
			int tmp=array[min];
			array[min]=array[max];
			array[max]=tmp;
		}
		return array;
	}

}
