 package accessPermission.Math;
public class FLASH_method{
static int[]arrayB=new int[3];
	  //static int size = 10000;
	  //static int[] arrayA = new int[]{1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1};
	static int[] arrayA = new int[]{1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1};
	  
	  public static double judge(int y1,int y2){
		  double boo;
		  if(y1==y2) {
			  boo=1;
		  }
		  else { boo=0;}
		  return boo;
		  }
	 
	  
	  public static boolean judge(int[]array1,int[]array2){
		  boolean bool =false;
		  for(int j=0;j<array1.length;j++){
			if(array1.length==array2.length&&array1[j]==array2[j]) {
				bool =true;
			}  
			else {
				bool =false;
			}
		  }
	  return bool;
	  }
	  public static void main(String[]args){
//	int[] myArray=seek(arrayA);	
	//arrayB
//    System.out.println(myArray[0]);
//	System.out.println(myArray[1]);
//	System.out.println(myArray[2]);
//	printArray(myArray);
	//System.out.println(0xf==15);
//	System.out.println(judge(1,3));
	int[] arrayx = new int[]{1,2,3};
	int[] arrayy = new int[]{1,2,3};
	judge(arrayx,arrayy);
	
	   }
	  public static void printArray(int[] array) {
		
		  for(int j=0;j<array.length;j++){
			   if(j==0){
				   System.out.print("printArray： ["+array[0]+",");
			   }
				else if(j==array.length-1){
					System.out.println(array[array.length-1]+"]");
				}
				else{
					System.out.print(array[j]+",");
				}
				
				}
		  
	  }
	  public static void printArray(Object[] array) {
			
		  for(int j=0;j<array.length;j++){
			   if(j==0){
				   System.out.print("printArray： ["+array[0]+",");
			   }
				else if(j==array.length-1){
					System.out.println(array[array.length-1]+"]");
				}
				else{
					System.out.print(array[j]+",");
				}
				
				}
		  
	  }
	  public static  int[] seek(int[]array){
	 
	 // arrayA = array;
	 int couter=0;
	 
	  for1:for(int i =0;i<arrayA.length;){
	  if(array[i]==0&&array[i+2]==0&&array[i+47]==1){
		  
	// for2: for(int k=0;k<arrayB.length;k++){
		  do {
	        arrayB[couter]=(array[i+7]*1+array[i+12]*2+array[i+17]*4+array[i+22]*8+array[i+27]*16+array[i+32]*32+array[i+37]*64+array[i+42]*128)&0xff;

			System.out.println("arryB["+couter+"]="+Integer.toHexString(arrayB[couter]));
			//System.out.println("arryB["+couter+"]="+arrayB[couter]);
			couter+=1;
			i+=50;}while(couter<3);
//			break;	
	         }	
	  
//	     continue;
	      
	  else {
		 i++;
	  }
	  }
	    	
		return arrayB;
	 }
	//	private static  int[]arrayB=new int[3];//51
	public int[]arrayC={114,32,52,48,48,54,48,48,49,52,13,10,91,48,120,52,48,48,54,48,48,49,52,93,32,61,32,48,120,48,48,48,48,48,56,50,49,13,10,13,10,79,75,13,10,66,111,111,116,32,62};
	
	}