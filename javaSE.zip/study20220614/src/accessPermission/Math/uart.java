package accessPermission.Math;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
import java.util.zip.DataFormatException;
import accessPermission.System.print.printable;
import javax.xml.datatype.DatatypeConfigurationException;

import accessPermission.Strings.demoString;
import accessPermission.System.print.printable;

public class uart extends printable {
	public static double value;

	public static String AsciiToBinString(String asiicInput) throws DataFormatException{

		decimalToBin dtb = new decimalToBin();
		
		String[] ASIIC = asiicInput.split("");
		int[] hex = new int[ASIIC.length];
		Vector<String> vector = new Vector<>();
		for (int i = 0; i < ASIIC.length; i++) {
			if (ASIIC[i].equals(" ")) {
				hex[i] = 0x20;
			}else if(ASIIC[i].equals("!")) {
				hex[i] = 0x21;
			}else if(ASIIC[i].equals("\"")) {
				hex[i] = 0x22;
			}else if(ASIIC[i].equals("#")) {
				hex[i] = 0x23;
			}else if(ASIIC[i].equals("$")) {
				hex[i] = 0x24;
			}else if(ASIIC[i].equals("%")) {
				hex[i] = 0x25;
			}else if(ASIIC[i].equals("&")) {
				hex[i] = 0x26;
			}else if(ASIIC[i].equals("'")) {
				hex[i] = 0x27;
			}else if(ASIIC[i].equals("(")) {
				hex[i] = 0x28;
			}else if(ASIIC[i].equals(")")) {
				hex[i] = 0x29;
			}else if(ASIIC[i].equals("*")) {
				hex[i] = 0x2A;
			}else if(ASIIC[i].equals("+")) {
				hex[i] = 0x2B;
			}else if(ASIIC[i].equals(",")) {
				hex[i] = 0x2C;
			}else if(ASIIC[i].equals("-")) {
				hex[i] = 0x2D;
			}else if(ASIIC[i].equals(".")) {
				hex[i] = 0x2E;
			}else if(ASIIC[i].equals("/")) {
				hex[i] = 0x2F;
			} else if(ASIIC[i].equals("0")) {
				hex[i] = 0x30;
			} else if (ASIIC[i].equals("1")) {
				hex[i] = 0x31;
			} else if (ASIIC[i].equals("2")) {
				hex[i] = 0x32;
			} else if (ASIIC[i].equals("3")) {
				hex[i] = 0x33;
			} else if (ASIIC[i].equals("4")) {
				hex[i] = 0x34;
			} else if (ASIIC[i].equals("5")) {
				hex[i] = 0x35;
			} else if (ASIIC[i].equals("6")) {
				hex[i] = 0x36;
			} else if (ASIIC[i].equals("7")) {
				hex[i] = 0x37;
			} else if (ASIIC[i].equals("8")) {
				hex[i] = 0x38;
			} else if (ASIIC[i].equals("9")) {
				hex[i] = 0x39;
			} else if (ASIIC[i].equals(":")) {
				hex[i] = 0X3A;
			} else if (ASIIC[i].equals(";")) {
				hex[i] = 0X3B;
			} else if (ASIIC[i].equals("<")) {
				hex[i] = 0X3C;
			} else if (ASIIC[i].equals("=")) {
				hex[i] = 0X3D;
			} else if (ASIIC[i].equals(">")) {
				hex[i] = 0X3E;
			} else if (ASIIC[i].equals("?")) {
				hex[i] = 0X3F;
			} else if (ASIIC[i].equals("@")) {
				hex[i] = 0X40;
			} else if (ASIIC[i].equals("A")) {
				hex[i] = 0X41;
			} else if (ASIIC[i].equals("B")) {
				hex[i] = 0X42;
			} else if (ASIIC[i].equals("C")) {
				hex[i] = 0X43;
			} else if (ASIIC[i].equals("D")) {
				hex[i] = 0X44;
			}else if (ASIIC[i].equals("E")) {
				hex[i] = 0X45;
			}else if (ASIIC[i].equals("F")) {
				hex[i] = 0X46;
			}else if (ASIIC[i].equals("G")) {
				hex[i] = 0X47;
			}else if (ASIIC[i].equals("H")) {
				hex[i] = 0X48;
			}else if (ASIIC[i].equals("I")) {
				hex[i] = 0X49;
			}else if (ASIIC[i].equals("J")) {
				hex[i] = 0X4A;
			}else if (ASIIC[i].equals("K")) {
				hex[i] = 0X4B;
			}else if (ASIIC[i].equals("L")) {
				hex[i] = 0X4C;
			}else if (ASIIC[i].equals("M")) {
				hex[i] = 0X4D;
			}else if (ASIIC[i].equals("N")) {
				hex[i] = 0X4E;
			}else if (ASIIC[i].equals("O")) {
				hex[i] = 0X4F;
			}else if (ASIIC[i].equals("P")) {
				hex[i] = 0X50;
			}else if (ASIIC[i].equals("Q")) {
				hex[i] = 0X51;
			}else if (ASIIC[i].equals("R")) {
				hex[i] = 0X52;
			}else if (ASIIC[i].equals("S")) {
				hex[i] = 0X53;
			}else if (ASIIC[i].equals("T")) {
				hex[i] = 0X54;
			}else if (ASIIC[i].equals("U")) {
				hex[i] = 0X55;
			}else if (ASIIC[i].equals("V")) {
				hex[i] = 0X56;
			}else if (ASIIC[i].equals("W")) {
				hex[i] = 0X57;
			}else if (ASIIC[i].equals("X")) {
				hex[i] = 0X58;
			}else if (ASIIC[i].equals("Y")) {
				hex[i] = 0X59;
			}else if (ASIIC[i].equals("Z")) {
				hex[i] = 0X5A;
			}else if (ASIIC[i].equals("[")) {
				hex[i] = 0X5B;
			}else if (ASIIC[i].equals("\\") ){
				hex[i] = 0X5C;
			}else if (ASIIC[i].equals("]")) {
				hex[i] = 0X5D;
			}else if (ASIIC[i].equals("^")) {
				hex[i] = 0X5E;
			}else if (ASIIC[i].equals("_")) {
				hex[i] = 0X5F;
			}else if (ASIIC[i].equals("`")) {
				hex[i] = 0X60;
			}else if (ASIIC[i].equals("a")) {
				hex[i] = 0X61;
			}else if (ASIIC[i].equals("b")) {
				hex[i] = 0X62;
			}else if (ASIIC[i].equals("c")) {
				hex[i] = 0X63;
			}else if (ASIIC[i].equals("d")) {
				hex[i] = 0X64;
			}else if (ASIIC[i].equals("e")) {
				hex[i] = 0X65;
			}else if (ASIIC[i].equals("f")) {
				hex[i] = 0X66;
			}else if (ASIIC[i].equals("g")) {
				hex[i] = 0X67;
			}else if (ASIIC[i].equals("h")) {
				hex[i] = 0X68;
			}else if (ASIIC[i].equals("i")) {
				hex[i] = 0X69;
			}else if (ASIIC[i].equals("j")) {
				hex[i] = 0X6A;
			}else if (ASIIC[i].equals("k")) {
				hex[i] = 0X6B;
			}else if (ASIIC[i].equals("l")) {
				hex[i] = 0X6C;
			}else if (ASIIC[i].equals("m")) {
				hex[i] = 0X6D;
			}else if (ASIIC[i].equals("n")) {
				hex[i] = 0X6E;
			}else if (ASIIC[i].equals("o")) {
				hex[i] = 0X6F;
			}else if (ASIIC[i].equals("p")) {
				hex[i] = 0X70;
			}else if (ASIIC[i].equals("q")) {
				hex[i] = 0X71;
			}else if (ASIIC[i].equals("r")) {
				hex[i] = 0X72;
			}else if (ASIIC[i].equals("s")) {
				hex[i] = 0X73;
			}else if (ASIIC[i].equals("t")) {
				hex[i] = 0X74;
			}else if (ASIIC[i].equals("u")) {
				hex[i] = 0X75;
			}else if (ASIIC[i].equals("v")) {
				hex[i] = 0X76;
			}else if (ASIIC[i].equals("w")) {
				hex[i] = 0X77;
			}else if (ASIIC[i].equals("x")) {
				hex[i] = 0X78;
			}else if (ASIIC[i].equals("y")) {
				hex[i] = 0X79;
			}else if (ASIIC[i].equals("z")) {
				hex[i] = 0X7A;
			}else if (ASIIC[i].equals("{")) {
				hex[i] = 0X7B;
			}else if (ASIIC[i].equals("|")) {
				hex[i] = 0X7C;
			}else if (ASIIC[i].equals("}")) {
				hex[i] = 0X7D;
			}else if (ASIIC[i].equals("~")) {
				hex[i] = 0X7E;
			}else if (ASIIC[i].equals("DEL")) {
				hex[i] = 0X7F;
			}
			vector.add(dtb.toBinary(hex[i], 8));

		}

//		System.out.println("49:" + dtb.toBinary(49, 8));
		for (int i = 0; i < hex.length; i++) {
			System.out.println("ASIIC[i]:" + ASIIC[i]);
			System.out.println("hex[i]:" + Integer.toHexString(hex[i]));
		}

		String StringBinnary = "";
		for (String s : vector) {
			System.out.println("vector[i]:"+s);
			StringBinnary += s;
		}

//		System.out.println(StringBinnary);
		
		return StringBinnary;
	}
	
	
	public static String uartVectors(String asiicInput) {
		
       decimalToBin dtb = new decimalToBin();
		
		String[] ASIIC = asiicInput.split("");
		int[] hex = new int[ASIIC.length];
		Vector<String> vector = new Vector<>();
		for (int i = 0; i < ASIIC.length; i++) {
			if (ASIIC[i].equals(" ")) {
				hex[i] = 0x20;
			}else if(ASIIC[i].equals("!")) {
				hex[i] = 0x21;
			}else if(ASIIC[i].equals("\"")) {
				hex[i] = 0x22;
			}else if(ASIIC[i].equals("#")) {
				hex[i] = 0x23;
			}else if(ASIIC[i].equals("$")) {
				hex[i] = 0x24;
			}else if(ASIIC[i].equals("%")) {
				hex[i] = 0x25;
			}else if(ASIIC[i].equals("&")) {
				hex[i] = 0x26;
			}else if(ASIIC[i].equals("'")) {
				hex[i] = 0x27;
			}else if(ASIIC[i].equals("(")) {
				hex[i] = 0x28;
			}else if(ASIIC[i].equals(")")) {
				hex[i] = 0x29;
			}else if(ASIIC[i].equals("*")) {
				hex[i] = 0x2A;
			}else if(ASIIC[i].equals("+")) {
				hex[i] = 0x2B;
			}else if(ASIIC[i].equals(",")) {
				hex[i] = 0x2C;
			}else if(ASIIC[i].equals("-")) {
				hex[i] = 0x2D;
			}else if(ASIIC[i].equals(".")) {
				hex[i] = 0x2E;
			}else if(ASIIC[i].equals("/")) {
				hex[i] = 0x2F;
			} else if(ASIIC[i].equals("0")) {
				hex[i] = 0x30;
			} else if (ASIIC[i].equals("1")) {
				hex[i] = 0x31;
			} else if (ASIIC[i].equals("2")) {
				hex[i] = 0x32;
			} else if (ASIIC[i].equals("3")) {
				hex[i] = 0x33;
			} else if (ASIIC[i].equals("4")) {
				hex[i] = 0x34;
			} else if (ASIIC[i].equals("5")) {
				hex[i] = 0x35;
			} else if (ASIIC[i].equals("6")) {
				hex[i] = 0x36;
			} else if (ASIIC[i].equals("7")) {
				hex[i] = 0x37;
			} else if (ASIIC[i].equals("8")) {
				hex[i] = 0x38;
			} else if (ASIIC[i].equals("9")) {
				hex[i] = 0x39;
			} else if (ASIIC[i].equals(":")) {
				hex[i] = 0X3A;
			} else if (ASIIC[i].equals(";")) {
				hex[i] = 0X3B;
			} else if (ASIIC[i].equals("<")) {
				hex[i] = 0X3C;
			} else if (ASIIC[i].equals("=")) {
				hex[i] = 0X3D;
			} else if (ASIIC[i].equals(">")) {
				hex[i] = 0X3E;
			} else if (ASIIC[i].equals("?")) {
				hex[i] = 0X3F;
			} else if (ASIIC[i].equals("@")) {
				hex[i] = 0X40;
			} else if (ASIIC[i].equals("A")) {
				hex[i] = 0X41;
			} else if (ASIIC[i].equals("B")) {
				hex[i] = 0X42;
			} else if (ASIIC[i].equals("C")) {
				hex[i] = 0X43;
			} else if (ASIIC[i].equals("D")) {
				hex[i] = 0X44;
			}else if (ASIIC[i].equals("E")) {
				hex[i] = 0X45;
			}else if (ASIIC[i].equals("F")) {
				hex[i] = 0X46;
			}else if (ASIIC[i].equals("G")) {
				hex[i] = 0X47;
			}else if (ASIIC[i].equals("H")) {
				hex[i] = 0X48;
			}else if (ASIIC[i].equals("I")) {
				hex[i] = 0X49;
			}else if (ASIIC[i].equals("J")) {
				hex[i] = 0X4A;
			}else if (ASIIC[i].equals("K")) {
				hex[i] = 0X4B;
			}else if (ASIIC[i].equals("L")) {
				hex[i] = 0X4C;
			}else if (ASIIC[i].equals("M")) {
				hex[i] = 0X4D;
			}else if (ASIIC[i].equals("N")) {
				hex[i] = 0X4E;
			}else if (ASIIC[i].equals("O")) {
				hex[i] = 0X4F;
			}else if (ASIIC[i].equals("P")) {
				hex[i] = 0X50;
			}else if (ASIIC[i].equals("Q")) {
				hex[i] = 0X51;
			}else if (ASIIC[i].equals("R")) {
				hex[i] = 0X52;
			}else if (ASIIC[i].equals("S")) {
				hex[i] = 0X53;
			}else if (ASIIC[i].equals("T")) {
				hex[i] = 0X54;
			}else if (ASIIC[i].equals("U")) {
				hex[i] = 0X55;
			}else if (ASIIC[i].equals("V")) {
				hex[i] = 0X56;
			}else if (ASIIC[i].equals("W")) {
				hex[i] = 0X57;
			}else if (ASIIC[i].equals("X")) {
				hex[i] = 0X58;
			}else if (ASIIC[i].equals("Y")) {
				hex[i] = 0X59;
			}else if (ASIIC[i].equals("Z")) {
				hex[i] = 0X5A;
			}else if (ASIIC[i].equals("[")) {
				hex[i] = 0X5B;
			}else if (ASIIC[i].equals("\\") ){
				hex[i] = 0X5C;
			}else if (ASIIC[i].equals("]")) {
				hex[i] = 0X5D;
			}else if (ASIIC[i].equals("^")) {
				hex[i] = 0X5E;
			}else if (ASIIC[i].equals("_")) {
				hex[i] = 0X5F;
			}else if (ASIIC[i].equals("`")) {
				hex[i] = 0X60;
			}else if (ASIIC[i].equals("a")) {
				hex[i] = 0X61;
			}else if (ASIIC[i].equals("b")) {
				hex[i] = 0X62;
			}else if (ASIIC[i].equals("c")) {
				hex[i] = 0X63;
			}else if (ASIIC[i].equals("d")) {
				hex[i] = 0X64;
			}else if (ASIIC[i].equals("e")) {
				hex[i] = 0X65;
			}else if (ASIIC[i].equals("f")) {
				hex[i] = 0X66;
			}else if (ASIIC[i].equals("g")) {
				hex[i] = 0X67;
			}else if (ASIIC[i].equals("h")) {
				hex[i] = 0X68;
			}else if (ASIIC[i].equals("i")) {
				hex[i] = 0X69;
			}else if (ASIIC[i].equals("j")) {
				hex[i] = 0X6A;
			}else if (ASIIC[i].equals("k")) {
				hex[i] = 0X6B;
			}else if (ASIIC[i].equals("l")) {
				hex[i] = 0X6C;
			}else if (ASIIC[i].equals("m")) {
				hex[i] = 0X6D;
			}else if (ASIIC[i].equals("n")) {
				hex[i] = 0X6E;
			}else if (ASIIC[i].equals("o")) {
				hex[i] = 0X6F;
			}else if (ASIIC[i].equals("p")) {
				hex[i] = 0X70;
			}else if (ASIIC[i].equals("q")) {
				hex[i] = 0X71;
			}else if (ASIIC[i].equals("r")) {
				hex[i] = 0X72;
			}else if (ASIIC[i].equals("s")) {
				hex[i] = 0X73;
			}else if (ASIIC[i].equals("t")) {
				hex[i] = 0X74;
			}else if (ASIIC[i].equals("u")) {
				hex[i] = 0X75;
			}else if (ASIIC[i].equals("v")) {
				hex[i] = 0X76;
			}else if (ASIIC[i].equals("w")) {
				hex[i] = 0X77;
			}else if (ASIIC[i].equals("x")) {
				hex[i] = 0X78;
			}else if (ASIIC[i].equals("y")) {
				hex[i] = 0X79;
			}else if (ASIIC[i].equals("z")) {
				hex[i] = 0X7A;
			}else if (ASIIC[i].equals("{")) {
				hex[i] = 0X7B;
			}else if (ASIIC[i].equals("|")) {
				hex[i] = 0X7C;
			}else if (ASIIC[i].equals("}")) {
				hex[i] = 0X7D;
			}else if (ASIIC[i].equals("~")) {
				hex[i] = 0X7E;
			}else if (ASIIC[i].equals("DEL")) {
				hex[i] = 0X7F;
			}
			vector.add(dtb.toBinary(hex[i], 8));

		}

//		System.out.println("49:" + dtb.toBinary(49, 8));
		for (int i = 0; i < hex.length; i++) {
			System.out.println("ASIIC[i]:" + ASIIC[i]);
			System.out.println("hex[i]:" + Integer.toHexString(hex[i]));
		}
		
		List<String>UartSequence=new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		for (String s : vector) {
			System.out.println("vector[i]:"+s);
			s="0"+demoString.StringReverse(s)+"1";
			sb.append(s);
		}
		
		return sb.toString();
	}

	public static void main(String[] args) throws DataFormatException {
//		printable.println("ASIIC_TO_BIN:"+AsciiToBinString("1D"));
		 
		printable.println("uartVectors:"+uartVectors("w 70001000 00480081"));
		printable.println("uartVectors.length:"+uartVectors("w 70001000 00480081").length());
		uart d =new uart();
	String mm= "0112";
	char [] c =mm.toCharArray();
     for (int i = 0; i < c.length; i++) {
		System.out.println(c[i]);
	}
	}
}