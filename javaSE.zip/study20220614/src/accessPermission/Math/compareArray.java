package accessPermission.Math;

import java.util.Arrays;

public class compareArray {
	private static int[] arrayx = new int[]{1,2,3};
	private static int[] arrayy = new int[]{1,2,5};
	/*两个数组不能直接比较*/
	public static boolean isEqualArray(int[]array1,int[]array2){
         boolean boo=Arrays.equals(array1,array2);
         return boo;
      }

	 /* 方法错误，比较的是两个数组不同的地址，返回false的结果
	  * public static boolean compareArray(int[]array1,int[]array2){
		  return array1==array2;
		  }*/
	  public static void main(String[]args){	
		//两个相同数组地址不同 
		System.out.println(arrayx); //[I@15db9742
		System.out.println(arrayy);//[I@6d06d69c
		System.out.println(isEqualArray(arrayx,arrayy));//方法正确
		System.out.println("over");
		
	 }
}
