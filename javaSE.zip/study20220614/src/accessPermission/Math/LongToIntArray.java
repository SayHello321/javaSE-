package accessPermission.Math;
public class LongToIntArray {
	public static int[] LongToIntArray(long[]array) {
		int[]temp=new int[array.length];
		for(int i =0;i<array.length;i++){
		temp[i]=(int)array[i];
		}
		return temp;
	}
	public static void main(String[]args) {		
		long [] array1 = {32,44,36,1,6,8};
		int[]array2=LongToIntArray(array1);
		FLASH_method.printArray(array2);
		System.out.println("test over");
	}
}
