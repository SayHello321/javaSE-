package accessPermission.Math;

public class ASCIIToBinary {

public static void main(String[] args) {
//	char str1 ='2';
//	char str2='8';
//	String str="10";
//	String str3="1011";	
//	int x =Integer.valueOf(str);
//	int x1 =Integer.valueOf(str3).intValue();
//	int num =(str1-'0')*16+(str2-'0');
//	System.out.println(num);
//	System.out.println(x1);
	long [] a= {48,50,102};
	long [] a1= {a[0],a[2]};
	byte[] b =new byte[a.length];	
	for(int i=0;i<a.length;i++){
		b[i]=(byte)a[i];	
	}
	String s=new String(b);
	long data0=Long.parseLong(s,16);
	long longdata=Long.parseLong("2B",16);
//	int data0 =Integer.parseInt(s);
//	int signedInt =Integer.valueOf(s);
	System.out.println(b[0]);
	System.out.println(b[1]);
	System.out.println(b[2]);
	
	System.out.println("Stringtohex: "+longdata);
	System.out.println("decimal_data0: "+data0);
	System.out.println("a1[0]: "+a1[1]);
	
}

}
