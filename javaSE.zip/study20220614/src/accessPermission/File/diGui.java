package accessPermission.File;

import java.io.File;

/*1.递归：
 * 直接递回：自己调用自己的方法
 * 间接递归：a方法调用b方法，b方法再调用a
 *2.使用前提 
 *  ① 调用方法的时候，主体不变，每次调用方法的参数不同，可以使用递归
 *  ② 构造方法禁止使用递归，否则会产生无数个对象，编译报错 */
public class diGui {
 
	//1.利用递归计算1-n的和 ，但是压栈与弹栈效率低
	private static int sum(int n) {	//Exception in thread "main" java.lang.StackOverflowError 栈内存溢出
		System.out.println(n);
		if(n==1) {
			return 1; //结束方法
		}		
			return n+sum(n-1);
		
	}
	
	//2.利用递归计算阶乘
	private static int factorial(int n) {
		
		System.out.println(n);
		if(n==1) {
			return 1; //结束方法
		}		
			return n*factorial(n-1);
		
	}
	//3.利用递归打印多级目录，遍历目录
	private static void getAllFile(File directory) {
		System.out.println("directory: "+directory);
		File[] file =directory.listFiles();
		for(File files: file) {
			//判断是否是文件夹
			if(files.isDirectory()) {
				getAllFile(files); //参数是files,不是directory
			}else {
				//如果是文件直接打印
				System.out.println("document:"+files);
				
			}
		}

	}
	//4.类似方法3，创建一个文件搜索的案例。
	private static void searchDocument(File directory) {
//		System.out.println("directory: "+directory);
		File[] file =directory.listFiles();
		for(File files: file) {
			//判断是否是文件夹
			if(files.isDirectory()) {
				searchDocument(files); //参数是files,不是directory;
			}else {
				//如果是文件直接打印
				String documentName = files.getName();
				boolean docFormat = documentName.endsWith(".java");
				if(docFormat) {
				System.out.println("document:"+files);
				}
			}
		}

	}
    	public static void main(String[] args) {
    		
//	      int sum=sum(365);  
//		  System.out.println("sum："+sum);
//		  int fac= factorial(4);
//		  System.out.println("阶乘: 4! = "+fac);
//		  System.out.println("=============================================");
		  File dir=new File("C:\\Users\\12525\\eclipse-workspace\\study\\src\\accessPermission\\File\\文件夹b");
//		  getAllFile(dir);
		  searchDocument(dir);
 }
    	
}
