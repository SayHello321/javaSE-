package accessPermission.File;

import java.io.File;
import java.io.FileFilter;

/*1.FileFilter类：是一个抽象类，过滤器，用来过滤抽象路径(File的对象);
 * FilenameFilter:是一个接口，其实现类可以过滤文件名
 * 注意：两个接口没有实现类，自己重写accept方法，定义过滤规则
 *2.方法 
 *  ① File[]   listFiles(FileFilter filter)   返回抽象路径名数组，这些路径名表示此抽象路径名表示的目录中满足指定过滤器的文件和目录。
 *    作用：用来过滤File对象   抽象方法：用来过滤文件的方法
 *    boolean accept(File pathName); 测试指定File路径是否包含在某个路径列表内
 *    File pathname: 使用file.listFiles()方法遍历每个抽象路径
 *  ② boolean accept(File dir ,String name) 测试指定文件是否包含在某一文件列表中
 *  ③ char toLowerCase(char ch)  返回转换后字符的小写形式，如果有的话；否则返回字符本身。
 *    toUpperCase()*/
public class fileFilter implements FileFilter{

	@Override
	public boolean accept(File pathname) {
	if(pathname.isDirectory()) {
		return true; //如果true则把参数传给listFile的每个对象，false则全部过滤掉
	}
		return pathname.getName().toLowerCase().endsWith(".java");
      }
	//用文件过滤器过滤".java结尾的文件"
	private static void getAllFile(File directory) {
//		System.out.println("directory: "+directory);
		/*使用listFiles(FileFilter filter)方法，把Filter对象传参给pathname参数*/
		File[] file =directory.listFiles(new fileFilter());  //
		for(File files: file) {
			//判断是否是文件夹
			if(files.isDirectory()) {
				getAllFile(files); //参数是files,不是directory
			}else {
				//如果是文件直接打印
				System.out.println("document:"+files);
				
			}
		}

	}
	public static void main(String[] args) {
		  //File dir=new File(pathname); 
		  File dir=new File("C:\\Users\\12525\\eclipse-workspace\\study\\src\\accessPermission\\File\\文件夹b");
		  getAllFile(dir) ;
	}
	}