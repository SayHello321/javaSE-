package accessPermission.File;

import java.io.File;

/* java.io.File:
 * 1.File:文件和目录路径名的抽象表示形式,抽象路径。 
 *  File类中的方法可以进行：创建文件、文件夹、删除、获取、判断文件是否存在、遍历文件、获取文件大小
 *  File类与系统无关，任何系统都可以用File中的方法
 * 2.关键字：
 *   file:文件
 *   directory:文件夹、目录
 *   path:路径  
     static String pathSeparrator 与系统有关的路径分隔符，为了方便，把它表示为一个字符串
	 static char   pathSeparrator 与系统有关的路径分隔符
	 static String separator      与系统有关的默认名称分隔符,为了方便，把它表示为一个字符串
	 static char   separator      与系统有关的默认名称分隔符
	 操作路径：
	 C:\work\A.txt  windows系统
	 C:/work/A.txt  Linux系统
	 System.out.println("C:"+File.separator+"work"+File.separator+"A.txt")
	 
 * 3.路径
 *   绝对路径：以盘符开始的路径，如：C:\work\A.txt 
 *   相对路径：相对当前项目的根目录： 如：A.txt  m\A.txt
 *   注意:路径不区分大小写，windows路径是反斜杠\ 两个反斜杠代表一个普通的反斜杠
 * 4.构造方法：
     ① File(File parent, String child);   根据 parent 抽象路径名和 child 路径名字符串创建一个新 File 实例。 
     ② File(String parent, String child); 根据 parent 字符串路径名和 child 路径名字符串创建一个新 File 实例。
     ③ File(String pathname);             通过将给定路径名字符串转换为抽象路径名来创建一个新 File 实例。 
     ④ String getAbsolutePath()           返回此抽象路径名的绝对路径名字符串,不管File路径是绝对还是相对都返回绝对路径。 
     ⑤ String getPath()                   将此抽象路径名转换为一个路径名字符串。 
     ⑥ String getName()                   返回由此抽象路径名表示的文件或目录的名称。 
     ⑦ long length()                      返回由此抽象路径名表示的文件的长度 
     ⑧ boolean exists()                   判断此抽象路径名表示的文件或目录是否存在。 
     ⑨ boolean isDirectory()              判断此File是否为目录/文件夹
     ⑩ boolean isFile()                   判断此File是否为文件
 *    */
public class file {
	private static void separatorShow() {
		   String pathSeparator =File.pathSeparator;
		   System.out.println(pathSeparator); //windows是;   Linux是:
		   
		   String  separator =File.separator;
		   System.out.println(separator);  //windows是\   Linux是/

	}
	private static void FileShow() {
		  //打印路径
		   System.out.println("真路径\t"+"C:"+File.separator+"work"+File.separator+"A.txt");
		   
		   File file1 =new File("C:\\work\\A.txt");  //真实存在的路径
		   System.out.println("真路径\t"+file1);
		   
		   File file2 =new File("C:\\work\\dummy\\A.txt");  //也可以输入假路径
		   System.out.println("假路径\t"+file2);
		   
		   File file3 =new File("A.txt");  //也可以输入相对路径
		   System.out.println("相对路径\t"+file3);

	}
	private static void FileParentChild(String parent,String child) {
		File file=new File( parent,child); 
        System.out.println(file);
	}
	private static void FileParentChild(File parent,String child) {
		File file=new File( parent,child); 
        System.out.println(file);
	}
	private static void getAbsolutePathShow() {
		File file1 = new File("C:\\Users\\12525\\eclipse-workspace\\study\\src\\accessPermission\\File\\file.java");//本file类的真实绝对路径地址
		File file2 = new File("src\\accessPermission\\File\\file.java");////本file类的真实相对路径地址
		
        String absolutePath1=file1.getAbsolutePath();
        long len =file1.length();
        String name =file1.getName();
        boolean isPathExist =file1.exists();
        boolean isAbsolutePath1 =file1.isAbsolute();  
        System.out.println("file1打印结果:");
        System.out.println("file1: "+file1);
        System.out.println("absolutePath1: "+absolutePath1);
        System.out.println("length: "+len+"字节");
        System.out.println("name: "+name);
        System.out.println("isPathExist: "+isPathExist);
        System.out.println("isAbsolutePath: "+isAbsolutePath1);
        
        System.out.println("file2打印结果:");
        String absolutePath2=file2.getAbsolutePath(); 
        boolean isAbsolutePath =file2.isAbsolute();      
        System.out.println("file2: "+file2);
        System.out.println("absolutePath2: "+absolutePath2);
        System.out.println("isAbsolutePath: "+isAbsolutePath);
	}
   public static void main(String[] args) {
//	   separatorShow();
//	   FileShow();
//	   FileParentChild("C:","\\work\\A.txt");   //File(String parent, String child) 
//	   FileParentChild("D:","\\work\\A.txt");   //File(String parent, String child)
//	   FileParentChild(new File("E:"),"\\work\\B.txt");  ////File(File parent, String child)
	   getAbsolutePathShow();
	 
}
}
