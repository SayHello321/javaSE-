package accessPermission.File;

import java.io.File;
import java.io.IOException;

/*1.File类创建删除的方法
 *  ① boolean createNewFile();    当且仅当不存在具有此抽象路径名指定名称的文件时，不可分地创建一个新的空文件,此方法不能创建文件夹。
 *    true 文件不存在，创建文件，返回true    
 *    false 文件存在，不会创建，返回false
 *  ② boolean delete();           删除此抽象路径名表示的文件或目录。  
 *    true 文件/文件夹删除成功 返回true
 *    false 文件夹中有内容，不会删除返回false，构造方法中路径不存在返回false
 *  ③ boolean mkdir() ;           创建此抽象路径名File指定的目录(单级文件夹),boolean返回值和createNewFile()一样。  
 *  ④ boolean mkdirs() ;          创建此抽象路径名指定的目录(多级文件夹)，包括所有必需但不存在的父目录。
 *2.File类遍历(文件夹)目录功能
 *  ① String [] list();           返回一个字符串数组，这些字符串指定此抽象路径名表示的目录中的文件和目录(不显示文件/文件夹所在地址)。
 *  ② File[] listFiles()          返回一个抽象路径名数组，这些路径名表示此抽象路径(File)名表示的目录中的文件(显示文件/文件所在夹地址)。  */
public class FileMethod {
	private static void createNewFile() {
		File file = new File("src\\accessPermission\\File\\文件1.txt");
        try {
			boolean hasCreateFile =file.createNewFile();
			System.out.println("hasCreateFile: "+hasCreateFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	}
	private static void mkdir() {
		File file = new File("src\\accessPermission\\File\\文件夹a");  //单级文件夹
		boolean hasmkdir = file.mkdir();		
		System.out.println("hasmkdir: "+hasmkdir);
		
		File file1 = new File("src\\accessPermission\\File\\文件夹b\\文件夹c\\文件夹d");  //多级文件夹
		boolean hasmkdirs = file1.mkdirs();
		System.out.println("hasmkdirs: "+hasmkdirs);
	}
	private static void delete() {
		File file = new File("src\\accessPermission\\File\\文件夹b\\文件夹c\\文件夹d\\d3.txt");  //目录里面有文件，不是空的不能删除该目录，返回false
		boolean hasDelete = file.delete();
		System.out.println("hasDelete: "+hasDelete);
	}
	private static void list() {
		File file = new File("src\\accessPermission\\File\\文件夹b\\\\文件夹c\\文件夹d");//不能遍历文件，否则nullPointException
        String[] doc =file.list();
        System.out.println("=================  文件夹d下文件有(不显示文件/文件夹所在地址)：  ===================");
        for (int i = 0; i < doc.length; i++) {
			System.out.println(doc[i]);
		}
	}
	private static void listFiles() {
		File file = new File("src\\accessPermission\\File\\文件夹b\\\\文件夹c\\文件夹d");//不能遍历文件，否则nullPointException
        File[] doc =file.listFiles();
        System.out.println("=================  文件夹d下文件有(显示文件/文件夹地址)：   ======================");
        for (int i = 0; i < doc.length; i++) {
			System.out.println(doc[i]);
		}

	}
	public static void main(String[] args) {
		createNewFile();
		mkdir();
		delete();
		list();
		listFiles();
	}
}
