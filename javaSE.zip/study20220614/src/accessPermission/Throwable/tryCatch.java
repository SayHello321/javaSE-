package accessPermission.Throwable;

import java.io.IOException;

/*try ...catch:异常处理的第二种方式，程序继续执行
 * try{
 * 可能产生有异常的代码
 * }catch(定义一个异常的变量，用来接受try中抛出的异常对象){
 * 异常的处理逻辑，异常何异常对象之后，怎么处理异常对象，一般在工作中，会把异常的现象记录到一个日志中
 * }
 * ...
 * catch(异常名 变量名){}
 * 注意：
 * 1.try中可能抛出多个异常对象，那么就可以使用多个catch来处理这些异常对象
 * 2.一次捕获多次处理，也可以多次捕获分别处理catch
 * 3.如果try中产生了异常，那么就会执行catch中的异常处理逻辑，再去执行try..catch后面的代码
 *   如果try中没有异常就不会执行catch中的代码 
 * */
public class tryCatch {

	private static void readFile(String filename)throws IOException {
		
        if(!filename.endsWith(".txt")) {
        	throw new IOException("文件后缀不对");//java.io.IOException: 文件后缀不对 
        }
        System.out.println("路径没有问题，读取文件"); 
	}
	
	public static void main(String[] args) {
		try {
			readFile("c:\\exception.tt");
		} catch (IOException e) {
			//try抛出什么异常catch就定义什么异常变量来接收这个异常对象
			e.printStackTrace();/* java.io.IOException: 文件后缀不对 at
								 * accessPermission.Throwable.tryCatch.readFile(tryCatch.java:22) at
								 * accessPermission.Throwable.tryCatch.main(tryCatch.java:29)
								 */
//			System.out.println(e.getMessage());//文件后缀不对
//			System.out.println(e.toString());//java.io.IOException: 文件后缀不对
		}
		System.out.println("代码继续执行！");
		
	}
}
