package accessPermission.Throwable;

import java.io.IOException;

/*1.finally代码块格式:用于资源释放（资源回收），无论是否异常，最后都要释放IO
 *2. 格式：
 * try ...catch:异常处理的第二种方式，程序继续执行
 * try{
 * 可能产生有异常的代码
 * }catch(定义一个异常的变量，用来接受try中抛出的异常对象){
 * 异常的处理逻辑，异常何异常对象之后，怎么处理异常对象，一般在工作中，会把异常的现象记录到一个日志中
 * }
 * ...
 * catch(异常名 变量名){
 * } finally{
 *  无论是否出现异常都会执行 }
 *3.注意事项：
 *   ①finally必须和try一起使用
 *   ②无论是否异常，最后都要释放IO 
 *   ③如果finally中变量有返回值，那么此变量的值永远是finally中的返回值 
 *   ④如果父类没有throw异常，子类只能捕获catch,不能throw */
public class Finally {

	private static void readFile(String filename)throws IOException {
		
        if(!filename.endsWith(".tx")) {
        	throw new IOException("文件后缀不对");//java.io.IOException: 文件后缀不对 
        }
        System.out.println("路径没有问题，读取文件"); 
	}
	
	public static void main(String[] args) {
		try {
			readFile("c:\\exception.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			System.out.println("资源释放！");
		}
	}
}
