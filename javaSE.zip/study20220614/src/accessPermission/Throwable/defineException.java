package accessPermission.Throwable;
/*Exception:编译期异常，方法内部抛出编译期异常
 * RuntimeException:运行期异常，无需处理，交给虚拟机中断处理*/
import java.util.List;
import java.util.Scanner;

/*模拟操作已存在用户名则抛出：用户名已经被注册*/
public class defineException extends  Exception {
	//效仿源码可自定义xxxException类
	public defineException() {}
	public defineException(String message) { super(message);}
	
	//1.建立数据库（花名册）
	private final static List<String>userNames=List.of("李莉","王奔","张大","杨洋");
	//2.建立一个方法，检查数组中是否有这个人
	  public static void checkName(String name) throws defineException ,UnsupportedOperationException {
		  for(String userName : userNames) {
			  if(userName.equals(name)) {
				  throw new defineException("该用户名已被注册！");
			  }	  
		  }
		  
		  System.out.println("恭喜你注册成功！"); 
		  userNames.add(name);//此行代码不可操作，UnsupportedOperationException
	  }
	
 public static void main(String[] args) {
	//3.使用Scanner获取用用户输入
	 Scanner sc =new Scanner(System.in);
	 System.out.println("请输入您要注册的用户名：");
	 String name =sc.next();
	 try {
		checkName(name);
		
	} catch (defineException e) {
	
		e.printStackTrace();
	}
	catch(UnsupportedOperationException e) {
	 System.out.println(123);
	 System.out.println(e.getMessage());//null
	// return;//return在这里是程序结束
 }finally {}
	
	 System.out.println("后续代码继续执行！");
   
}
}
