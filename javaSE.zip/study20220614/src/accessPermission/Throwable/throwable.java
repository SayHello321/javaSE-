package accessPermission.Throwable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*1.Throwable:直接子类 Error,Exception
 *   ① Error:错误，JVM解决不了
 *   ② Exception:使用不当，异常类，可以解决
 *    (1) throws new ..Exception  //new的必须时Exception或者其子类 
 *    (2) try{  ... }
 *   catch( ...Exception e){
 *       e.printStackT ();               }
 * 2.throwable中的三个重要方法
 *   ① getMessage(); 返回此 throwable 的详细消息字符串。
 *   ② toString(); 返回此 throwable 的简短描述。
 *   ③ printStackTrace(); 将此 throwable 及其追踪输出至标准错误流。    
 * */
public class throwable {
	 
	private static void showException() /*throws ParseException*/ {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
		
		try {
			Date date = sdf.parse("2021年1203日");// 格式不对解析异常
			System.out.println("date:" + date);
		} catch (ParseException e) {
			System.out.println(e.getMessage());//Unparseable date: "2021年1203日"
			e.printStackTrace();
		}

		System.out.println("Exception处理后程序继续运行！");

	}

	private static void showError() {
		System.out.println("JVM中断！");
		int[] x = new int[1024 * 1024 * 1024];//内存溢出OutOfMemoryError	
		System.out.println(x);
	}

	public static void main(String[] args) {
		showException();
//		showError();

	}
}
