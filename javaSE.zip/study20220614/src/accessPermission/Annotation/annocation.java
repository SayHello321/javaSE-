package accessPermission.Annotation;

import accessPermission.Annotation.自定义注解.mode;
import accessPermission.Annotation.自定义注解.myAnnotation;

import java.net.MalformedURLException;
import java.net.URL;

import accessPermission.Annotation.自定义注解.anno1;

/*注解：@注解名称
 *1. JDK预定义注解
 *   ① @Override:检测该方法是否继承自父类（接口）的
 *   ② @Deprecated:该注解便是的内容，表示已过时
 *   ③ @SupressWarnings：压制警告，可以压制类或者方法，传参all @SupressWarnings("all")
 *2.自定义注解
 *     格式  public @interface 注解名称{}
 *  ① 元注解 描述注解的注解，种类有：
 *     @Target:描述注解作用的位置，ElementType 12种枚举类型
 *     @Retention:描述注解被保留的阶段，RetentionPolicy 3种枚举类型
 *     @Documentd:描述注解是否被抽取到API文档中
 *     @Inherited:描述注解是否被子类继承 
 *  ② 本质：是一个接口，默认继承Annotation
*     public interface myAnnotation extends java.lang.annotation.Annotation{}
*   ③ 属性：接口中的抽象方法
*     属性的返回值类型
*     基本数据类型、String、枚举、注解、以上类型的数组*/
@SuppressWarnings("all") //压制所有警告
public class annocation extends superClass{
@myAnnotation(method1=12,method2= {1,2,3},method3=mode.XMODE,method4=@anno1) //自定义注解
private static void preShow() {
	superClass.m1();
	new superClass().m2();
	
}


@Override
 void m2(){
	super.m2();
	System.out.println("m2方法重写！");
}
public static void main(String[] args) {
	preShow();
	
	
}
}
