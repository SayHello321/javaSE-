package accessPermission.Annotation;

public  class superClass {
  /* 方法1
   * @version 1.1
   * @author me
   * */
 @Deprecated
  static void m1() {
	  System.out.println("已过时！");
  }
  /* 方法2
   * @version 1.2
   * @author me
   * */
    void m2(){
	  System.out.println("新方法");
  }
}
