package accessPermission.Annotation.自定义注解;
/*1.命令提示窗口
*   javac myAnno.java
*   javap myAnno.java  //反编译
* 2.本质：是一个接口，默认继承Annotation
*   public interface myAnnotation extends java.lang.annotation.Annotation{}
* 3.属性：接口中的抽象方法
*     属性的返回值类型
*     基本数据类型、String、枚举、注解、以上类型的数组
*/
public @interface myAnnotation {
 int method1();
 int [] method2();
 mode method3();
 anno1 method4();
}
