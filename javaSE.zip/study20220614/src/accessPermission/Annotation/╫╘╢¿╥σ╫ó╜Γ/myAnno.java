package accessPermission.Annotation.自定义注解;
public @interface myAnno {

}