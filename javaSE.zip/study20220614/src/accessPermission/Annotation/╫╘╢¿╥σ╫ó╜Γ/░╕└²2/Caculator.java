package accessPermission.Annotation.自定义注解.案例2;

public class Caculator {
@check
public static  void add() {
	System.out.println("1+0="+(1+0));
	
}
@check
public static void subtact() {
	System.out.println("1-0="+(1-0));
}
@check
public static void  div() {
	System.out.println("1/0="+(1/0));
}
@check
public static void str() {
	String str =null;
	System.out.println("str:"+str.length());
}
}
