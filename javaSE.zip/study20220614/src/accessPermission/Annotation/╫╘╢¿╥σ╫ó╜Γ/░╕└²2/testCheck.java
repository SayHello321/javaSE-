package accessPermission.Annotation.自定义注解.案例2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/*利用注解进行方法测试，相当于Junit测试
 * */

public class testCheck {
@check
private static void checkBug ()  {
    Caculator cal =new Caculator();
    Class caculatorlClass =Caculator.class;
    Method[] methods =caculatorlClass.getDeclaredMethods();
  
	try {
		  BufferedWriter bw = new BufferedWriter(new FileWriter("src\\accessPermission\\Annotation\\自定义注解\\案例2\\CaculatorBug.txt"));
		  int number =0;//记录bug个数
		    for(Method method :methods) {
		    	//判断方法上是否有check注解
		    	if(method.isAnnotationPresent(check.class)) {
		    		
		    	try {
					method.invoke(cal);
				} catch (Exception e) {
					//记录bug到文件中
			    	number++;
			    	bw.write(method.getName()+"方法出现异常！");
			    	bw.newLine();
			    	bw.write("异常的名称："+e.getCause().getClass().getSimpleName());//异常的真实原因
			    	bw.newLine();
			    	bw.write("异常的原因："+e.getCause().getMessage());
			    	bw.newLine();
			    	bw.write("---------------------------------------------------------------");	
			    	bw.newLine();
				    } 
		    
		    	 }
		    	 
		    }    
		    bw.write(caculatorlClass.getName()+"一共有"+number+"个bug");
		    bw.newLine();
	    	bw.flush();
	    	bw.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  
    
    
}
public static void main(String[] args) {
	checkBug ();
}
}
