package accessPermission.Annotation.自定义注解.案例2;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)//方法前加注解
@Retention(RetentionPolicy.RUNTIME) //运行阶段被保留
public @interface check {

}
