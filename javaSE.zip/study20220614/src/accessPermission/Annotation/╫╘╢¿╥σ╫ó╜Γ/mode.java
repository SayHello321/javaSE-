package accessPermission.Annotation.自定义注解;

public enum mode {
XMODE,YMODE;
}
