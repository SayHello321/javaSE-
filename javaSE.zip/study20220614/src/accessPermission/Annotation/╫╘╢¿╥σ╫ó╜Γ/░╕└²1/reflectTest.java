package accessPermission.Annotation.自定义注解.案例1;

import java.lang.reflect.Method;

/*利用注解代替配置文件*/
@pro(className="accessPermission.reflect.Person",methodName="play")
public class reflectTest {
private static  void test() throws Exception  {
    //1.解析注解，获取该类的所有字节码文件对象
	Class<reflectTest>reflectTestClass=reflectTest.class;
	//2.获取注释对象
	pro annotation =reflectTestClass.getAnnotation(pro.class);
	 //3.调用注解对象中的方法获取返回值
	/*public proimpl implements pro{
	 *  public String className(){
	 *  return "accessPermission.reflect.Person"
	 *  }
	 * }
	 * */
	//4.提取类和方法
	String ClassName =annotation.className(); //内存中实现类重写了className()方法
	String MethodName=annotation.methodName();
	System.out.println(ClassName);
    System.out.println(MethodName);	
    
     //5.加载类进内存  
		Class cls =Class.forName(ClassName);
	 //6.获取新类的对象
		Object objclass =cls.newInstance();
	 //7.获取新方法的对象,执行方法
		Method method =cls.getMethod(MethodName);
		method.invoke(objclass);
	
}
public static void main(String[] args) throws Exception {
	test();
}
}
