package accessPermission.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/*1.reflect:反射,将类的各个组成部分封装成其他对象
 *2.反射机制
 *  ①  Filed[] getFields(); 获取public修饰的成员变量
 *     Field getField();
 *     Filed[] getDeclaredFields();//获取所有的成员变量
 *     Field getDeclaredField();
 *     myfield.setAccessible(true);//暴力反射
 *  ② Constructor[] getDeclaredConstructors():获取构造方法
 *    Constructor    getDeclaredConstructor();
 *    Constructor[] getConstructors():获取构造方法
 *    Constructor    getConstructor();
 *  ③ Method[] getMethods();获取成员方法
 *    Method   getMethods()；
 *    Method[] getDeclaredMethods();获取成员方法
 *    Method   getDeclaredMethod();
 *    method.invoke(对象名);执行对象中的方法
 *  ④ String getName():获取类名
 *    String na=personClass.getName();
 *    */
public class reflect {
	private static void showField() throws Exception {
		//获取类名
		Class personClass =Person.class;
		String na=personClass.getName();
		System.out.println("获取类名："+na);
		//获取fields
		Field[]fields=personClass.getFields();
		for (int i = 0; i < fields.length; i++) {
			System.out.println(fields[i]);
		}
		
		//获取Filed
		Field name=personClass.getField("age");
		Field age =personClass.getField("age");		
		
		//设置成员变量name的值
		Person p =new Person();
		p.setName("李青");
		p.setAge(15);
		
		//获取Field值，打印输出
		Object nameValue =name.get(p);
		Object ageValue =age.get(p);
		
		System.out.println(p);		
		System.out.println("nameValue:"+nameValue);
		System.out.println("ageValue:"+ageValue);
		
		System.out.println("====================declaredFields=======================================");
		Field[] declaredFileds =personClass.getDeclaredFields();
		for (int i = 0; i < declaredFileds.length; i++) {
			System.out.println(declaredFileds[i]);
		}
		Field Address =personClass.getDeclaredField("Address");
		//直接访问会有非法访问异常IllegalAccessException，访问前非public要进行忽略权限修饰符的安全检测
		Address.setAccessible(true);//暴力反射
		p.setAddress("shanghai");
		System.out.println(p);
		Object AddressValue =Address.get(p);
		System.out.println("AddressValue:"+AddressValue);
	}
	private static void showConstructor() throws Exception {
		Constructor[] declaredcon =Person.class.getDeclaredConstructors();
		for (int i = 0; i < declaredcon.length; i++) {
			System.out.println(declaredcon[i]);
		}
	
		Constructor con =Person.class.getDeclaredConstructor(String.class,int.class,String.class);
		//创建对象
		Object person =con.newInstance("王琦",22,"shanghai");
		System.out.println(person);
		
		Object person2 =Person.class.newInstance();
		System.out.println(person2);
	}
	private static  void showMethod() throws Exception {
		Method method_play=Person.class.getMethod("play");
	    Person p =new Person();
	    method_play.invoke(p); 
	    
	    //查看Person中的成员方法,包括自身方法和Object中的方法
	    Method[] methods=Person.class.getMethods();
		for (int i = 0; i < methods.length; i++) {
			System.out.println(methods[i]);
		}
	}
    public static void main(String[] args) throws Exception {
//    	showField();
//    	showConstructor();
    	showMethod();
	}
}
