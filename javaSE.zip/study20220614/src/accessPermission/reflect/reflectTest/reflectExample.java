package accessPermission.reflect.reflectTest;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Properties;
/*获取Class方法
 * 1.Class.forName("全类名"); //将字节码文件加载到内存，返回Class对象
 * 2.类名.class; //通过类名的属性获取class
 * 3.对象.getClass();
 *  结论、；三种方式对应的对象==*/
/*要求：在不该代码的前提下，创建任意都一项，执行任意方法*/
public class reflectExample {
public static void test() throws Exception {
	//1.加载配置文件为一个集合
	Properties pro =new Properties();
	ClassLoader loader= reflectExample.class.getClassLoader();//获取本类下的配置文件
	InputStream is =loader.getResourceAsStream("pro.properties"); //获取文件resource
	
	//2.加载文件并配置数据
	pro.load(is);
	String className =pro.getProperty("className");
	String method_play =pro.getProperty("method_play");
	String method_eat = pro.getProperty("method_eat");
	
	//3.加载本类进内存
	Class cls = Class.forName(className);
	
	//4.创建本类新对象
	Object ob =cls.newInstance();
	System.out.println(ob.getClass());//查看Person对象
	//5.获取方法对象
	Method ob_play=cls.getMethod(method_play);
	Method ob_eat=cls.getMethod(method_eat);
	
	
	//6.执行方法
	ob_play.invoke(ob);
	ob_eat.invoke(ob);
}
 public static void main(String[] args) throws Exception {
	 test();
}
}
