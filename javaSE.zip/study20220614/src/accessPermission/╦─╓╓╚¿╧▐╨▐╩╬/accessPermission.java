package accessPermission.四种权限修饰;
/* 四种权限修饰：         public > protected > (default) > private  default在这里指不写
 * 同一个类（class）：    yes       yes         yes          yes
 * 同一个包（package）：  yes       yes         yes          no
 * 不同包子类：          yes       yes          no           no
 * 不同包非子类：         yes       no          no           no
 * */
public class accessPermission {

}
