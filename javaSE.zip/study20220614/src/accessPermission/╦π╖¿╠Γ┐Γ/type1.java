package accessPermission.算法题库;

public  class type1 {
/*@param source {@code source},the source String.
 *@param target {@code target},the target String.
 *@return the index of target while first target char appear to the source String.
 * 找出目标字符串在源字符串中第一次出现的位置*/
public static int  StringIndex1(String source,String target) {
	  int n = source.length(), m = target.length();
      for (int i = 0; i + m <= n; i++) {
          boolean flag = true;
          for (int j = 0; j < m; j++) {
              if (source.charAt(i + j) != target.charAt(j)) {
                  flag = false;
                  break;
              }
          }
          if (flag) {
              return i;
          }
      }
      return -1;
  }
/*@param source {@code source},the source String.
 *@param target {@code target},the target String.
 *@return the index of target while first target char appear to the source String.
 * 找出目标字符串在源字符串中第一次出现的位置*/
public int StringIndex2(String source, String target) {
    int n = source.length(), m = target.length();
    char[] s = source.toCharArray(), p = target.toCharArray();
    // 枚举原串的「发起点」
    for (int i = 0; i <= n - m; i++) {
        // 从原串的「发起点」和匹配串的「首位」开始，尝试匹配
        int a = i, b = 0;
        while (b < m && s[a] == p[b]) {
            a++;
            b++;
        }
        // 如果能够完全匹配，返回原串的「发起点」下标
        if (b == m) return i;
    }
    return -1;
}
/**/
/*@param nums ,the source array
 *@param target ,the target value
 *@return the index position of target first appear on the array
 *二分查找:在升序数组里面查找目标值位置*/
public static int binarySearch(int[] nums, int target) {
    if (nums == null || nums.length == 0)
        return -1;
    
    int left = 0, right = nums.length - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (target == nums[mid])
            right = mid-1;
        else if (target < nums[mid])
            right = mid-1;
        else
            left = mid+1 ;
    }
    
    if (left < nums.length && nums[left] == target) {  // left = first position
        return left;}
    return -1;
}
/*二分法*/
public static int findPosition(int[] nums, int target) {
    int low = 0, high = nums.length - 1;
    while (low <= high) {
        int mid = (high - low) / 2 + low;
        int num = nums[mid];
        if (num == target) {
            return mid;
        } else if (num > target) {
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }
    return -1;
}


/**
 * @param a: An integers array.
 * @return: return any of peek positions.
 * 寻找峰值：a[0]<a[1],且a[n-1]<a[n]<a[n+1],找到任意一个峰值的位置，返回数组index.
 */
public static int findPeak(int[] a) {
 if(a==null||a.length==0){
     return -1;
 }
 int left=0,right=a.length-1;
while(left+1<right){
   int mid = left+(right-left)/2;
 //这里可以直接这么搞我觉得原因是 / 2永远是小的一方，由于left+ 1还不到right,所以+1不会越界
    if(a[mid]<a[mid+1]){
        left=mid;
    }else{
          right =mid;
    }

}
return a[left]>a[right]?left:right;
}
public static void main(String[] args) {
	int index =StringIndex1("aabbc","bb");
	System.out.println("bb_index:"+index);
	int []arr = {1,2,3,4,5,6,7};
	int[]arr1 = {1,2,1,3,4,5,7,6};
	int b =binarySearch(arr,4);
	int b1 =findPeak(arr1);
	System.out.println("4_index:"+b);
	System.out.println("b1:"+b1);
	System.out.println("a_peak_index:"+arr1[b1]);
	
}
}


