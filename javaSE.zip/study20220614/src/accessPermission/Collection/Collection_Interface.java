package accessPermission.Collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import accessPermission.Math.FLASH_method;
/*1.集合通用方法:
 *  ① boolean add(E , e); 向集合添加元素
 *            addAll(list) 可以将多个集合追加到一个集合里
 *  ② boolean remove(E,e);删除集合中的某个元素
 *  ③ void clear(); 清空集合所有元素
 *  ④ boolean contains(E,e);判断集合是否包含某个元素
 *  ⑤ boolean isEmpty();判断集合是否为空
 *  ⑥ int size(); 获取集合的长度
 *  ⑦ Object[] toArray(); 将集合转换成数组，返回Object类
 *  ⑧ List list = Arrays.asList(array); 将数组装换成集合
 *  
 *2.Collectiions类下方法
 *  ① public static<T>boolean addAll(Collection<T>c,T...elements); 往集合中添加一些元素
 *    Collections.addAll(list,"a","b","c");
 *  ② public static<T> void shuffle(List<?>list);
 *     Collections.shuffle(list);
 *  ③ public static<T>void sort(List<T>list);将集合按默认规则排序
 *  ④ public static<T>void sort(List<T>list,Comparator<？ super T> c);将集合中元素按照指定规则排序
 *    前提条件：实现comparable类并重写其compareTo方法，
 *    Collections.sort(list);
 *    comparable:自己（this）和别人（o）比较
 *    comparator:第三方裁判，比较o1-o2
 * 
 * 3.JDK9:    of方法适用于List接口，Set接口，Map接口，不适用接口的实现类
 *   用法：List<String>list=List.of("a","b","c","d");*/

public class Collection_Interface implements Comparable<Collection_Interface>,Comparator<Collection_Interface>{
	
	private String name;
	private int age;
	
	
	public Collection_Interface() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Collection_Interface(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
    
	@Override
	public String toString() {
		return "{name=" + name + ", age=" + age + "}";
	}

	@Override
	public int compareTo(Collection_Interface o) {
		//比较两个人的年龄
		//comparable接口排序规则：自己（this）-参数 是升序，反之降序 
		//return this.getAge() - o.getAge();//升序排序
		return o.getAge() - this.getAge();//降序
		//return 0;//默认元素都是相同的
	}
	@Override //必须重写，但没有调用
	public int compare(Collection_Interface o1, Collection_Interface o2) {
		//return o1.getAge()-o2.getAge();//升序
//		return o2.getAge()-o1.getAge();//降序
		return 0;
	}


	private static void CollectionShow() {
		Collection<Integer>list = new ArrayList<Integer>();//ArrayList extends list implants Collection
		list.add(10);
		list.add(11);
		list.add(12);
		Object[] array =list.toArray();
		System.out.println("====================================");
		new FLASH_method().printArray(array);		
		System.out.println("list:  "+list);
		System.out.println("====================================");
		boolean result =list.remove(11);		
		System.out.println("remove result:\t "+result);
		System.out.println("list remove: "+list);
		list.clear();
		System.out.println("list  clear: "+list);

	}
	private static void CollectionsShow() {
		List<String>list=new ArrayList<>();
		Collections.addAll(list,"a","b","c","d","e","f");
		System.out.println("====================================");
		System.out.println("list:"+list);
		Collections.shuffle(list);//打乱集合顺序
		System.out.println("乱序："+list);
		Collections.sort(list);
		System.out.println("默认排序："+list);
		
		System.out.println("====================================");
		
		Collection_Interface p1=new Collection_Interface("b",100);
		Collection_Interface p2=new Collection_Interface("a",70);
		Collection_Interface p3=new Collection_Interface("c",110);
		Collection_Interface p4=new Collection_Interface("d",70);
		
		LinkedList<Collection_Interface>list01 =new LinkedList<>();
		Collections.addAll(list01, p1,p2,p3,p4);
		System.out.println("list01:"+list01);
		Collections.sort(list01);
		System.out.println("list01自定义age升序:"+list01);
		Collections.sort(list01,new Comparator<Collection_Interface>() { //匿名局部内部类写法
			@Override
			public int compare(Collection_Interface o1, Collection_Interface o2) {
				
				if(o1.getAge()==o2.getAge()) {
					return o1.getName().charAt(0)-o2.getName().charAt(0);//a~z
				}
				
				return o1.getAge()-o2.getAge();//升序
//				return o2.getAge()-o1.getAge();//降序
				//return 0;
			}
		   }
		 );
		System.out.println("list01自定义age&name升序:"+list01);
	}
	private static void addAll() {
		List<Integer>list=new ArrayList<>();
		List<Integer>list1=List.of(1,2,3);
		List<Integer>list2=List.of(4,5,6);
		list.addAll(list1);
		list.addAll(list2);
		System.out.println("list=list1+list2"+list);
		
		}
	public static void main(String[] args) {
//		CollectionShow(); 
//		CollectionsShow();
		addAll();
	}

}