package accessPermission.Collection.应用案例.斗地主案例;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class owner {
  

 	public static void watchPoker() {
		//1.准备牌
				//用ArrayList集合装54张牌
				Map<Integer,String>poker = new HashMap<>(); 
				
				//设置一个pokerIndex集合为原始顺序，看牌时，用来给玩家看牌时排序作排序标准
				ArrayList<Integer>pokerIndex = new ArrayList<>(); 
				//一个集合装颜色
				String[] colors = {"♥","♠","♣","♦"};
				//List<String>colors=List.of{"♥","♠","♣","♦"};
				//一个集合装数字
				String[] numbers = {"2","A","K","Q","J","10","9","8","7","6","5","4","3"};
				//先把大小王装进poker集合
				int index =0;				
				poker.put(index, "大王");
				pokerIndex.add(index);     
				index++;
				
				poker.put(index, "小王");
				pokerIndex.add(index);
				index++;
				//for each循环，组装52张牌
				for(String number :numbers) {
					for(String color:colors) {
//						System.out.println(color+number);					
						poker.put(index, color+number);
						pokerIndex.add(index);
						index++;
					}
				}
				System.out.println("poker:"+poker);
				System.out.println("pokerIndex:"+pokerIndex);
				//2.洗牌
				//用Collections.shuffle(List<?> list) ,使用默认的随机源随机排列指定的列表。
				//把pokerIndex位置打乱
				Collections.shuffle(pokerIndex);
                System.out.println("打乱后的pokerIndex:"+pokerIndex);				
				System.out.println("一共有"+pokerIndex.size()+"张牌");
				
				//3.发牌
				//定义四个集合，存储3个玩家（每人17张）与底牌（3张）
				//索引3： 0%3=0,1%3=1,2%3=2,3%3=0
				ArrayList<Integer>player1 = new ArrayList<>(); 
				ArrayList<Integer>player2 = new ArrayList<>(); 
				ArrayList<Integer>player3 = new ArrayList<>(); 
				ArrayList<Integer>floor= new ArrayList<>(); 
				
				for(int i =0;i<pokerIndex.size();i++) {
					if(i>=51) {
						floor.add(pokerIndex.get(i));
						
					}
					else if(i%3==0) {
						player1.add(pokerIndex.get(i));				
					}
					
					else if(i%3==1) {
						player2.add(pokerIndex.get(i));				
					}
					
					else if(i%3==2) {
						player3.add(pokerIndex.get(i));				
					}
					
				}
				//给玩家的牌排序
				Collections.sort(player1);
//				System.out.println("player1排序 :"+player1);
				Collections.sort(player2);
				Collections.sort(player3);
				Collections.sort(floor);
		  		//5.看牌  
				
				lookpoker( "小宋",player1,poker );
				lookpoker( "小何",player2,poker );
				lookpoker( "小赵",player3,poker );
				lookpoker( "底牌",floor,poker );
				
//				System.out.print("player1: ");
//				for(Integer key : player1) {
//					String value=poker.get(key);
//					System.out.print(value+" ");
//				}
//				System.out.println();
//				
//				System.out.print("player2: ");
//				for(Integer key : player2) {
//					String value=poker.get(key);
//					System.out.print(value+" ");
//				}
//				System.out.println();
//				
//				System.out.print("player3: ");
//				for(Integer key : player3) {
//					String value=poker.get(key);
//					System.out.print(value+" ");
//				}
//				System.out.println();
//				
//				System.out.print("floor: ");
//				for(Integer key : floor) {
//					String value=poker.get(key);
//					System.out.print(value+" ");
//				}
//				System.out.println();
				
				 
	}
			
	public static void  lookpoker(String name,ArrayList<Integer>player,Map<Integer,String>poker ) {
		System.out.print(name+":  ");
		for(Integer key : player) {
			String value=poker.get(key);
			System.out.print(value+" ");
		}
		System.out.println();
	}
	public static void main(String[] args) {
		watchPoker();
		
	}
	
}
