package accessPermission.Collection.应用案例;
/*1.可变参数：
 *   格式：修饰符 返回值类型 方法名（数据类型...变量名）{}
 *2.注意
 *   ①一个方法的参数列表只能有一个可变参数
 *   ⑤如果方法的参数有多个，普通参数写前面，可变参数写在最后面  
 *3.可变参数的终极方法：  修饰符 返回值类型 方法名（Object...OBJ）可接收任意数据类型的参数 */
public class variableArguments {
     
	//传N个参数，就会创建一个长度为N的数组
	private static int add(int...array) {
		
//		System.out.println("type:"+array);
//		System.out.println("array.length:"+array.length);
		//定义初始化变量
		int sum=0;
		for(int i:array) {
			sum=sum+i;
		}
		System.out.println("sum:"+sum);
    return sum;
    
	}
	
	private static String mutiAdd (String name,int age, int...array) {
		StringBuilder str =new StringBuilder();
		for(int i:array) {
//			str=str.append( Integer.toString(i));
//			str=str.append( ""+i);
			str=str.append( String.valueOf(i));
		}
//		System.out.println(str);
		return "[姓名："+name+",年龄："+""+age+"岁,学号："+str+"]";
	}
	private static void objectType(Object...obj) {
		System.out.print("Object的任意参数: [");
		for(int i=0;i<obj.length;i++) {
			if(i==obj.length-1) {
				System.out.println(obj[i]+"]");	
			}
			else {	System.out.print(obj[i]+",");	}	
		}
		
	}
	
	
	public static void main(String[] args) {
		add(1,2,3,4,5);	
		String information =mutiAdd("张同学",17,1506090115);
		System.out.println(information);
		objectType(true,false);
		objectType(1,2,3,4);
		objectType("1","2","3","4");
		objectType("a","b","c","d");
	}
	
}
