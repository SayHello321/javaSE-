package accessPermission.Collection.应用案例;

import java.util.HashMap;
import java.util.Scanner;

/*要求：计算输入字符串的个数*/
public class MapTest {

	public static void charShow(){
		//1.获取用户输入
		Scanner sc =new Scanner(System.in);
		System.out.println("请输入一个字符串，按enter键结束！");
		String str =sc.next();
		sc.close();
		//2.创建map
		HashMap<Character,Integer>map=new HashMap<>();
		//3.判断map中是否包含字符c
		for(char c:str.toCharArray()) {
			if(map.containsKey(c)) {
			Integer value=map.get(c);
			map.put(c, value);}
			else {
				map.put(c, 1);
			}
		}
		//4.遍历map
		for(char c:map.keySet() ) {
			int value =map.get(c);
			System.out.println(c+"出现"+value+"次");
		}
		
	}
	public static void main(String[] args) {
		charShow();
	}
}
