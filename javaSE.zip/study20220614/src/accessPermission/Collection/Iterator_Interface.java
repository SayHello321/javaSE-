package accessPermission.Collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/*1.Iterator:迭代器，是个interface,要用实现类调用
 *2.构造方法：
 *  boolean hasNext(); //有元素true,否则false
 *  E next();返回迭代下一个元素
 *  hasNext() 访问原理： index：-1->0->1->2->3->4...
 *3.迭代器的使用步骤：
 *  ①使用集合中的方法 list.Iterator()获取迭代器的实现对象，使用Iterator 接口接受
 *  ②用it.hasNext();判断有没有下一个元素
 *  ③it.用next()；取集合的下一个元素*/
   
public class Iterator_Interface {
	public static void main(String[] args) {
		
		Collection<String>list = new ArrayList<>();
		
		list.add("土豆");
		list.add("西红柿");
		list.add("西瓜");
		list.add("红薯");
		
		
		
		Iterator<String> it= list.iterator();
		/*用Iterator遍历集合，已知集合size用for,不知道size用while */
		boolean result = it.hasNext();
		System.out.println(result);
		
		
		//方法一：while循环
		System.out.println("while循环:");
		while(it.hasNext()) {
			String s =it.next(); //如果没有元素再取会报错：noSuchElementException			
			System.out.print(s+",");		
		}		
		System.out.println("");
		System.out.println("======================================");
		
		//方法二：for循环
		System.out.println("for循环:");
		for(Iterator<String> it1= list.iterator(); it1.hasNext();) {
			String e = it1.next();		
			System.out.print(e+",");
		}
		System.out.println("");
		System.out.println("======================================");
		
		//方法三：for_each循环
		System.out.println("for_each循环:");
		for(String s:list) {			
			System.out.print(s+",");
		}
	}
 
}
