package accessPermission.Collection.Set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/*1.Set接口特点：
 *  ①.不允许存储重复元素；
 *  ②.没有索引，不能使用普通的for循环遍历
 *2.HashSet特点：
 *  ①.不允许存储重复元素
 *  ②.没有索引，不能使用普通的for循环遍历
 *  ③.是一个无序的集合有，存储何取出元素可能不一致
 *  ④.底层时哈希表结构，查询速度非常快
 * */
public class set {
	public static void main(String[] args) {
		
		Set<Integer>se= new HashSet<>();//用hashSet存储必须定义HashCode()和equals()方法
		se.add(1);
		se.add(2);
		se.add(3);
		se.add(1);
		
		System.out.println("Iterator遍历：");
		Iterator<?>it=se.iterator();
		while(it.hasNext()) {			
			Object obj  = it.next();
			System.out.println(obj);//取出来（1,2,3），存的是1231
		}
		
		System.out.println("增强for遍历：");
		for(Integer integer :se) {
			System.out.println(integer);
		}
		
	}
	
 
 
}
