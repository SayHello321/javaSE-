package accessPermission.Collection.Set;

import java.util.HashSet;
import java.util.LinkedHashSet;

/*linkedHashSet特点：
 *   底层是HashSet+链表：哈希表+（数组+链表、红黑树）+链表，多了一个链表成双链表可以排序*/
public class LinkedHashSetD {
	public static void HashSetShow() {
       HashSet<String>Hash= new HashSet<String>();
	   Hash.add("a");
	   Hash.add("b");
	   Hash.add("c");
	   Hash.add("c");
	   Hash.add("d");
	   System.out.println("无序的HashSet:"+Hash);
	}
	
	public static void LinkedHashSetShow() {
	       LinkedHashSet<String>LinkedHash= new LinkedHashSet<String>();
	       LinkedHash.add("e");
	       LinkedHash.add("f");
	       LinkedHash.add("g");
	       LinkedHash.add("g");
	       LinkedHash.add("h");
		   System.out.println("有序的LinkedHashSet:"+LinkedHash);
		}
	
	public static void main(String[] args) {
		HashSetShow() ;
		LinkedHashSetShow() ;
	}
}
