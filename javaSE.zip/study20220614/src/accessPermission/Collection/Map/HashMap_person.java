package accessPermission.Collection.Map;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/*HashMap存储自定义类型键值对：
 * ①：Map集合要保证key是唯一的
 * ②：作为Key的元素，必须重写hashCode()和equals()方法*/
public class HashMap_person {
	
    private String name;
    private int height;
	public HashMap_person() {}
	public HashMap_person(String name, int height) {
		super();
		this.name = name;
		this.height = height;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
    
    @Override
	public String toString() {
		return " {name=" + name + ", height=" + height + "cm]";
	}
    
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + height;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HashMap_person other = (HashMap_person) obj;
		if (height != other.height)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	private static void hashMapDemo1() {
        //key唯一，value可以重复
		HashMap<String,HashMap_person>map=new HashMap<>();
		map.put("北京", new HashMap_person("姚明",213));
		map.put("上海", new HashMap_person("李莉",167));
		map.put("香港", new HashMap_person("古天乐",178));
		map.put("香港", new HashMap_person("渣渣辉",175));
		Set<String>set =map.keySet();//获取所有地名到一个集合
		System.out.println("地名："+set);
		for(String key :set) {
			HashMap_person value =map.get(key);
			System.out.println(key+","+value);
		}
		
	}
	private static void hashMapDemo2() {
        //key唯一，value可以重复
		HashMap<HashMap_person,String>map=new HashMap<>();
		map.put(new HashMap_person("普京",65), "俄罗斯");
		map.put(new HashMap_person("老细",66), "中国");
		map.put(new HashMap_person("川普",22), "美国");
		map.put(new HashMap_person("阿莫",22), "英国");
		map.put(new HashMap_person("阿莫",26), "英国");
		Set<Map.Entry<HashMap_person,String>>set =map.entrySet();
		System.out.println(set);
		for(Map.Entry<HashMap_person,String>entry:set) {
			HashMap_person key = entry.getKey();
			String value =entry.getValue();
			System.out.println(key+","+value);
		}
		
		}
	private static void LinkedHashMapDemo3() {
		LinkedHashMap<Integer,String>map =new LinkedHashMap<>();
		map.put(2, "b");
		map.put(1, "a");
		map.put(4, "d");   
		map.put(3, "c");
		
		System.out.println("LinkedHashMap:"+map);
		
		
	}
    public static void main(String[] args) {
    	hashMapDemo1(); 
    	System.out.println("===============================================");
    	hashMapDemo2(); 
    	System.out.println("===============================================");
    	LinkedHashMapDemo3();
	}
    
    
}
