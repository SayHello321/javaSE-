 package accessPermission.Collection.Map;

import java.util.HashSet;

/*1.哈希值：十进制的证书，系统随机给的，模拟出来对象的地址
 *       Object类中 public native int hashCode(); 返回该对象的哈希码值
 *2.jdk1.8之后：
 *   哈希表结构=数组+链表； //哈希值相同的元素放在一组，链表/红黑树把哈希值相同的元素连在一起
 *   哈希表结构=数组+红黑数（提高查询效率）      */
public class HashCodeDemo {
	
	private int o;
	private String name;
	
	public HashCodeDemo() {
	}

	public HashCodeDemo( String name,int o) {
		super();
		this.o = o;
		this.name = name;
	}
    


	public int getO() {
		return o;
	}

	public void setO(int o) {
		this.o = o;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	//用hashSet自定义存储元素必须定义在该类中重写HashCode()和equals()方法
	@Override //重写保证集合对象地址和内容唯一性，不重复，哈希值相等
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + o;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HashCodeDemo other = (HashCodeDemo) obj;
		if (o != other.o)
			return false;
		return true;
	}


    @Override
	public String toString() {
		return "HashCodeDemo {"+ "name='" + name +"'"+ ",age="+o+"}";
	}

public static void main(String[] args) {
	
	//HashCodeDemo类如果没有重写hashCode();返回一个随机地址
	HashCodeDemo hash1 =new HashCodeDemo();
	HashCodeDemo hash2 =new HashCodeDemo();
	 int n1 =hash1.hashCode();
	 int n2 =hash2.hashCode();
	 System.out.println("hash1地址："+hash1); //toString方法：Integer.toHexString(hashCode());
	 System.out.println("hash2地址："+hash2);
	 System.out.println("n1内容："+n1);
	 System.out.println("n2内容："+n2);
	 System.out.println("===============================================");
	 
	//String重写的hashCode();
	 String s1=new String("123");
	 String s2=new String("123");
	 System.out.println("s1:"+s1);
	 System.out.println("s2:"+s2);
	 System.out.println("s1.hashCode:"+s1.hashCode());
	 System.out.println("s2.hashCode:"+s2.hashCode());
	 System.out.println("===============================================");
	 
	 //HashSet自定义存储类型
	 HashSet<HashCodeDemo>hashset =new HashSet<>();
	 HashCodeDemo p1 =new HashCodeDemo("大力",16); //47
	 HashCodeDemo p2 =new HashCodeDemo("乔治",15); //46
	 HashCodeDemo p3 =new HashCodeDemo("大力",17); //48
	 HashCodeDemo p4 =new HashCodeDemo("小张",17); //48,哈希值重复了，不能重复，集合add不进去
	 hashset.add(p1);
	 hashset.add(p2);
	 hashset.add(p3);
	 hashset.add(p4);
	 System.out.println(p1.hashCode());
	 System.out.println(p2.hashCode());
	 System.out.println(p3.hashCode());
	 System.out.println(p4.hashCode());
	 System.out.println(hashset);
	 
}
}
