package accessPermission.Collection.Map;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

/*1. Interface Map<K,V>:键，值一一映射，键是唯一性的，值可以相同
 *2. 子类关系：
 *LinkedHashMap<k,v> extends HashMap<k,v> extends abstractMap<k,v> Implements Map
 *只有LinkedHashMap是有序的，其他是无序的
 *3.方法
 *  ① public V put (k,v);将指定的键与值放到Map中
 *  ② public V remove(Object key)；将指定的键对应的键值对删掉，返回被删掉元素的值
 *  ③ public V get(Object key);根据指定的键，在Map集合中找对应的值,返回value
 *  ④ boolean containsKey(Object key);判断集合是否含有指定的键
 *  ⑤ public set<K>set  map.keySet();获取Map中所有的键，存到Set集合中
 *  ⑥ public Set<Map.Entry<k,y>>entry= map.entrySet();获取集合中所有的键值对对象的集合（即Set集合）,
 *    Map.Entry<k,y>entry就是一个对象
 *    在对象entry所在的集合中： key =entry.getKey();  value =entry.getValue(); 
 *  ⑦ map.clear();   清除集合中所有的元素*/
public class Map_Interface {
private static void show1() {
	Map<String,Integer>map =new HashMap<>();

	map.put("黄球", 1);
	map.put("红球", 2);
	map.put("蓝球", 3);
	map.put("黑球", 4);
	map.put("绿球", 5);
	
	System.out.println("map: "+map);
	Integer int1=map.get("蓝球");
	System.out.println("\"篮球\"的value是:"+int1);
	map.remove("蓝球");
	System.out.println("removed_map: "+map);
	System.out.println("是否含有蓝球: "+map.containsKey("蓝球"));
	System.out.println("是否含有红球: "+map.containsKey("红球"));
	map.clear();
	System.out.println("cleared_map: "+map);
	
}
private static void show2() {
	Map<String,String>map =new LinkedHashMap<>();
	Set<String>set =new TreeSet<>();
	map.put("杨过", "小龙女");
	map.put("郭靖", "黄蓉");
    map.put("张无忌", "小昭");
    System.out.println(map);
    set =map.keySet();
    for(String key : set) {
    	String value =map.get(key);
    	System.out.println(key+"♥"+value);
    }
   System.out.println("========================================"); 
   Set<Map.Entry<String,String>>set1=map.entrySet();
   Iterator<Map.Entry<String, String>> it= set1.iterator();
   while(it.hasNext()){
	   Map.Entry<String,String>entry =it.next();
	   String key = entry.getKey();
	   String value = entry.getValue();
	   System.out.println(key+"💕😍"+value);
   }
    
}


public static void main(String[] args) {
	show1();
//	show2();
}
}
