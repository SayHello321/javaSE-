package accessPermission.Collection.Map;
/*Hashtable<K,V> implements Map<K,V>:
 *Hashtable:底层哈希表，线程安全，速度慢，不允许<null,null>;
 *HashMap:  底层哈希表，线程不安全，速度快，允许<null,null>;*/

import java.util.HashMap;
import java.util.Hashtable;

public class Hashtable_demo {
 public static void main(String[] args) {
	 
	 //hashMap
	 HashMap<Integer,Integer>hashmap=new HashMap<>();
	 hashmap.put(null,null);
	 hashmap.put(null,2);
	 hashmap.put(1,null);
	 System.out.println("HashMap:"+hashmap);
	 
	 //Hashtable
	 Hashtable<Integer,Integer>hashtable=new Hashtable<>();
		/* java.lang.NullPointerException
		 *  hashtable.put(null,null);
		 * hashtable.put(null,1);
		 * hashtable.put(1,null); */
	 hashtable.put(1,2);
	 System.out.println("Hashtable:"+hashtable);
	 
}

 
 
}
