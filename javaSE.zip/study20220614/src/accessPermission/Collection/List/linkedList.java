package accessPermission.Collection.List;

import java.util.LinkedList;

public class linkedList {

	private static void showList() {

		class mylink {
			void printList(LinkedList<String> link) {
				String link_string = new String();
				for (int i = 0; i < link.size(); i++) {
					link_string = link_string + link.get(i);
				}
				System.out.println("print_LinkedList: " + link_string);
			}
		}

		LinkedList<String> link = new LinkedList<>();
		link.add("b");
		link.add("a");
		link.add("i");
		link.add("d");
		link.add("u");
		System.out.println("LinkedList: " + link);

//		link.push("www."); //等同addFirst
		link.addFirst("www.");
		link.addLast(".com");
		System.out.println("LinkedList: " + link);
		new mylink().printList(link);

	}

	public static void main(String[] args) {
		showList();
	}

}
