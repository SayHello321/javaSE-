package accessPermission.Collection.List;
/*List:
 * list.add(int index,E element); 往集合中添加指定index位置元素  
 *      addFisrt();
 *      addLast();
 * list.push(E,e);将元素推入此列表所表示的堆栈,等效addFisrt();
 * list.pop(); 从此列表所表示的堆栈中弹出一个元素，等效removeFirst();
 * list.remove(int index);  删除集合指定索引位置的元素
 * list.removeFisrt(); 返回列表的第一个元素
 * list.removeLast();  返回列表的最后一个元素
 *      Arrays.asList(T...a);
 * list.set(int index,E element); 替代指定index位置的元素
 * list.get(int index);
 *      getFirst();
 *      getLast();
 *JDK9: of方法适用于List接口，Set接口，Map接口，不适用接口的实现类
 *   用法：List<String>list=List.of("a","b","c","d");
 **/
import java.util.ArrayList;
import java.util.List;

public class List_Interface {
public static void main(String[] args) {
	List<Integer>list = new ArrayList<>();
	list.add(5);
	list.add(4);
	list.add(2);
	list.add(1);
	System.out.println("list.get()："+list.get(1));
	System.out.println("list: "+list);
	//inex:2处添加元素3
	list.add(2, 3);
	System.out.println("list添加元素："+list);
	//移除index:4的元素，1
	list.remove(4);
	System.out.println("list删除元素："+list);
	//set index3为6
	list.set(3,6);
	System.out.println("list.set元素："+list);
	
	System.out.println("for_each循环遍历集合:");
	for(Integer s:list) {			
		System.out.println(s);
	}
}
}
