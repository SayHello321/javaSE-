package accessPermission.Enum;

public class startMode {
enum Mode{DEVICE,MCU};
static Mode mode;
public static void main(String[] args) {
	startMode s =new startMode();
	s.mode =s.mode.DEVICE;
	System.out.println(s.mode.DEVICE);
//	startMode.mode =startMode.Mode.DEVICE;
}
}
