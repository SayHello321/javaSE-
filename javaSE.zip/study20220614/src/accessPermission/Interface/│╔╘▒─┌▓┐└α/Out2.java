package accessPermission.Interface.成员内部类;
/*②局部内部类中的匿名内部类：
 * 用法如下：*/
public interface Out2 {

	void method();  //抽象方法，省略public abstract
}
