package accessPermission.Interface.成员内部类;
/* ①成员内部类 使用如下：
 * 1、间接方式：在外部类方法中使用内部类，然后main调用外部类方法
 * 2、直接方式：格式：  外部类名称.内部类名称 对象名 =new 外部类名称（）.new 内部类名称（）；
 * /*/

//成员内部类
public class Body { 
	
    private String name;
	public void outsideMethod() {  //成员内部类方法
		System.out.println("外部类方法执行！");
		System.out.println("我叫："+name);
		heart hea =new heart();
//		hea.insideMethod();//调用内部类方法
	}
	public Body() {}
    public Body(String name) {
    	this.name=name;
    }
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	 //内部类
	public class heart{ 
		public void insideMethod() { //内部类方法		
        System.out.println("内部类方法执行！");
        outsideMethod();//调用外部类方法
		}
	}
	
	public static void main(String[] args) {
		Body body =new Body("张何");
        body.outsideMethod();
        System.out.println("===========================");
        Body.heart heart=new Body().new heart();
        heart.insideMethod();
	}
}
