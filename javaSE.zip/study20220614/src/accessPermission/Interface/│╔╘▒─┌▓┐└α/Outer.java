package accessPermission.Interface.成员内部类;
/*内部类同名变量访问*/
public class Outer {
	
    int num=10; //外部类成员变量
    
	public class Inner {
		
		int num =20; //内部类成员变量
		
		void innerMethod() {
			int num =30; //内部类局部变量
			System.out.println("局部变量: "+num);//30,局部变量
			System.out.println("内部类成员变量: "+this.num);//20,内部类成员变量
			System.out.println("外部类成员变量: "+Outer.this.num);//10,外部类成员变量,不能用super,内外类没有继承关系
		}
	}
	
	public static void main(String[] args) {
		// 外部类名称.内部类名称 对象名 =new 外部类名称（）.new 内部类名称（）；
		Outer.Inner In=new Outer().new Inner();
		
		In.innerMethod();
	}
	
	
	
}
