package accessPermission.Interface.成员内部类;

/*注意：如果接口的实现类（或者父类的子类），只需使用唯一的一次
 * ，这种情况下可以省略该类的定义，直接使用【匿名内部类】
 * 格式 接口名 实现类对象名 =new 实现类名称（）；
 *     接口名称 对象名 =new 接口名称（）{
 *     //覆盖重写所有抽象方法} */
public  class implementsOut2 implements Out2{

	@Override
	public void method() {
		System.out.println("2、实现类重写接口\"Out2\"方法");
		
	}

	public static void main(String[] args) {
		//1、通过接口调用实现类方法
		Out2 out2Imp=new implementsOut2();
		out2Imp.method();
		
		//2、通过实现类调用实现类方法
		implementsOut2 imp=new implementsOut2();
		imp.method();
		
		//3、使用匿名内部类
		Out2 obj=new Out2() {  //new Out2()，new 的interface就相当于一个类，还是局部的，所以叫匿名内部类
			@Override
			public void method() {
				System.out.println("3、匿名内部类重写了接口中的方法2");
				
			}	
		};
		
		obj.method();

		
		//4、使用匿名内部类,省略对象	
		
		new Out2() {  //new Out2()，new 的interface就相当于一个类，还是局部的，所以叫匿名内部类
			@Override
			public void method() {
				System.out.println("4、匿名内部类重写了接口中的方法");
				
			}	
		}.method();
		
		
	}
	  
}
