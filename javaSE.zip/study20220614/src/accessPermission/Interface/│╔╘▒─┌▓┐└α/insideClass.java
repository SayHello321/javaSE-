package accessPermission.Interface.成员内部类;
/*内部类，比如身体和心脏的关系
 * 1、内部类的分类：
 *    ①成员内部类：格式如下
 *    修饰符 class 外部类名称{
 *        修饰符 class 内部类名称{
 *        代码块  }
 *        代码块
 *        }
 *   注意：内部类随意访问外部类，外部类访问内部类一定要引用内部类对象
 *    ②局部内部类（包含匿名内部类）：*/
public class insideClass {
  
	
	
	
}
