package accessPermission.Interface.成员内部类;
/*②局部内部类：定义在方法内部类的，出了方法就不能用了
 * 定义格式：public class 外部类名称{
 *    修饰符 返回值类型 外部类方法名（参数裂变）{
 *       class 局部类名称{}
 *    }  
 * }
 * */
public class Out1 {

	 public void OutMethod() {
		 /*方法局部变量，只要事实不变final关键字可以省略，class local只是copy了其堆中的内容 num=1会持续存在，
		  * 直到垃圾回收消失,这样解决了生命周期问题 */
		 int num =1; 
		 
		 System.out.println("OutMethod_num: "+num);//1,外部类局部变量
		 class local{  //任何修饰符都不能写
			 int num =2;
			 void localMethod() {
				 System.out.println("localMethod_num: "+num);
			 }
			 
		 }
		
		 local local=new local();
		 local.localMethod();
	 }
	
	 
public static void main(String[] args) {
	Out1 out1 =new Out1();
	out1.OutMethod();
}
}
