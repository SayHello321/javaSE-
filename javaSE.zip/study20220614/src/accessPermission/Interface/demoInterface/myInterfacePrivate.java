package accessPermission.Interface.demoInterface;
/*
 * 从JAVA9开始(目前是java8 )，interface允许定义private方法
 * 1、普通私有方法，解决各个默认方法之间的重复代码问题
 * 格式：private 返回值类型 方法名称（参数列表）{方法体}
 * 2、静态私有方法：解决多个静态间重复代码问题 
 * 格式：private static 返回值类型 方法名称（参数列表）{方法体} */
/*public interface myInterfacePrivate {
//public default void method1() {
//	System.out.println("实现功能1");
//	System.out.println("实现功能2");
//	System.out.println("实现功能3");
//}
private static void method1() {
	System.out.println("实现功能1");
	System.out.println("实现功能2");
	System.out.println("实现功能3");
}
public static void method2() {
	method1();
	System.out.println("实现功能4");
	
}
public static void method3() {
	method1();
	method2();
}
}
*/