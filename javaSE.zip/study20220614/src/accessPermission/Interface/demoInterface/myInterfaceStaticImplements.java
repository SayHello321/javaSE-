package accessPermission.Interface.demoInterface;

public class myInterfaceStaticImplements implements myInterfaceStatic{
//interface中没有抽象方法，没必要覆盖重写
}
