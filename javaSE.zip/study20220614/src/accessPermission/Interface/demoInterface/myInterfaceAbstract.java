package accessPermission.Interface.demoInterface;
/*1、接口是引用数据类型（基本、引用）
 *2、接口定义格式 public interface 接口名字{接口内容}
 *3、接口内容（5个）：常量（java7）、抽象方法(java7)、默认方法(java8)、静态方法(java8)、私有方法（JAVA9才有）  
 *4、接口的使用步骤：
 * ①接口不能直接使用，必须有一个“实现”类，格式： public class 类名 implements 接口名称  
 * ②接口的实现类必须覆盖重写接口中的抽象方法
 * ③创建实现类的对象，开始使用*/

public interface myInterfaceAbstract {
 //抽象方法
 public abstract void method1();
 //抽象方法
 abstract void method2();
 //返回值为接口类型的抽象方法
 public void method3();
 //抽象方法
 void method4();
}
