package accessPermission.Interface.demoInterface;

public class myInterfaceDefaultImplements1 implements myInterfaceDefault{

	@Override
	public void default2() {
		// TODO Auto-generated method stub
		myInterfaceDefault.super.default2(); //继承default2（）方法
		System.out.println("实现类implement_1覆盖重写default方法");
	}

	@Override
	public void method1() {
	System.out.println("实现抽象方法，implements_1");
		
	}
 
}
