 package accessPermission.Interface.demoInterface;
/*1、默认方法，从java8允许定义：
 * 格式：public default 返回值类型 方法名称（参数列表）
 * 备注：接口中的默认方法可以解决接口升级问题
 *2、接口默认方法通过接口实现类直接调用
 *   接口的默认方法也可以被接口的实现类覆盖*/
public interface myInterfaceDefault {
	 //新添加的默认方法
	 public default  void default2() {
		 System.out.println("新添加的default()方法");
	 }
	 
	 public abstract void method1();
}
