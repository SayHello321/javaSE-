package accessPermission.Interface.demoInterface;
/*接口中也可以定义"成员变量"，但必须使用 public static final 三个关键字修饰，即【常量】
 * 1、格式：public static final 数据类型 常量名称 =数据值；
 * 注意：①接口中public static final 关键字可以省略，省略后还是常量;
 *     ②一旦定义，值不可改变,且变量必须手动赋值;
 *     ③接口常量的命名一般用大写，下划线分隔； */
public interface myInterfaceConst {
public static final int NUM_CP =10;//一旦定义，值不可改变,且变量必须手动赋值
int NUM_EDGE =15 ;//仍然是常量,而且还是静态
public static void main(String[] args) {
	System.out.println(myInterfaceConst.NUM_CP);
	System.out.println(myInterfaceConst.NUM_EDGE);
}
}
