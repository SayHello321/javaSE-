package accessPermission.Interface.demoInterface;

public class demomain {

	public static void main(String[] args) throws NullPointerException{
		myInterfaceDefaultImplements1 su1=new myInterfaceDefaultImplements1();		
		su1.method1();
		su1.default2();//实现类implement_1覆盖重写default方法
		System.out.println("1、________________________________________________________________________");		
		myInterfaceDefaultImplements2 su2=new myInterfaceDefaultImplements2();
		su2.method1();
		su2.default2(); //新添加的default()方法
		System.out.println("2、________________________________________________________________________");	
		//类中接口中方法的调用
		
	}
}
