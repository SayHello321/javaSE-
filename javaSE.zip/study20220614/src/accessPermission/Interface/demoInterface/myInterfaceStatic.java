 package accessPermission.Interface.demoInterface;
/*java8开始可以使用接口静态方法：
 *1、 格式：public static 返回值类型 方法名称 （参数列表）{方法体}
 *2、注意：不能通过实现类调用方法，直接用interface直接调用即可
 *   格式：interface名称.静态方法名 */
public interface myInterfaceStatic {
public static void main(String[] args) {
	myInterfaceStatic.staticMethod();
}
public static void staticMethod() {
	System.out.println("interface staticMethod excute!");
}
}
