package accessPermission.Interface.demoInterface;
/* 抽象方法两个固定关键字 public  abstract，可以选择性地省略
 * 格式： public abstract 返回值类型 方法名字 参数列表;
 * */
public  class myInterfaceAbstractImplements implements myInterfaceAbstract{
public static void main(String[]args){
	myInterfaceAbstractImplements inter = new myInterfaceAbstractImplements();
	inter.method1();
	inter.method2();
	inter.method3();
	inter.method4();
	
}
/*所有抽象方法覆盖重写，接口方法实现如下：
//注意：1.但凡有一个抽象方法没有覆盖重写，实现类就要是abstract抽象类
	  2.父类是唯一的，但可以实现多个接口，实现类可以继承重写多个类相同的方法，只需覆盖重写一次；
	  3.接口中extends父类中的方法与接口implements冲突时，父类方法优先，比如：Zi extends Fu implements interfaceA；
	  4.接口是多继承的，比如interface extends interfaceA,interfaceB，多个父接口中的抽象方法重复可以，
	    多个父接口中的默认方法重复不行，会报错；
	  */
@Override
public  void method1() {
	System.out.println("method1 excute!");
}
@Override
public void method2() {
	System.out.println("method2 excute!");
}
@Override
public void method3() {
	System.out.println("method3 excute!");
	
}

@Override
public void method4() {
	System.out.println("method4 excute!");
	
}

}
