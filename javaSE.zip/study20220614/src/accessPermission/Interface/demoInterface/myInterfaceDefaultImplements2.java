package accessPermission.Interface.demoInterface;

public class myInterfaceDefaultImplements2 implements myInterfaceDefault {

	@Override
	public void method1() {
		System.out.println("抽象方法实现，implements_2");
	}
	//这里没有覆盖重写default2();

}
