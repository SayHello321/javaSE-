package accessPermission.Interface.demoInterface;
/*
public class myInterfacePrivateImplement implements myInterfacePrivate{

	public void method4() {
		//method1();直接访问接口中的默认方法，错误！！！
	}
	public static void main(String[] args) {
		myInterfacePrivate.method2();
		myInterfacePrivate.method3();
	}
} 
*/