package accessPermission.Interface.接口作为方法参数或者返回值;

import java.util.ArrayList;
import java.util.List;
/*java.util.List是java.util.ArrayList的实现类接口*/
public class interfaceList {
	
	public static List<String> addName(List<String> list) {
		list.add("小叮当");
		list.add("大雄");
		list.add("小明");
		return list;
	}
	
	public static void main(String[] args) {
		//左边是接口，右边是实现类名称，多态写法
		List<String>list=new ArrayList<>();
		List<String>Name=addName(list);
		for(int i =0;i<Name.size();i++) {
			System.out.println(Name.get(i));
		}
	}
}
