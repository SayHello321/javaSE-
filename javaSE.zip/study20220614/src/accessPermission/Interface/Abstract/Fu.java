package accessPermission.Interface.Abstract;
/*注意事项：
 * 1、抽象类不能创建对象，只能创建非抽象子类对象
 * 2、抽象类中，可以有构造方法，是供子类创建对象，初始化父类成员使用的
 * 3、抽象类中不一定有抽象方法（可以理解为抽象类中可以有普通方法），但是抽象方法必有抽象类
 * 抽象类的子类必须重写父类中所有的抽象方法,否则编译器无法识别抽象方法属于哪个类*/
public abstract class Fu {
	public Fu()	{
		 System.out.println("抽象父类构造函数执行 ");
	}
	
//抽象方法
public abstract void eat();
//构造方法
public void say() {
	System.out.println("我是爸爸");
}
{System.out.println("父类代码块执行");}
}
