 package accessPermission.Interface.Abstract;

public class Zi extends Fu {
	public static void main(String[]args) {
		Zi zi =new Zi();
		zi.eat();
		zi.say();
		
		//向上转型
		Fu fu =new Zi();
		fu.say();
		//向下转型
		Zi zi1=(Zi)fu;
		zi1.excute();
	}
public Zi() {
	System.out.println("子类构造函数执行");
}
@Override 
public void eat() {
	System.out.println("子类覆盖重写父类eat() ");
}
@Override
public void say() {
	System.out.println("我是儿子");
}
void excute(){
	System.out.println("子类特有方法执行！");
}
{System.out.println("子类代码块执行");}
}
