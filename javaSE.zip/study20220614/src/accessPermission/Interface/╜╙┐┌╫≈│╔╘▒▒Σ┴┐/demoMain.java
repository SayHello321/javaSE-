package accessPermission.Interface.接口作成员变量;

public class demoMain {

	 public static void main(String[] args) {
		 Hero hero =new Hero();
		 hero.setName("亚瑟");   //给英雄设置名字
		 hero.setSkill(null);
		 
		 Skill skill =new Skill() {  //使用匿名局部内部类,写一个实现类实现方法use();
			 @Override 
			public void use() {
				System.out.print("王者圣剑！");
			 }
		 };
		
	 hero.setSkill(skill);	//给英雄配置技能
	 hero.attack();	 //开始攻击
	}
}
