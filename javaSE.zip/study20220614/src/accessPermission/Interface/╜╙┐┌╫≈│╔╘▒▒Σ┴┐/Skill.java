package accessPermission.Interface.接口作成员变量;

public interface Skill {
void use();
}
