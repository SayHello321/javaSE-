package accessPermission.Date;
/*1. String s =Format(Date date); 将日期转换字符串
 *2. Date date=sdf.parse(String source);把字符串日期转换成date日期
 *3. DateFormat是一个抽象类，无法创建对象，可以使用其子类：SimpleDateFormat  sdf=new SimpleDateFormat();
 *  String time=sdf.format(date);
 *4. 单位：年月日时分秒、毫秒：y M d H m s S
 *   传入模式 "yyyy-MM-dd HH:mm:ss" 或者 "yyyy年MM月dd日 HH时mm分ss秒"
 * */

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class dateFormat {
	/*将日期转换成文本字符串*/
	private static void date1() {
		//创建SimpleDateFormat对象->创建一个日期->format->打印
		SimpleDateFormat  sdf1=new SimpleDateFormat();//默认为本地时间格式
		SimpleDateFormat  sdf2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//指定模式"yyyy-MM-dd HH:mm:ss"
		SimpleDateFormat  sdf3=new SimpleDateFormat("yyyy年MM月dd日 HH时mm分ss秒");//指定模式"yyyy年MM月dd日 HH时mm分ss秒"
		Date date =new Date();
		String text1 =sdf1.format(date);
		String text2 =sdf2.format(date);
		String text3 =sdf3.format(date); 
        System.out.println("本地时间格式：                 "+text1);
        System.out.println("yyyy-MM-dd HH:mm:ss       "+text2);
        System.out.println("yyyy年MM月dd日 HH时mm分ss秒   "+text3);
	}
	
	/*将文本解析为日期*/
	
	private static void date2() throws ParseException {
		
		SimpleDateFormat  sdf=new SimpleDateFormat("yyyy年MM月dd日 HH时mm分ss秒");
		Date date =sdf.parse("2021年11月25日 10时32分27秒"); //parse解析异常,添加throws抛出异常，要么try ..catch 处理
		 System.out.println("文本解析为日期：  "+date);
	}
	public static void main(String[] args) throws ParseException {
		date1();
		date2();
	}

}
