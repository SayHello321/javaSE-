package accessPermission.Date;

import java.util.Date;

/*date - 1970年1月1日以来的毫秒，GMT 00:00:00不超过8099的毫秒表示。负数表示1970年1月1日00:00:00 GMT（英国格林威治时间）之前的毫秒数。
 * 毫秒：千分之一秒
 * 注意：中国是东巴区，会把时间加8小时 表示1970年1月1日08:00:00 CST(china standard time)
 *时间原点： 1970年1月1日00:00:00以来的指定毫秒数
 *当前时间2021-11-24 21：11：55：344
 *1天=86400秒=86400*1000毫秒=86400000毫秒
 *方法 long getTime();
 *    String toLocaleString();根据本地格式转换日期对象
 *    String toGMTString() ; （英国格林威治时间）*/

public class demoDate {

	private static void cstDate1() {
		Date date = new Date();
		System.out.println("空参构造Date : " + date);
	}
   private static void cstDate2() {
	Date date =new  Date(0L);//0毫秒，也就是1970年1月1日00:00:00，这里加了8h
	System.out.println("带毫秒数long有参构造Date : " + date);
}
   private static void cstDate3() {
	   Date date = new Date();
	   long time=date.getTime();
	   System.out.println("把当前日期转换为long毫秒数："+time);
	   String strTime=date.toLocaleString();
	   System.out.println("本地时间格式： "+strTime);
   }
	public static void main(String[] args) {
		System.out.println("系统当前时间(毫秒数)： "+System.currentTimeMillis());// 从原点时间到系统目前时间走了多少毫秒：1637754636013L
		cstDate1();
		cstDate2();
		cstDate3();
	}
}
