package accessPermission.Date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class birthday {
//计算一个人活了多少天
	public static long[] liveTime() throws ParseException {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("请在下方输入您的生日，格式为：yyyy年MM月dd日，按enter键结束！");
		String birthday = sc.next();
		sc.close();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
		
		Date date = sdf.parse(birthday);
		long birthdayTime = date.getTime();
		long todayTime = new Date().getTime();
		long Year=(todayTime - birthdayTime) / 1000 / 3600 / 24 / 365;
		long Month=(todayTime - birthdayTime) / 1000 / 3600 / 24 / 12;
		long Day = (todayTime - birthdayTime) / 1000 / 3600 / 24;
		long Hour = (todayTime - birthdayTime) / 1000 / 3600 ;
		long minute = (todayTime - birthdayTime) / 1000 / 60;
		long second = (todayTime - birthdayTime) / 1000 ;
		long [] liveTime=new long[]{Year,Month,Day,Hour,minute,second };
		
		return liveTime;
	}
	
	public static void main(String[] args) throws ParseException {
		long[] arr =liveTime();
		System.out.println("您的一生一共走过了"+arr[0]+"个春秋！");
		System.out.println(arr[1]+"个月！");
		System.out.println(arr[2]+"个日夜！");
		System.out.println(arr[3]+"个小时！");
		System.out.println(arr[4]+"分钟！");
		System.out.println(arr[5]+"秒！");
		System.out.println("且行且珍惜！");
	}
}
