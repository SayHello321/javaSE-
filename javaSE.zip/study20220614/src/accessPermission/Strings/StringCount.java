package accessPermission.Strings;
/*1. char Character.toLowerCase(char ch);  返回转换后字符的小写形式，如果有的话；否则返回字符本身。
 *   toLowerCase();将字符串大写转成小写
 *2. char Character.toUpperCase(char ch);
 *   toUpperCase(); 将字符小写转成大写
 * */
import java.util.Scanner;

public class StringCount {
	static int countUpper=0;
	static int countLower=0;
	static int countNumber=0;
	static int countOther=0;
	public static void main(String[]args){	
	Scanner sc =new Scanner(System.in);
	System.out.println("提示：请输入一个字符串，按enter键结束！");
	String intput =sc.next();
	char[] charArray=intput.toCharArray();
	for(int i=0;i<charArray.length;i++) {
		char ch =charArray[i];
		if('A'<=ch&ch<='Z') {
			countUpper++;}
		 else if('a'<=ch&ch<='z'){
			 countLower++;}
		 else if('0'<=ch&ch<='9'){
			 countNumber++;}
		 else {
			 countOther++;}	
	}
//**************************************************	
	System.out.println("大写字母有"+countUpper+"个");
	System.out.println("小写字母有"+countLower+"个");
	System.out.println("数字有"+countNumber+"个");
	System.out.println("其他字符有"+countOther+"个");
	
	}
}
