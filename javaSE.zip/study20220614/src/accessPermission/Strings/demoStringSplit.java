package accessPermission.Strings;
/**/
public class demoStringSplit {
	public static int[] arraya= {1,2,3};
/**change array to String
 * @param array
 * @return  {@code STR}
 */
 public static String arrayToString(int[]array) {//int数组以字符串的方式打印
 String STR = "[";
  for(int j=0;j<array.length;j++){
	  if(j==array.length-1) {
		  STR+="number"+array[j]+"]";  
	  }
	  else {
    STR+="number"+array[j]+"#";}
    
  }
  return STR;
 }
    public static void main(String[]args){
		String str1 ="1101";
		String str2 ="aa.bb.cc";
		String str3 ="aa,bb,cc";
		String[] array1=str1.split("");
		int[] array1_1=stringToIntArray(array1);
		System.out.println(array1_1[0]);
		System.out.println(array1_1[1]);
		System.out.println(array1_1[2]);
		System.out.println(array1_1[3]);
//		String[] array2=str2.split("\\.");
//		String[] array3=str3.split(",");
//		StringArrayprint(array1);
//		StringArrayprint(array2);
//		StringArrayprint(array3);
//		
		arrayToString(arraya);
//		System.out.println(arrayToString(arraya));
	} 
 /*split	regex:regular expression 正则表达式 
 * 1.英文“. ”用split("\\.")分割
 * 2.var str = "123abc";
 *   var patt1 = /^[0-9]+abc$/;  ^是字符串开始位置，$是字符串结束位置，[0-9]匹配单个数字，[9]+匹配多个数字
 *   document.write(str.match(patt1));
 * 
 * 
 * 
 * */  public static void StringArrayprint(String[]array) {
		
	  for(int j=0;j<array.length;j++){
		   if(j==0){
			   System.out.print("Print_Array: ["+array[0]+",");
		   }
			else if(j==array.length-1){
				System.out.println(array[array.length-1]+"]");
				
			}
			else{
				System.out.print(array[j]+",");
			}
			
			}
	  
 }
	public static int [] stringToIntArray(String[] arr) {//字符串数组转成int数组
		 int[] array=new int[arr.length];
		 for(int i=0;i<arr.length;i++) {
			 array[i]=Integer.parseInt(arr[i]);
		 }
		 return array;
	 }
}
