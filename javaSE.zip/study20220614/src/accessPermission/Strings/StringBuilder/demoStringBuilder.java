package accessPermission.Strings.StringBuilder;
/*1.final String 是常量， 底层：private final byte[]value，被final修饰不可更改，
 * StringBuilder 缓冲区字符串数组，可按照16、32、64扩容，底层：private byte[]value =new value[16],没被final修饰可以更改，; 
 * 2.StringBuilder构造方法
 *   StringBuilder();
 *   StringBuilder(String s);
 * 3.append方法;
 *   reverse();反转字符串
 *   toString();将缓冲区内容转换成字符串；
 * 
 * */

/*1.除Character,字符串->基本数据类型：
 * public static int parseInt(String s);
 * public static byte parseByte(String s);
 * public static long parseLong(String s);
 * public static long parseLong(String s,index x); 
 *   ...
 *2.基本数据类型->字符串
 * ① String s = 1+"";
 * ② String s =Integer.toString(int i);
 * ③ String s =String.valueof(int i);   
 * */
public class demoStringBuilder {
	
  public static void StringBUilder() {
	  StringBuilder str=new StringBuilder();
	  StringBuilder str1=new StringBuilder("abcDEF");	  
	  System.out.println(str.capacity());
	  System.out.println(str1);
	  str1.reverse();
	  System.out.println("str1_reverse: "+str1 ); 
//	  str.append("牡丹花");
//	  str.append(1.3);
//	  str.append(true);	
	  str.append("牡丹花").append(1.3).append(true);//链式编程
      System.out.println("str: "+str);  
	  String s =str.toString();
	  System.out.println("s: "+s);
	  
}
  
  public static void main(String[] args) {
//	  StringBUilder();
	 //String与StringBuilder之间的转换
	 String str = "10011100";
	 System.out.println("str: "+str);  
	 String[] string= str.split(",");
	 StringBuilder SB=new StringBuilder();
	 for (int i = 0; i < string.length; i++) {		 
		 SB.append(string[i]);
	}
	 System.out.println("SB: "+SB);  
	 String str2=SB.toString();
	 System.out.println("str2: "+str2); 
	 System.out.println("equals? :"+str.equals(SB.toString()) );
	 System.out.println("==? :"+str==str2 ); //==是引用数据类型，String与StringBuilder值相同，地址不同，所以返回false
}
}
