package accessPermission.Strings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import accessPermission.Arrays.Arrays.demoArrays;

/*String方法摘要：
 * 1.字符串.split("");和字符串.toCharArray(array);都可以将字符串转化为数组
 * 2.字符串截取：substring(beginIndex,endIndex); 
 *           substring(beginIndex); 
 * 3.字符串替换：replace(String oldChar ,String newChar);
 *           replaceFirst(String oldChar ,String newChar);
 * 4.sort排序优先级：数字>大写字母>小写字母
 * 5.String.format(String format , Object ...args)
 *   比如format("0x%08x",变量)
   6. 原字符串打印：System.out.println("\"字符串\"");*/
public class demoString extends demoStringSplit {
	void show() {
		String str1 = new String();
		String str2 = "ba";
		char[] c1 = { 'b', 'a', 'o' };
		byte[] b1 = { 98, 97, 111 };
		String str3 = new String(c1);
		String str4 = new String(b1);
		String str5 = "bao";
		String str5_1 = "baoo";
		String str6 = "你大爷的！";
		System.out.println("str5_1: " + str5_1);
		System.out.println("str1: " + str1);
		System.out.println("str2: " + str2);
		System.out.println("str2字符串长度: " + str2.length());
		System.out.println("c1: " + c1);
		System.out.println("b1: " + b1);
		System.out.println("str3: " + str3);
		System.out.println("b1: " + str4);
		System.out.println("BA".equals(str2));
		System.out.println("bao".equals(str2 + "o"));
		System.out.println(str5.equals(str2 + "o"));
		System.out.println(arrayToString(arraya));
		System.out.println("************************************");
		System.out.println("将字符串升序排序，倒序打印:");
		System.out.println("************************************");
		System.out.println("替换\"大爷\"字符: " + str6.replace("大爷", "**"));
		String sd = "acbd4325BCA"; // sort排序优先级：数字>大写字母>小写字母
		String sdp1 = sd.substring(8);// 截取"BCA"
		String sdp2 = sd.substring(4, 8);// 截取"4325"

		char[] char1 = sd.toCharArray();
		String[] char2 = sd.split("");
		Arrays.sort(char1);
		for (int i = char1.length - 1; i >= 0; i--) {
			System.out.print(char1[i]);
		}
		System.out.println("");
		for (int i = 0; i < char2.length; i++) {
			System.out.print(char2[i]);
		}
		System.out.println("");
		System.out.println("*******************************************");
		System.out.println("截取\"BCA\": " + sdp1);
		System.out.println("截取\"4325\": " + sdp2);
	}
    public static  Object[] arrayReverse(Object[]array) {
    	List<Object>list =new ArrayList<>();
    	for (int i = 0; i < array.length; i++) {
			list.add(array[array.length-1-i]);
		}
    	Object[] arr =list.toArray();
    	return arr;
    }
	public static String StringReverse1(String s) {
		char[] c = s.toCharArray();
		char[] c1 = new char[c.length];
		for (int i = 0; i < c.length; i++) {
			c1[i] = c[c.length - 1 - i];
		}

		return new String(c1);
	}

	public static String StringReverse(String s) {

		char[] c = s.toCharArray();
		for (int i=0,j = c.length-1; i<j; i++,j--) {
		char x =c[i];
		c[i]=c[j];
		c[j]=x;

		}
		return new String(c);
	}
  public static void demo_join() {
	  List<String>list=List.of("刘","关","张");
	  String s =String.join("+", list);
	  System.out.println(s);

  }

	/*
	 * %x代表16进制输出的字母符号为小写,%X为大写 
	 * 08指定数据的最小输出位数为8，若不够8位，则补零，若大于8位，则按照原位数输出
	 * #代表的是在字符串前面加上0x,占2个输出位
	 */
  public static void format() {
	    int i = 7;	     
	    String s1 =String.format("%#010x\n", i);  // gives 0x00000007
	    String s2 =String.format("0x%08x\n", i);  // gives 0x00000007
	    String s3 =String.format("%#08x\n", i);   // gives 0x000007
	    String s4 =String.format("%04x", 4779); // gives 12ab
	    String s5 =String.format("%04X", 4779); // gives 12AB
	    System.out.println(s1);
	    System.out.println(s2);
	    System.out.println(s3);
	    System.out.println(s4);
	    System.out.println(s5);
  }
	public static void main(String[] args) {		
		int[] a = {2,3,4};
		demoArrays.printArray(a);
		System.out.println(StringReverse1("1234567@#$%%"));
		demo_join();
		format();
		
	}
}
