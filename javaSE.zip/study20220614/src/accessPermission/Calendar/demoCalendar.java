package accessPermission.Calendar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/*1.Calender类：日历类，抽象类，直接子类GregorianCalendar，必须调用子类抽象方法才能使用
 * Calendar c =Calendar.getInstance(); 
 *2.Calendar 成员方法 
 * public int get(int field) 返回指定日历字段的值
 * public void set(int field ,int value) 将指定的日历字段设置为给定值
 * public abstract void add(int field ,int amount) 根据日历规则，添加或减去指定时间
 * public Date getTime();把日历转成日期 Date的对象
 * 成员方法参数 YEAR=1;年
 *          MONTH=2;月
 *          DATE=5;月中的某一天
 *          DAY_OF_MONTH = 5;月中的某一天
 *          HOUR =10; 时
 *          MINUTE =12; 分
 *          SECOND =13; 秒
 *3.西方：（0~11月），中国（1~12月）          
 * */

public class demoCalendar {

	private static void demo1() {
		Calendar c = Calendar.getInstance();// 多态
		System.out.println("日历信息： " + c);
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);
		System.out.println("年: " + year);
		System.out.println("月: " + month);
		System.out.println("月中的某一天：" + day);
	}

	private static void demo2() {
		Calendar c = Calendar.getInstance();// 多态
		// 设置年
		c.set(Calendar.YEAR, 2025);
		// 设置月
		c.set(Calendar.MONTH, 10);
		// 设置日
		c.set(Calendar.DATE, 24);
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);
		System.out.println(year + "年" + month + "月" + day + "日");

		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy年MM月dd日");// 未定义格式的部分用系统时间
		Date date = c.getTime();
		String time = sdf1.format(date);
		System.out.println(time);
	}

	private static void demo3() {
		Calendar c = Calendar.getInstance();// 多态
		 c.add(Calendar.YEAR, 2);
		 c.add(Calendar.YEAR, -3);//YEAR:2-3=-1 ,2021-1=2020年
		 int year = c.get(Calendar.YEAR);
		 System.out.println(year + "年");
	}
	public static void main(String[] args) {
    	demo1();
		demo2();
		demo3();
	}
}
