package accessPermission.PackageClass;
/*1.除Character,字符串->基本数据类型：
 * public static int parseInt(String s);
 * public static byte parseByte(String s);
 * public static long parseLong(String s);
 * public static long parseLong(String s,index x); 
 *   ...
 *2.基本数据类型->字符串
 * ① String s = 1+"";
 * ② String s =Integer.toString(int i);
 * ③ String s =String.valueof(int i);   
 * */
public class demoParse {
	public static void intToCharPrint(int input) {
		String s =String.valueOf(input);
		System.out.println(s);
		char[] c =String.valueOf(input).toCharArray();
		StringBuilder sb =new StringBuilder();
		for(int i =0;i<c.length;i++) {
			sb.append(c[i]);
		}
		System.out.println(sb);
		System.out.println(c[0]);
	}
public static void main(String[] args) {
//	int int1=Integer.parseInt("99");//非字母
//    long long1=Long.parseLong("ff", 16);//16进制
//	
//	String s1= 15+"";
//	String s2= 15+""+200;
//	String s3=Integer.toString(10);
//	String s4=String.valueOf(16);
//	
//	System.out.println("int1: "+int1);
//	System.out.println("long1: "+long1);
//    System.out.println(s1);
//    System.out.println(s2);
//    System.out.println(s3);
//    System.out.println(s4);
    intToCharPrint(0x1f);
    String s= "1101";
    System.out.println(s.substring(2));
 }
}
