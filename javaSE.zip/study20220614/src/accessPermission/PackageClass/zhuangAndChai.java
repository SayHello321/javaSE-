package accessPermission.PackageClass;

import java.util.ArrayList;

/*1.基本数据类型： byte short int      long float double char        boolean
 *      包装类： Byte Short Integer  Long Float Double Character   Boolean
 *2.装箱：基本数据->包装类
 *  构造方法：
 *  new Integer(int value) ;返回Integer实例 //Integer toString()被重写
 *  new Integer(String s); s必须是int 对应的数，如："11" ,"12"  
 *  成员方法：
 *  static Integer valueof(int i);
 *  static Integer valueof(String s);
 *3.拆箱：包装类->基本数据
 *   成员方法：
 *   int Integer对象.intvalue();  */
public class zhuangAndChai {
      public static void main(String[] args) {
		Integer int1 =new Integer("100");//装箱
		int int2= int1.intValue();//拆箱
		Integer int3=3;//自动装箱
		Integer int4=int3+1;//相当于new Integer(int3.intValue()+1);
//		Integer int4=new Integer(int3.intValue()+1);
		
		ArrayList<Integer>list = new ArrayList<>(); 
		list.add(150);
		int int5 =list.get(0); //自动拆箱，相当于list.get(0).intValue();
	

		System.out.println("装箱："+int1); //toString在Integer中被重写
		System.out.println("拆箱："+int2);
		System.out.println("自动装箱："+int3);
		System.out.println("自动装箱："+int4);
		System.out.println("自动拆箱："+int5);
	}
}
