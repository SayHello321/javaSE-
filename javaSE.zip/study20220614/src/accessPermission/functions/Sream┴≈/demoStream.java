package accessPermission.functions.Sream流;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/*  interface Stream<T> 流是不同于IO流的一种流,java1.8之后的，关注做什么，而不是怎么做
 * 1.获取stream流 接口的方式：
 * 	① Collection集合下的默认方法： default<T> Stream<E>   stream();
 * 	② Stream 接口的静态方法可以获取数组相应的流
 * 	   static <T>Stream<T>  of (T...values)   参数是可变参数,可以传递一个数组
 * 2.Stream流模型
 *   ①延迟方法：返回值仍是stream流，除了延迟方法外都是终结方法
 *      常用方法：
 *      Stream<T>     filter(Predicate<? super T>predicate)  返回由与此给定谓词匹配此流的元素组成的流，作判断并筛选boolean test(T t)
 *      <R>Stream<R>  map(Function<?super T,? extends R>mapper)  返回由给定函数应用于此流的元素的结果组成的流，把T转为R数据类型R apply(T t)
 *      Stream<T>     limit(long MaxSize);       用于对六种元素进行截取，返回一个新的流，MaxSize是截取的前n各元素
 *      Stream<T>     skip(long n);            如果流的当前长度大于n,则跳过前n个，否则系那个会得到一个长度为0的空流 
 *      static<T>Stream<T>  concat(Stream<? extends T>a,Stream<? extends T>a) 静态方法，与java.lang.String下的concat不同，用于将两个流合成一个新的流     
 *   ②终结方法： forEach(),count()
        forEach(Consumer<? super T> action); Consumer消费型接口void accept(T t)
        long    count(); 用于统计
        List<T> collect(Collector<T>collector); 将流中元素汇总到集合中
   3.interface  Collector<T,A,R>,class Collectors 将元素积累到集合中，实现汇总
    List<T>list2 =list1.stream().collect(Collectors.toList());
 * 4.注意事项：Stream流属于管道流，只能使用一次，且使用后流会自动关闭，数据传递到下一个流中*/
public class demoStream {

	private static void filter_forEach_stream() {
		List<String> FinalList = new ArrayList<>();
		FinalList.add("张丽");
		FinalList.add("张有为");
		FinalList.add("韩旭");
		FinalList.add("方大大");
//		System.out.println(FinalList);

		/*
		 * Stream<T> filter(Predicate<? super T> predicate); 用于过滤判断 void
		 * forEach(Consumer<? super T> action); Consumer消费型接口
		 */
		FinalList.stream().filter(name -> name.startsWith("张")).filter(name -> name.contains("为")) // 两次过滤是&&的关系
				.forEach(name -> System.out.println("过滤出集合中的人名：" + name));

	}

	private static void skip_limit() {
		// 1.list skip、limit、stream方法
		List<String> list = new ArrayList<>();
		Collections.addAll(list, "a", "b", "c", "d", "e");
		Stream<String> stream1 = list.stream();
		stream1.skip(1).limit(3).forEach((String s) -> {
			System.out.println("list_skip_limit：" + s);
		});// 跳过前1个再截取3个
	}

	private static void concat() {
		// 2.Set
		Set<String> set = new HashSet<>();
		set.add("丽丽");
		set.add("莉莉");
		set.add("李莉");
		Stream<String> stream2 = set.stream();
		Stream<String> stream2_1 = Stream.of("刘静", "刘能", "刘老根");
		Stream<String> streamAll = Stream.concat(stream2, stream2_1);
		streamAll.map(name->new person(name)).forEach((person p) -> {
			System.out.println(p);
		});
	}

	private static void map() {
		// 3.Map map(Function fun)
		Map<String, String> map = new HashMap<>();
		map.put("1", "第一名");
		map.put("2", "第二名");
		map.put("3", "第三名");

		Set<String> keyset = map.keySet();
		Collection<String> values = map.values();
		Stream<String> stream3 = keyset.stream();
		stream3.map((String s) -> {
			return Integer.parseInt(s);
		}).forEach((Integer i) -> {
			System.out.println("map_String转Integer:" + i);
		});
		
		Stream<String> stream4 = values.stream();
		// 获取键值对的映射关系
		Set<Map.Entry<String, String>> entry = map.entrySet();
		Stream<Map.Entry<String, String>> stream5 = entry.stream();
		stream5.map((Map.Entry<String, String> ent)->{return ent.getKey()+"->"+ent.getValue(); }).forEach((String ss)->System.out.println(ss));
	}
    
	private static void forEach_of() {

		// 4.数组 forEach、of方法
		int[] arr = { 1, 2, 3, 4, 5 };
		Stream<Integer> stream6 = Stream.of(1, 2, 3, 4);
		System.out.println("stream6_long_count()方法:" + stream6.count());
		Stream<int[]> stream7 = Stream.of(arr);
		/* 用forEach遍历流中数组的数据 */
		stream7.forEach((int[] a) -> {
			System.out.print("arr[]_forEach遍历：");
			for (int j = 0; j < a.length - 1; j++) {
				System.out.print(a[j] + ",");
			}
			System.out.println(a[a.length - 1]);
		});
	}
    private static void collect() {
    	Stream<Integer> stream=Stream.of(4,5,6,7,8);
    	List<Integer>list=stream.filter(x->x>6).collect(Collectors.toList());
    	System.out.println("collect_list:"+list);
    }
	public static void main(String[] args) {
//		filter_forEach_stream();
//		skip_limit();
		concat();	
//		forEach_of();
//		map();
		collect();
	}
}
