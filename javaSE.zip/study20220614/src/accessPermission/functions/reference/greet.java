package accessPermission.functions.reference;
@FunctionalInterface
public interface greet {
void greet();
}
