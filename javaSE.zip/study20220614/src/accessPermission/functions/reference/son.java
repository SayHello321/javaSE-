package accessPermission.functions.reference;

public class son extends father {

	@Override
	public void say() {
		System.out.println("I am son") ;
	}
    public void dosome(greet g) {
    	g.greet();
    } 
	public void showObject() {
		/*  Lambda expression
		 * dosome(()->{ father fa =new father(); fa.say(); });
		 */
//		dosome(()->super.say());//super引用父类方法
		dosome(super::say);//super引用父类方法
		dosome(this::say);//super引用子类方法
	}
	
	
	
}
