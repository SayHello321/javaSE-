package accessPermission.functions.reference;

import javax.xml.transform.Source;

/* 通过对象名引用方法,对象和方法已存在，引用的方式有三种：
 * ① 通过对象名引用成员方法
 * ② 通过类名引用静态的成员变量
 * ③ 通过super关键字引用父类的成员方法
 * ④ 通过this引 用本类的成员方法
 * */
public class reference {
 
    
    
    public static void printString (printable p) {
	   p.print("nihao");
   }
   
   public static void main(String[] args) {
	   //① 通过对象名引用成员方法
	   printString (s->System.out.println(s));	  
	   /*Lambda表达式的目的：将参数传递给System.out对象，调用println(s)方法对字符串打印输出*/
	   printString (System.out::println);
	   
	   
	   printString ((s)->{
		   father m =new father();
		   m.printToUpperCase(s);
	   });
	   father m =new father(); 
	   printString (m::printToUpperCase);
	   
	   
	   //② 通过类名引用静态的成员变量
	   System.out.println("-100的绝对值："+Math.abs(-100));
	   
	   //③ 通过super关键字引用父类的成员方法
	   new son().showObject();
   }        
}
