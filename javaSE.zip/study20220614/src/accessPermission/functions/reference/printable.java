package accessPermission.functions.reference;
@FunctionalInterface
public interface printable {
	
    void print(String s);
}
