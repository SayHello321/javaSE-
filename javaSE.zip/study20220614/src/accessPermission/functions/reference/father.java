package accessPermission.functions.reference;

public class father {
   public void say() {
	   System.out.println("I am father");
   }
	public void printToUpperCase(String s){
		 System.out.println(s.toUpperCase()); 
	 }
	public void printToLowerCase(String s){
		System.out.println( s.toLowerCase());
	 }
}
