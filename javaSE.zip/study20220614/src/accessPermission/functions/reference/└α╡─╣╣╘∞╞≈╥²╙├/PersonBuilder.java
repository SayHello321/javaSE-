package accessPermission.functions.reference.类的构造器引用;
@FunctionalInterface
public interface PersonBuilder {
 //传递姓名，返回Person对象
 Person builderPerson(String name);
}
