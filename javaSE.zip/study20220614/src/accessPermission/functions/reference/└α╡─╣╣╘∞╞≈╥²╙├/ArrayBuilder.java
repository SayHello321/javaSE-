package accessPermission.functions.reference.类的构造器引用;

@FunctionalInterface
public interface ArrayBuilder {
	int[] builderArray(int arrayLength);
}
