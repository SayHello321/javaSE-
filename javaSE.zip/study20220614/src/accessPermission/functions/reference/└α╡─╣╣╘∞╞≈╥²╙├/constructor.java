package accessPermission.functions.reference.类的构造器引用;

/*1.类的构造器（构造方法）引用
 *2.数组的构造器引用*/
public class constructor {
	private static void printName(String name, PersonBuilder pb) {
		Person person = pb.builderPerson(name);
		System.out.println(person.getName());
	}

	public static int[] createArray(int arrayLength, ArrayBuilder ab) {
		return ab.builderArray(arrayLength);
	}

	public static void main(String[] args) {
		//类的构造引用
		// （1）Lambda表达式
		printName("李欣", (name) -> new Person(name));
		// （2）使用Person类的带参构造，使用name创建对象
		printName("李欣", Person::new);

		//数组的构造引用
		//(1)Lambda
		int [] arr1 =createArray(3, (len)->new int[len]);
		System.out.println("arr1.length:"+arr1.length);
		//(2)引用数组int[]时已经存在的
		int[] arr2 =createArray(3,int[]::new);
		System.out.println("arr2.length:"+arr2.length);
	}
}
