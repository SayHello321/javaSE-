package accessPermission.functions.FunctionalInterface;
/*函数式接口：有且只有一个抽象方法的接口，当然也可以由其他方法（私有，静态，默认）
 * @FunctionalInterface 注解
 * 作用：检测接口是否是一个函数式接口，若果是，编译成功；如果编译失败，可能是抽象方法的个数>1个或者没有抽象方法*/
@FunctionalInterface
public interface myFunctionalInterface {
public abstract void method();
public static void method2() {
	System.out.println("接口中方法static method2");
}
}
