package accessPermission.functions.FunctionalInterface.函数式接口案例;
@FunctionalInterface
public interface logbuilder {
	
public abstract String builderMessage();

}
