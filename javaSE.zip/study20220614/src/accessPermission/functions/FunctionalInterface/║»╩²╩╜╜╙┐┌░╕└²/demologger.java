package accessPermission.functions.FunctionalInterface.函数式接口案例;
/* 常见的函数是接口：
 * ① Runnable：java.lang.Runnable也是函数式接口，里面只有run()方法
 * ② Comparator：java.util.Comparator<T>也是函数时接口,排序器 ，compare(o1,o2)
 * ③ Supplier：生产数据，函数式接口java.util.Supplier<T> 接口，泛型执行T型数据类型,获取一个T型的result
 * ④ Consumer ：消费数据，函数式接口java.util.function.Consumer<T>,抽象方法void accept(T t)
 * ⑤ Predicate java.util.function.Predicate,抽象方法boolean test(T t)作判断
 *    逻辑运算符：与 && 相当于  default Predicate<T> and(Predicate<? super T> other)
 *              或 || 相当于  default Predicate<T> or(Predicate<? super T> other)
 *              非 !相当于    default Predicate<T> negate()
 * ⑥ java.util.function.Function<T,R>,根据T类型得到R类型的数据
 *   抽象方法 R apply(T t);
 *   抽象方法andThen()*/
import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class demologger {
	private static void showlog(int level, String message) {
		if (level == 1) {
			System.out.println(message);
		}
	}

	/* 满足条件才会执行builderMessage()方法，避免了性能浪费 */
	public static void showlogOptimized(int level, logbuilder lb) {
		if (level == 2) {
			System.out.println(lb.builderMessage());
		}
	}

	/* java.lang.Runnable也是函数式接口，里面只有run()方法,函数时接口@作参数*/
	public static void startThread(Runnable runnable) {
		new Thread(runnable).start();
	}
	
	/* java.util.Comparator也是函数时接口,排序器，函数时接口作@返回值 */
    public static Comparator<String> getComparator() {
		
		/*
		 * return new Comparator<String>() {
		 * 
		 * @Override public int compare(String o1,String o2){ return
		 * o2.length()-o1.length(); //降序 } };
		 */
		 
    	return (o1, o2)-> o2.length()-o1.length() ;
    }
    
    /*函数式接口java.util.Supplier<T> 接口，泛型执行T型数据类型,获取一个T型的result*/
    public static String getString(Supplier<String>supplier) {
    	return supplier.get();
    }
    /*传递名字和Consumer接口，消费姓名*/
    public static void consume(String name,Consumer<String> consumer) {
    	consumer.accept(name);
    }
    
    /*函数式接口Predicate作传递参数*/
    
    public static boolean checkString(String s ,Predicate<String> predicate) {
		return predicate.test(s);

	}
    public static boolean checkString(String s ,Predicate<String> predicate,Predicate<String> predicate1) {
//      return predicate.test(s) && predicate1.test(s);   	
		return predicate.and(predicate1).test(s); //逻辑与，&&
//		return predicate.or(predicate1).test(s); //逻辑或，||
//		return predicate.negate().test(s);       //逻辑非  ！

	}
    
    
    //用Function<T,R>函数式接口将字符串类型整数转成Integer类型整数
    public static void changeDataType(String s,Function<String,Integer>fun) {
			Integer in =fun.apply(s);
		 System.out.println("字符串\""+s+"\"转换成Integer整数为:"+in);
	}
    
    //用Function<T,R>将String->Integer,经过运算后，将Integer->String
    public static String changeDataType(String s,Function<String,Integer>fun1,Function<Integer,String>fun2) {
    	    //相当于fun1.apply(String s),fun2.apply(Integer i)
    		return fun1.andThen(fun2).apply(s);
    }
    
    
	public static void main(String[] args) {
		// 案例1.日志
		String message1 = "m1";
		String message2 = "m2";
		String message3 = "m3";
		showlog(1, message1 + message2);
		showlogOptimized(1, () -> {
			System.out.println("满足条件执行如下（不满足不执行）：");
			return message1 + message2 + message3;// level条件如果不满足，拼接字符串也不会执行
		});

		// 案例2.开启线程案例
		// 匿名内部类
		startThread(new Runnable() {
			@Override
			public void run() {
				System.out.println("匿名内部类-" + Thread.currentThread().getName() + "线程开启了");
			}
		});
		// Lambda
		startThread(() -> System.out.println("Lambda-" + Thread.currentThread().getName() + "线程开启了"));
        
	    //案例3.排序
	    String [] arry = {"1","22","333","4544","55555"};
	    Arrays.sort(arry);
	    System.out.println(Arrays.toString(arry));
	    Arrays.sort(arry,getComparator());;
	    System.out.println(Arrays.toString(arry));
	    
	    //案例4.Supplier接口
	    System.out.println(getString(()->"Supplier函数式接口"));
	    //用Lambda重写函数get()方法，寻找最长的字符串
	    String str =getString(
	    	    ()->{
	 	           String strMaxLength =arry[0];
	 	           for(String s:arry) {
	 	        	   if(s.length()>strMaxLength.length()) {
	 	        		   strMaxLength=s;
	 	        	   }
	 	           }
	 	           return strMaxLength;
	 	    }		
	 	    		);
	    System.out.println("数组中字符串长度最多的元素是："+str);
	    
	    //案例5.Consumer，消费数据,获取姓氏
	    consume("李振",(String name)->System.out.println("此人姓："+name.substring(0,1)) );
	    
	    //案例6.Predicate,判断字符串长度
	    String so = "123456";
	    boolean b =checkString(so,(String sss)->{
	    	return sss.length()>5;}
	    );
	    System.out.println("字符串so的长度是否大于5："+b);
	    
	    
	    //案例6.Function函数接口
	    changeDataType(so,(String w)->Integer.parseInt(w));
	    
	}
}
