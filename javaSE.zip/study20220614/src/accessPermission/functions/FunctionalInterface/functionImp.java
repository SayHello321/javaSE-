package accessPermission.functions.FunctionalInterface;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class functionImp implements myFunctionalInterface {
@Override
public void method() {
	System.out.println("实现类重写method()");
	
}
/*函数式接口当作参数或返回值*/
public static void show(myFunctionalInterface FunctionInterface) {
	FunctionInterface.method();
}
public static void main(String[] args) {
	/*抽象方法通过实现类调用*/
	new functionImp().method();
	/*静态方法通过接口调用*/
	myFunctionalInterface.method2();
    
	/*1.通过调用实现类中的方法调用函数式接口*/
	show(new functionImp() );
	/*2.通过匿名内部类*/
	show(new myFunctionalInterface() {
		
		@Override
		public void method() {
			System.out.println("第二种方法");
			
		}
	} );
	/*3.通过Lambda表达式*/
	show( ()->{
		System.out.println("第三种方法");
		}  
	);
	
	/*
		try {
			char[]c = {'a','b','c','d'};
			FileWriter o =new FileWriter("src\\accessPermission\\FunctionalInterface\\f.csv");
			
			o.write(c);
			o.flush();
			o.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	*/
	
}
}
