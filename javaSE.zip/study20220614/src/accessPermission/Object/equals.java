package accessPermission.Object;

import java.util.Objects;

/*1、person默认继承了Object类，所以person可以继承object的equals方法
 *2、 boolean p.equals(Object obj) 返回的是一个布尔值
 *   boolean Objects.equals(Object a,Object b); //防止空指针异常
 *3、基本数据类型： 比较的是值；
 *  引用数据类型： 比较的是地址值；*/
public class equals {
public static void main(String[] args) {
	person per1 = new person("小明",10);
	person per2 = new person("小红",10);
	System.out.println("P1地址值： "+per1);
	System.out.println("P2地址值： "+per2);
	System.out.println("传地址之前P1与P2是否相等： "+per1.equals(per2));//person.equals()调用重写的方法；
	per1=per2;//把p2的地址给p1
	System.out.println("传地址之后P1与P2是否相等： "+per1.equals(per2));
	System.out.println("================================================");
	
	
	/*<源码> public static boolean equals(Object a, Object b) {
        return (a == b) || (a != null && a.equals(b));
    }
	 * */
	
//	String a ="a";
//	String b= "b";
	String a =null;//equals(null,null); true是被容忍的
	String b= null;
	System.out.println("equals(a,b): "+Objects.equals(a, b));
	
}
}
