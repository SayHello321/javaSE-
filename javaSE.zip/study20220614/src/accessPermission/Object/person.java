package accessPermission.Object;

public class person /*extends Object*/{

	private String name;
	private int age;

	public person() {
		super();
		// TODO Auto-generated constructor stub
	}

	public person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

//	@Override
//	public String toString() {
//		return "person [name=" + name + ", age=" + age + "]";
//	}
//	
	/* 覆盖重写Object中的equals（）方法，让其比较属性，不比较地址 */
	@Override
	public boolean equals(Object obj) {
		if(obj ==this) {//如果obj是自身肯定相等，为true
			return true;
		}
		if (obj==null ) { //如果传入空值null，肯定false
			return false;
		}
		// 使用多态的向下强转,加Intanceof防止类型转换一场，还有Random、toString等类；
		if (obj instanceof person) {
			person p = (person) obj;
			// this谁，方法中调用的就是那个对象
			boolean b = this.name.equals(p.name) && this.age == p.age;
			return b;
		} else {
			return false;
		}
	}

}
