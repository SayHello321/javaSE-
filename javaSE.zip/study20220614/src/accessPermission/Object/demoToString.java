package accessPermission.Object;

import java.util.Random;

/*Object类中的同toString()方法：
 * 对象中继承重写toStrig(),直接打印println(对象名)就是打印对象的参数，如果对象中没有写此方法，打印的是对象地址；*/
public class demoToString {
	public static void main(String[] args) {
		
		person p = new person("小明", 13);
		System.out.println(p.toString());//默认toString(),但是person目前没有重写Object中的toString()方法，打印的是地址值。
		Random r =new Random();
		int num=r.nextInt(10)+1;//1~10
         System.out.println(num);
		System.out.println(r);//java.util.Random类下没有写toString类
	}
}
