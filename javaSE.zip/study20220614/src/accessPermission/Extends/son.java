package accessPermission.Extends;

public class son extends father {
int num=2;
public son() {
	//super(); //编译器自带的无参的，继承父类构造方法
	System.out.println("儿子类无参构造方法执行");
}
public son(int num) {
	
	System.out.println("儿子类有参构造方法执行");
}
void methodSon() {
	System.out.println("Son's methodSon excuted!");
}
}
