package accessPermission.Extends;
/*1、继承优先用自己的变量或方法，自己没有逐级往上继承；
 *2、 成员方法参数调用如下：
 * ① num是局部变量
 * ② this.num是本类成员变量
 * ③ super.num是父类变量,本类方法也可以继承父类方法 super.methodSon()； 
 *3、override:方法重写、覆盖，方法名称一样，参数列表也【一样】，写在方法之前@override,是一种注解，检测此方法与父类中的方法是否一样，可以添加功能
 *  overload :方法重载，方法名称一样，参数列表【不一样】
 *  object 所有类的父类，子类返回值【小于等于】object返回值范围
 *4、权限修饰符：public>private>(default)>protected
 *   子类权限【大于等于】父类权限,default是什么都不写
 *5、构造函数的访问特点：
 *   ①先访问父类的构造方法，后访问子类构造方法 
 *   ②继承无参构造方法"super();"是系统自带,若继承有参构造需要用"super(参数);"方法
 *   ③super的父类构造调用，必须是子类构造方法的第一个语句，也不能多次调用super
 * */
public class grandson extends son{	
	public static void main(String[]args) {
		father fa=new father();
		fa.methodFather();	
		System.out.println("======================================================");
		
		new son().methodSon();
		System.out.println("======================================================");
		
		System.out.println(new son().num);
		System.out.println("======================================================");
		
		new grandson().methodGrandson();
		System.out.println("======================================================");
		new grandson().methodSon();
	}
	int num =3;
public grandson() {
	//super(); //编译器自带的无参的，继承父类构造方法
	super(10);  //调用父类重载的构造方法，必须是第一个语句,而且只能调用一个super
	System.out.println("孙子类无参构造方法执行,继承儿子类有参构造方法");
}
void methodGrandson() {
	int num =4;
		System.out.println("grandson's methodGrandson excuted!");
		System.out.println("son num变量：     \t"+super.num);
		System.out.println("grand_son num成员变量：\t"+this.num);
		System.out.println("grand_son num方法参数：\t"+num);
	}
@Override
void methodSon() {
	super.methodSon();
	// grandson类在son的基础上再添加功能
	System.out.println("grandson类中方法重写覆盖(@override) son中方法methodSon()  ");
}
} 
