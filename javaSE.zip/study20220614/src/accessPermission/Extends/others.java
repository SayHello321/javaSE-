package accessPermission.Extends;

public class others {
	public static void main(String[]args) {
		System.out.println("============调用son类(无参)========================================== ");
		son son=new son();
		System.out.println("============调用grandson类========================================== ");
		grandson grandson= new grandson();	
		System.out.println("============调用son类方法========================================== ");
		son.methodSon();
		System.out.println("============调用grandson类方法========================================== ");
		grandson.methodSon();
		
		
	}
}
