package accessPermission.Extends;

public class father {
	int num=1;
	public father() {
		//super(); //编译器自带的无参的，继承父类构造方法
		System.out.println("父亲类无参构造方法执行");
	}
void methodFather() {
	System.out.println("father's methodFather excuted!");
}
}
