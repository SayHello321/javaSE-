package accessPermission.Arrays;

import accessPermission.Math.FLASH_method;

public class decimalToHex {
/*需要注意的是 ：
1.基于上述的这种实现思想（除数取余），对于任意十进制正整数转换到任何进制（比如三进制、八进制、十六进制等等）都是通用的
2.而对于任意十进制负整数转换到其它进制，需要先将其转换为二进制（补码形式），再由该补码转换为我们想要的进制。*/
	public static void decimalToBin(int num) {
		 //取num的绝对值 
		int absNum = Math.abs(num);
		//假设我们要得到一个8位的二进制数
		int[] bins = new int[8];
		//不停的循环上述算法过程
		for(int i = 0; absNum > 0; i++) {
			bins[i] = absNum % 2;
			absNum /= 2;
		}
		//判断一下num是否是负数
		//如果是负数还需要进行取反、最低位+1操作（负数以补码表示）
		if (num < 0) {
			//首先对所有非符号位取反 
			for(int i = 0; i < bins.length-1; i++) {
				bins[i] = bins[i] == 0 ? 1 : 0;
			}
			//之后在最低位加1
			for(int i = 0; i < bins.length-1; i++) {
				if (bins[i] == 0) {
					bins[i] = 1;
					break;
				}else {
					bins[i] = 0;
				}
			}
			//最高位置1，表示负数
			bins[bins.length - 1] = 1;
		}
		//将数组倒过来,所有的元素拼接在一起就是最终的结果了
		StringBuilder sBuilder = new StringBuilder();
		for(int i = bins.length - 1; i >= 0; i--) {
			sBuilder.append(bins[i]);
		}
		System.out.println("二进制表示为： "+sBuilder);

	}
	
	
	public static int[] decimalToHex(int num,int bits) {
		 //取num的绝对值 
		int bit =bits/4;
		int absNum = Math.abs(num);
		//假设我们要得到一个bits位的二进制数
		int[] bins = new int[bit];
		//不停的循环上述算法过程
		for(int i = 0; absNum > 0; i++) {
			bins[i] = absNum % 16;
			absNum /= 16;
			
			
			
		}
		//判断一下num是否是负数
		//如果是负数还需要进行取反、最低位+1操作（负数以补码表示）
		if (num < 0) {
			//首先对所有非符号位取反 
			for(int i = 0; i < bit-1; i++) {
				bins[i] = bins[i] == 0 ? 1 : 0;
			}
			//之后在最低位加1
			for(int i = 0; i < bit-1; i++) {
				if (bins[i] == 0) {
					bins[i] = 1;
					break;
				}else {
					bins[i] = 0;
				}
			}
			//最高位置1，表示负数
			bins[bins.length - 1] = 1;
		}
		//将数组倒过来,所有的元素拼接在一起就是最终的结果了		
		for(int i = bins.length - 1,k=0; i >=k; i--,k++) {
			int temp=bins[k];
			bins[k]=bins[i];
			bins[i]=temp;
		}
     return bins;
	}
	
	
	public static void main(String[]args) {
		decimalToBin(-5);
		tenToBin(10);
		new FLASH_method().printArray(decimalToHex(255,8));
		//SB.delete(0, 2);
		//System.out.println("十六进制表示：" + Integer.toHexString(SB));
		//System.out.println("十六进制表示：" +SB);
	}
	

	public static void tenToBin(int num) {
		StringBuilder sBuilder = new StringBuilder();
		
		//假设我们要得到一个32位的二进制数
		for (int i = 0; i < 32; i++){
		    //与 1 执行按位与运算，其目的就是对2求余
	        sBuilder.append(num & 1);
	        
	        //采用无符号右移来实现除法
	        //这样既保证了符号位参与运算，又借助了移位运算速度优于除法速度这一优势
	        num = num >>> 1;
	    }
	    //记得翻转
	    System.out.println("二进制表示为： "+sBuilder.reverse());
	}
}
