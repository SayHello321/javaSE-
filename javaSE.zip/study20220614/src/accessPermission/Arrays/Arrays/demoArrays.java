package accessPermission.Arrays.Arrays;

import java.util.Arrays;
/*Arrays相关用法：
 * Arrays.toString(array);  将数组转换为字符串
 * Arrays.sort(array) 将数组进行升序排列
 * Arrays.asList(String...a);
 * Arrays.copyof(int[]source,int newLength);
 * Arrays.copyOfRange(int[] original, int from, int to) 
 * 
 * */
public class demoArrays {
	  public static void printArray(int[] array) {
			
		  for(int j=0;j<array.length;j++){
			   if(j==0){
				   System.out.print("printArray： ["+array[0]+",");
			   }
				else if(j==array.length-1){
					System.out.println(array[array.length-1]+"]");
				}
				else{
					System.out.print(array[j]+",");
				}
				
				}
		  
	  }
	  public static void printArray(Object[] array) {
			
		  for(int j=0;j<array.length;j++){
			   if(j==0){
				   System.out.print("printArray： ["+array[0]+",");
			   }
				else if(j==array.length-1){
					System.out.println(array[array.length-1]+"]");
				}
				else{
					System.out.print(array[j]+",");
				}
				
				}
		  
	  }
	public static void main(String[]args){
		int [] array =new int[]{3,2,1,4};
		printArray(array);
		System.out.println(array);
		String str=Arrays.toString(array);
		System.out.println(str);
		Arrays.sort(array);
		String str1=Arrays.toString(array);
		System.out.println(str1);
		String []array1 = {"cfg","acd","b22"};
		Arrays.sort(array1);
		String str2=Arrays.toString(array1);
		System.out.println(str2);
		int [] arrayx =Arrays.copyOfRange(array, 0, 2);//[3,2]
		Arrays.asList(array);
	}
}
