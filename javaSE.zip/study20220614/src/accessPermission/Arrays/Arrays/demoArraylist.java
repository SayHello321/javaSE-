package accessPermission.Arrays.Arrays;

import java.util.ArrayList;
/*集合.add()方法*/
public class demoArraylist {
	  public static void main(String[]args){	
		ArrayList<String>list=new ArrayList<>();
		list.add("baidu");
		list.add("taobao");
		System.out.println(list);
		System.out.println(list.get(0));
		System.out.println(list.get(1));
		printArrayList(list);
		
	}

	public static void printArrayList(ArrayList<String>list) {
			
		  for(int j=0;j<list.size();j++){
			   if(j==0){
				   System.out.print("Print_ArrayList: ["+list.get(0)+",");
			   }
				else if(j==(list.size()-1)){
					System.out.println(list.get(list.size()-1)+"]");
					
				}
				else{
					System.out.print(list.get(j)+",");
				}
				
				}
		  
	  }
}
