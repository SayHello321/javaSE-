package accessPermission.Arrays;

import java.util.Scanner;

public class ScannerDemo {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		 
		  System.out.println("请输入选项：");	//打印提示，系统拿num
		 int num = sc.nextInt();
		 System.out.println("输入的数字是："+num);
	} 
}
