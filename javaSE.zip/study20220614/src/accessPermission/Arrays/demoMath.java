package accessPermission.Arrays;
/*java.util.Math
 * public static double abs(double num); 获取绝对值 
 *  public static double ceil(double num);向上取整，并非四舍五入，如12.64 取为13
 *  public static double floor(double num);向下取整，12.64为12
 *  public static long round(double num);四舍五入，如12.64 取为13
 * */
public class demoMath {
	public static void main(String[]args){
		double d1=-3.1415;
		double d2=3.1415;
		double d3=3.1415;
		double d4=3.52;
		System.out.println(Math.abs(d1));//3.1415
		System.out.println(Math.ceil(d2));//4
		System.out.println(Math.floor(d3));//3
		System.out.println(Math.round(d4));//4
	}
}
