package accessPermission.demoFinal;
/*用final 修饰一个方法
 * 格式 ：  public final 返回值类型（参数列表）{}
 * 注意：① final修饰的方法不能进行@override 
 *     ②  对于类、方法，final和abstract不能同时执行，会产生矛盾*/
public abstract class Fu {
	
	public abstract /*final不能用*/ void methodABS();
	
	public final void methodFu() {
		System.out.println("父类方法执行！");
		
	}
}
