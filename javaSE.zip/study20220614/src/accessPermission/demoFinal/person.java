package accessPermission.demoFinal;
/*final 修饰成员变量
 * 1、对于成员变量具有默认值，所以用final之后必须手动赋值，不会再给默认值了
 * 2、对于final的成员变量，要么直接赋值，要么通过默认构造方法赋值，二者选其一*/
public class person {
	//	public void setName(String name) {//既然已经赋值，set也没有必要了
//		this.name = name;
//	}
	 public static void main(String[] args) {
	System.out.println(new person().getName()); 
	}
	
    private final String name;//="李明"; //①可以去掉final关键字直接给成员变量赋值
	public person() {
		name="李明";//②通过构造方法直接赋值
	}

	public person(String name) {
		
		this.name = name;
	}

public String getName() {
		return name;
	} 	  
}

