package accessPermission.demoFinal;
/*用final 修饰一个类
 * 格式 ：  public final class 类名称{}
 * 注意：①final修饰的类没有子类，但可以有父类
 *     ②类中的所有方法不能进行@override */
public final class myclass1 /*extends Object 最高级别的类*/ {

}
