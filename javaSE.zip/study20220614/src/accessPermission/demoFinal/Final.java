package accessPermission.demoFinal;
/* final关键字：
 * 1、常见的四种用法：修饰一个类、修饰一个方法、修饰一个局部变量、修饰一个成员变量
 *   
 * */
public class Final {

	
	public static void main(String[] args) {
		/*final对于基本数据类型，变量当中的数据不可变
		 *final对于引用类型，变量当中的地址值不变*/
		final int NUM=20;//这是final修饰局部变量
		//NUM=30;错误，局部变量不可变
		System.out.println("==============引用类型：stu1地址值已改变；基本数据类型：数据已改变=================================");
	    student stu1 = new student("杨巅峰");
	    System.out.println(stu1.getName());
	    System.out.println(stu1);
	    stu1=new student("王莽");
	    System.out.println(stu1.getName());
	    System.out.println(stu1);
	   
	    
	    
	    //加上final后
	    System.out.println("==============引用类型：stu2引用地址值不变，数据可以改变；基本数据类型：数据不可变=======================");
	    final student stu2 =new student();
	    stu2.setName("吕小毛");
	   // stu2=new student("吕大毛"); //final的是基本数据类型String,数据不可变，不能把地址给"吕大毛"；
	    System.out.println(stu2.getName());
	    System.out.println(stu2);	 
	    stu2.setName("吕大毛");//final的引用类型，地址不变，数据可变
	    System.out.println(stu2.getName());
	    System.out.println(stu2);
	}
}
