package accessPermission.demoFinal;

public class student {

	private String name;

	public student() {
	}

	public student(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
