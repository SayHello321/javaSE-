package accessPermission.demoFinal;

public class Zi extends Fu{

	@Override
	public void methodABS() {
		System.out.println("子类覆盖重写抽象父类中的抽象方法");
		
	}

	//错误写法，子类不能覆盖重写父类中final修饰的方法
//   @Override
//   public final void methodZi() {
//		System.out.println("子类覆盖重写父类方法！");
//	}
	
	
}
