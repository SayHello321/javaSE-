package accessPermission.Objects;
/*Objects.equals(a,b);比较两个数据是否相同，但是添加了一些健壮性的判断，null也可以做判断*/
import java.util.Objects;

public class students {
public static void main(String[] args) {
	String st1=null;
	String st2="b";
	System.out.println(Objects.equals(st1, st2));
	//System.out.println(st1.equals(st2));空指针异常
}
}
