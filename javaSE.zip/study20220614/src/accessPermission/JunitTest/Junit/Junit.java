package accessPermission.JunitTest.Junit;
/**
 *1.Junit 单元测试，独立运行
 *分类：黑盒测试(不用写代码)，白盒测试(写代码)；
  2.使用步骤
  @before
  初始化方法{}
   @Test 
   public 数据类型 test{  
   调用方法（）；
   // 用Assert进行断言，（expected,actually）进行对比
   Assert.xxx
   }
   @after
   释放相关资源{}
   运行结果：红色运行失败，绿色运行成功
   注意事项：test方法类型必须为public
   */

public class Junit {
 public static int add(int a ,int b) {
	return (a+b);

}
}
