package accessPermission.JunitTest.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import accessPermission.JunitTest.Junit.Junit;
import junit.framework.Assert; //已过时

public class testJunit {
@Before
public void init() {
	System.out.println("1.init()");
}
@Test
public void testAdd() {
	
	int s = Junit.add(1,2);
	//用Assert进行断言，（expected,actually）进行对比
   Assert.assertEquals(3, s);
   System.out.println("2.test()");
}
@After
public void close() {
	System.out.println("3.close()");
} 

}
