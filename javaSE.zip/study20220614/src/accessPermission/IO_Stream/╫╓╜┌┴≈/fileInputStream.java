package accessPermission.IO_Stream.字节流;
/*FileInputStream extends java.io.InputStream: 从文件系统中的某个文件中获得输入字节，以【字节】为单位读取
 *  作用：把硬盘中的数据读到内存中使用 硬盘-->内存
 * 1.共性方法
 *   void close()                 关闭此文件输入流并释放与此流有关的所有系统资源。 
     int read()                   从此输入流中读取一个数据字节。 
     int len =fis.read(byte[] b);           从此输入流中将最多 b.length 个字节的数据读入一个 byte 数组中,返回一个有效字节个数len。 
     int len =fis.read(byte[] b, int off, int len)   从此输入流中将最多 len 个字节的数据读入一个 byte 数组中。 
   2.构造方法 
     FileInputStream(File file)          通过打开一个到实际文件的连接来创建一个 FileInputStream，该文件通过文件系统中的 File 对象 file 指定。
     FileInputStream(String name)        通过打开一个到实际文件的连接来创建一个 FileInputStream，该文件通过文件系统中的路径名 name 指定。
     String(byte[[]b);
     String (byte[]b,int offset,int len ); offset数组开始的索引，len转换的字节数。
   4.字节输入流使用步骤：
 *  ① 创建FileOutputStream，构造方法绑定数据源
 *  ② 调用read(),开始读文件
 *  ③ close()释放资源
 * 5.copy文件
 *   ①创建文件输入流，读文件
 *   ②创建文件输出流
 *   ③边读边写
 *   ④释放资源，写先close，然后再读close*/

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class fileInputStream {
	 private static void readDemo1() throws IOException {
		
		FileInputStream fis =new FileInputStream("src\\accessPermission\\IO_Stream\\IO\\IO.txt");
		//1.一次读取一个byte，read()
        int  int1  =fis.read(); //int 是十进制值
        int  int2   =fis.read();
        System.out.println((char)int1);//I 是以一个一个byte读的
        System.out.println((char)int2);//O 是以一个一个byte读的
        System.out.println("===========================1=======================================");
     	
        //2.一个一个Byte去读多个byte		
		int len = 0; // (char)0=NULL;
		while ((len = fis.read()) != -1) { // -1是结束标记
			System.out.print((char)len);
        }
		 fis.close();
        System.out.println();
        System.out.println("===========================2=======================================");
        }
      
      private static void readDemo2() throws IOException {
        //3.读固定数组长度的字节b.length()个字节,read(byte[]b)
        FileInputStream fis1 =new FileInputStream("src\\accessPermission\\IO_Stream\\IO\\a.txt");
        byte[]b =new byte[2];
        
        //第一次读取(一次读取2byte) ，读ab
        int b_len = fis1.read(b); //int 为多个byte的十进制值，不能通过(char)b_len解析
        System.out.println(b_len);
        System.out.println(new String(b));   
       //第二次读取(一次读取2byte),读cd
         b_len = fis1.read(b); //int 为多个byte的十进制值，不能通过(char)b_len解析
        System.out.println(b_len);
        System.out.println(new String(b));
      //第三次读取(一次读取2byte) 读两个结束标记-1 和-1,这次没读到，数组元素没变，还是cds
        b_len = fis1.read(b); //int 为多个byte的十进制值，不能通过(char)b_len解析
        System.out.println(b_len);
        System.out.println(new String(b));
        System.out.println("===========================3=======================================");
        fis1.close();
        
	}
      private static void readDemo3() throws IOException {
    	  //while有效位连续读
    	  FileInputStream fis1 =new FileInputStream("src\\accessPermission\\IO_Stream\\IO\\a.txt");
          byte[]b =new byte[1024];//定义1kb=1024byte容量
          int len =0;         
          while( (len =fis1.read(b) ) !=-1) {     	 
        	  System.out.println(new String(b,0,len)); //String (byte[]b,int offset,int len )
          }
          fis1.close();
	}
      private static void readDemo4() throws IOException {
    	  FileInputStream fis1 =new FileInputStream("src\\accessPermission\\IO_Stream\\IO\\a.txt");
    	  byte[] b =new byte[4];
    	  int len =fis1.read(b, 0, 2);//这里与write稍有不同，这里是弹栈，偏移量从0开始读两个byte
    	  fis1.close();
    	  System.out.println(new String(b));
      }
      private static void copyDemo() throws IOException {
    	  FileInputStream fis =new FileInputStream("C:\\Users\\12525\\eclipse-workspace\\study\\src\\accessPermission\\File\\文件夹b\\文件夹c\\文件夹d\\IO\\copyFile");
    	  FileOutputStream fos =new FileOutputStream("src\\accessPermission\\IO_Stream\\IO\\copyFile");
    	  int len =0;
    	  byte[] b= new byte[1024];
    	  while( (len=fis.read(b)) !=-1) {
    		  fos.write(b, 0, len);
    	  }
    	  fos.close();
    	  fis.close();
      }
public static void main(String[] args) throws IOException {
//	readDemo1();
//	readDemo2();
//	readDemo3();
//	readDemo4();
	copyDemo() ;
}
}
