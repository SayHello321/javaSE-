package accessPermission.IO_Stream.字节流;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

/*1.继承关系：java.io.FileOutputStream extends OutputStream  作用是把内存中的数据写入硬盘的文件中，以【字节】为单位写入
 *2.类共性成员方法 
 *  ① void close()                             关闭此文件输出流并释放与此流有关的所有系统资源。
 *  ② void write(byte[] b)                     将 b.length 个字节从指定 byte 数组写入此文件输出流中。 
 *  ③ void write(byte[] b, int off, int len)   将指定 byte 数组中从偏移量 off 开始的 len 个字节写入此文件输出流。 
 *  ④ void write(int b)                        将指定字节写入此文件输出流。 
 *3.FileOutPutStream构造方法
 *  ① FileOutPutStream(String name)        创建一个向具有指定名称的文件中写入数据的输出文件流
 *    name : 目的是文件路径
 *  ② FileOutputStream(File file)          创建一个向指定 File 对象表示的文件中写入数据的文件输出流。
 *    file : 目的是一个文件
 *    构造方法作用： 创建FileOutputStream对象、根据构造方法传递文件/文件路径，创建一个空的文件、把FileOutputStream对象指向创好的文件
 *  ③ FileOutputStream(String name, boolean append)    创建一个向具有指定 name 的文件中写入数据的输出文件流。
 *    FileOutputStream(File file, boolean append)      创建一个向指定 File 对象表示的文件中写入数据的文件输出流。
 *    String name，File file 写入数据的目的地
 *    true:创建不会覆盖而是再原文件末尾追加数据
 *    false:创建一个新文件，覆盖原文件
 *    注意事项：
 *    ① java程序-->JVM-->OS(OS操作系统)-->OS调用写数据的方法-->把数据写入文件
 *    ② 写换行符号：
 *       windows: \r\n
 *       Linux:  /n
 *       mac: /r
 *4.字节输出流使用步骤：
 *  ① 创建FileOutputStream，传入数据写入的目的地
 *  ② 调用write(),把数据写入文件中
 *  ③ close()释放资源*/
public class fileOutputStream {
	private static void writeDemo() throws IOException {
		// 创建文件,写入数据
		FileOutputStream fos = new FileOutputStream("src\\accessPermission\\IO_Stream\\IO\\IOstream.txt");
		byte[] b0 = "你好,先生 ".getBytes();// utf-8:三个字节是一个汉字
		byte[] b1 = { 10, 104, 101, 108, 108, 111, 44 };// '换行键hello,'共 7byte
		byte[] b2 = { 115, 105, 114 }; // sir
		fos.write(b0);
		fos.write(b1);
		fos.write(b2, 1, 2);// b2的index：0往后取2个byte字节,i和r
		fos.close();
		// byte与String之间的转换
		// 字符串转成字节数组String-->byte[]
		String s = "abc";
		byte[] b3 = s.getBytes();
		System.out.println(Arrays.toString(b3));

		// byte[] -->String
		byte[] b4 = { 65, 66, 67 };
		String s1 = new String(b4);
		System.out.println(s1);
	}
        private static void appendDemo() throws IOException {
		FileOutputStream fos =new FileOutputStream("src\\accessPermission\\IO_Stream\\IO\\IO.txt", false);
		FileOutputStream fos1 =new FileOutputStream("src\\accessPermission\\IO_Stream\\IO\\IO.txt", true);
        fos.write("IO.txt create！".getBytes());
        fos.close();
        fos1.write("IO.txt add！".getBytes());
        fos1.write("\r\nhello\r\nhi".getBytes());
//        fos1.write("-1".getBytes()); //-1是结束标记，还是会返回-1
        fos1.close();
		}
	public static void main(String[] args) throws IOException {
		writeDemo();
		appendDemo();
	}
}
