package accessPermission.IO_Stream.缓冲流;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import accessPermission.IO_Stream.excel.User;
import accessPermission.IO_Stream.excel.excelTest;

/*1.缓冲流：是在基本IO流的基础上创建一个缓冲区数组，减少IO流的次数，从而提高效率
 *  对应4中基本流，缓冲流也有四种：
 *  字节流(2个)： BufferedInputStream和BufferedOutputStream
 *  字符流(2个)： BufferedReader和 BufferedWriter
 *2.构造方法
	① BufferedReader(Reader in)              创建一个使用默认大小输入缓冲区的缓冲字符输入流。 
	  BufferedReader(Reader in, int sz)      创建一个使用指定大小输入缓冲区的缓冲字符输入流。 
	② BufferedWriter(Writer out)             创建一个使用默认大小输出缓冲区的缓冲字符输出流。 
	  BufferedWriter(Writer out, int sz)     创建一个使用给定大小输出缓冲区的新缓冲字符输出流。 
	③ BufferedInputStream(InputStream in)             创建一个 BufferedInputStream 并保存其参数，即输入流 in，以便将来使用。 
	  BufferedInputStream(InputStream in, int size)   创建具有指定缓冲区大小的 BufferedInputStream 并保存其参数，即输入流 in，以便将来使用。 
	④ BufferedOutputStream(OutputStream out)          创建一个新的缓冲输出流，以将数据写入指定的底层输出流。 
	  BufferedOutputStream(OutputStream out, int size) 创建一个新的缓冲输出流，以将具有指定缓冲区大小的数据写入指定的底层输出流。 
 3.三中缓冲流分别继承相应的基本六，对应成员方法一样
   ① BufferedWriter特有方法，换行作用
	   void newLine(); 写入一个分隔符，根据不同的操作系统，获取不同的分隔符
	   windows: \r\n
	 * Linux:  /n
	 * mac: /r
  ② BufferedReader特有方法 
     String readLine()  读取一个文本行(按行读取),返回内容字符串，不包含终止符，到达流末尾返回null 
*/
public class BufferStream {
    private static void BufferedReader_demo() throws IOException {
    	//1.字符输入流缓冲区BufferedReader
    	BufferedReader br =new BufferedReader(new FileReader("src\\accessPermission\\IO_Stream\\IO\\FileReader.txt"));   	     
    	    System.out.println("提示：BufferedReader读字符数组！"); 
    	    String line;
    	    while((line = br.readLine())!=null) {    	    	
    	    	System.out.println(line);
    	    }
    	    br.close();
	}
    private static void BufferedWriter_demo() throws IOException {
    	//2.字符输出流缓冲区BufferedWriter
    	BufferedWriter bw =new BufferedWriter(new FileWriter("src\\accessPermission\\IO_Stream\\IO\\BufferedWriter.txt",true));
    	    for(int i =0;i<3;i++) {
    	    bw.write("BufferedWriter换行！");   
    	    bw.newLine();
    	      }
    	    bw.flush();
    	    bw.close();
	}
    private static void BufferedOutpuStream_demo() throws IOException {
    	//3.字节输出流缓冲区BufferedOutpuStream
    	BufferedOutputStream br =new BufferedOutputStream(new FileOutputStream("src\\accessPermission\\IO_Stream\\IO\\BufferedOutpuStream.txt"));
    	    br.write("BufferedOutpuStream写入！".getBytes());
    	    br.write("BufferedOutpuStream写入！".getBytes());
    	    br.flush();
    	    br.close();
	}
  public static void writeCSV() throws IOException {
	  BufferedWriter bw =new BufferedWriter(new FileWriter("src\\accessPermission\\IO_Stream\\IO\\BufferedWriter.CSV",false));
	  
	  excelTest test =new excelTest();
	  Collection<User>user =test.getUsers();
	  System.out.println(user);
	  
	  String[]title= {"userName","passWord"};
	  bw.write(title[0]+","+title[1]);
	  bw.newLine();
	  
	  Iterator<User>it=user.iterator();
	  while(it.hasNext()) {
		  User u = it.next();
		  String userMessage =u.getUserName()+","+u.getPassword();
		  System.out.println("打印用户："+userMessage);
		  bw.write(userMessage);
		  bw.newLine();
	  }
	  double d = 15.1112;
	  bw.write(Double.toString(d));
	  bw.flush();
	  bw.close();
	
}
	public static void main(String[] args) throws IOException {
//		 BufferedReader_demo();
//		 BufferedOutpuStream_demo();
//		 BufferedWriter_demo();
		 writeCSV();		
	}
}
