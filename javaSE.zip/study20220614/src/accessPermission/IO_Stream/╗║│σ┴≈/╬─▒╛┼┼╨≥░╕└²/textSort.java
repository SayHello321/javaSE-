package accessPermission.IO_Stream.缓冲流.文本排序案例;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/*要求：对文本按照(1,2,3..)进行排序*/
public class textSort {
private static void docSort() throws IOException {
	//1.创建HashMap集合准备存行号和内容
	Map<String,String>hashmap =new HashMap<>();
    //2.创建字符流输入对象
	BufferedReader br= new BufferedReader(new FileReader("src\\accessPermission\\IO_Stream\\文本排序案例\\长恨歌.txt"));
	//3.创建字符输出流对象
	BufferedWriter bw =new BufferedWriter(new FileWriter("src\\\\accessPermission\\\\IO_Stream\\\\文本排序案例\\\\长恨歌SORT.txt"));
	//4.逐行读取字符
	String line ;
	while( (line =br.readLine()) !=null ){
		System.out.println(line);
		String[] arr =line.split("\\.");
		hashmap.put(arr[0], arr[1]);		
	}
	System.out.println("====================================");
	//5、遍历每hashmap
	for(String key :hashmap.keySet()) {
		String value =hashmap.get(key);
		line=key+"."+value;//拼接成一个文本行
		System.out.println(line);
		//6.写入字符输出流
		bw.write(line);
		bw.newLine();//写换行		
	}
	
	//7.释放资源
	bw.close();
	br.close();
}
public static void main(String[] args) throws IOException {
	docSort();
}
}
