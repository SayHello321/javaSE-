package accessPermission.IO_Stream.字符流;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/* 1. java.io.Reader:是字符输入流，是输入流最顶层的父类，是一个抽象类，是以【字符】为单位进行读取
 *   FileReader extends InputStreamReader extends Reader
 * 2.共性的成员方法：
 *   ① int read()                                      读取单个字符,返回读取的字符，如果已到达流的末尾，则返回 -1 。 
     ② int read(char[] cbuf, int offset, int length)   将字符读入数组中的某一部分。 
     ③ void close()                                   关闭该流并释放与之关联的所有资源。   
   3. 构造方法摘要 
     ① FileReader(String fileName)   在给定从中读取数据的文件名的情况下创建一个新 FileReader。
     ② FileReader(File file)         在给定从中读取数据的 File 的情况下创建一个新 FileReader。   
     ③ String(byte[[]b);             将字符数组转换成字符串
     ④ String (byte[]b,int offset,int len ); offset数组开始的索引，len转换的字节数。
   4 FileReader使用步骤
    ① 创建FileReader对象，构造方法绑定数据源
 *  ② 调用read(),开始读文件
 *  ③ close()释放资源       
*/
public class fileReader {
  private static  void FileReaderDemo() throws IOException {	
    
    //1.按照单个字符读
	  FileReader fr =new FileReader(new File("C:\\Users\\12525\\eclipse-workspace\\study\\src\\accessPermission\\IO_Stream\\IO\\FileReader.txt"));
	int len =0;
    System.out.print("读单个字符："); 
    while( (len=fr.read())!=-1) {
    	System.out.print((char)len);  	
    }
    fr.close();
    System.out.println();
    
    //2.读多个字符，即读一个字符数组有效长度
    FileReader fr1 =new FileReader("C:\\Users\\12525\\eclipse-workspace\\study\\src\\accessPermission\\IO_Stream\\IO\\FileReader.txt");
    int len1=0;
    System.out.print("读字符数组："); 
    char[] c=new char[1024];
    while((len1=fr1.read(c)) !=-1) {
    	System.out.println(new String(c,0,len1));
    }
    fr1.close();
    
}
  public static void main(String[] args) throws IOException {
	   FileReaderDemo();
}
}
