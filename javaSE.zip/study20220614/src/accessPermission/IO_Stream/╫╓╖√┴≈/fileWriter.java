package accessPermission.IO_Stream.字符流;

import java.io.FileWriter;
import java.io.IOException;

/* 1.java.io.Writer:写入字符流的抽象类,是输出流最顶层的父类，是以【字符】为单位进行输出
 *   直接子类：FileWriter extends OutputStreamWriter extends writer
 * 2.方法摘要 
	 ① void close()                              关闭此流，但要先刷新它。 
	 ② void flush()                              刷新该流的缓冲。 
	 ③ void write(char[] cbuf, int off, int len) 将字符写入数组的某一部分。
	   void write(char[] cbuf)                   写入字符数组
	 ④ void write(int c)                         写入单个字符。 
	 ⑤ void write(String str, int off, int len)  写入一部分字符串。 
	   void write(String str)                    写入字符串
   3.构造方法
     ① FileWriter(File file)                     根据给定的 File 对象构造一个FileWriter 对象。 
     ② FileWriter(File file, boolean append)     根据给定的 File 对象构造一个FileWriter 对象。
       boolean append: 
       true:创建不会覆盖而是再原文件末尾追加数据
       false:创建一个新文件，覆盖原文件 
     ③ FileWriter(FileDescriptor fd)             构造与某个文件描述符相关联的FileWriter 对象。 
     ④ FileWriter(String fileName)               根据给定的文件名构造一个FileWriter 对象。 
     ⑤ FileWriter(String fileName, boolean append)  根据给定的文件名以及指示是否附加写入数据的 boolean 值来构造 FileWriter 对象。 
     ⑥  Writer append(char c)                    将指定字符添加到此 writer。 
   4.FileWriter使用步骤
     ① 创建FileWriter，绑定路径/目录
     ② 用write()方法将数据从硬盘写道缓冲区
     ③ 用flush()刷新内存缓冲区的数据，刷新到文件中
     ④ 用close()方法释放资源
*/
public class fileWriter {
    private static void FileWriter_Demo()  {
		FileWriter fw = null ;
		try{ 
			fw = new FileWriter("src\\accessPermission\\IO_Stream\\IO\\FileWriter.txt",false);//覆盖写的内容
		    char[]ch = {'b','c'};
	        fw.write("FileWriter已写入！\r\n");//写入字符串并换行
	        fw.write(97); //写入int 字符 a
	        fw.write(10);  //写入换行键
	        fw.write(ch); //写入字符数组
	        fw.append('d');//追加
	        fw.flush();//如果不调用此方法，缓冲区的内容不会写道文件中
		  }
	   catch(IOException IO) {
			  System.out.println(IO);
		  }
       finally {
    	   /*如果路径不对，fw =null ,对象创建失败，close（）会出现空指针异常，所以要增加判断*/
    	   if(fw!=null) {
    	   try {
		     fw.close();
	              } 
           catch (IOException e) {
		         e.printStackTrace();
	                         }
               }
        }
	}
    
    public static void main(String[] args) {
    	 FileWriter_Demo();
	}
}
