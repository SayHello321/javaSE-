package accessPermission.IO_Stream.字集符;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

/* 1.字集符：
 *     ASCII(美国)字符集：ASCII编码
 *     GBK(中文)： GBK编码，2个字节存储
 *     Unicode字符集：UTF-8(通用)编码，3个字节存储；UTF-16；UTF-32                   
 * 2.转换原理
 *    FileInputStream(字节输入流 )->InputStreamReader(字节输入到字符输入桥梁)->FileReader(字符输入流)       解码
 *    FileOutputStream(字节输出流 )<-OutputStreamReader(字符输出到字节输出的桥梁) <-FileWriter(字符输出流)   编码     
 * 3.构造方法、成员方法
 *    OuputStreamReader(OutputStream out); 创建默认字符集的OutputStreamWriter
 *    OutputStreamReader(OutputStream out ,String charsetName); 创建指定字符集的OutputStreamWriter   
 *    InputStreamReader(InputStream in); 创建默认字符集的InputStreamReader
 *    InputStreamReader(InputStream in ,String charsetName);  
 *    String charsetName:默认为UTF-8,不区分大小写，UTF-8/utf-8,GBK/gbk                                                              
 *                  */
public class InOutputStreamReaderWriter {
	
private static void write_utf_8() throws IOException{	
	//1.编码
	OutputStreamWriter osw= new OutputStreamWriter(new FileOutputStream("src\\accessPermission\\IO_Stream\\IO\\write_utf_8.txt",false), "utf-8"); 
	osw.write("字符流到字节流");
	osw.flush();
	osw.close();
	
}
private static void read_utf_8() throws IOException, FileNotFoundException {
	//解码
   InputStreamReader isr = new InputStreamReader(new FileInputStream("src\\accessPermission\\IO_Stream\\IO\\read_utf_8.txt"), "utf-8");
   int len =0;
   
   while((len=isr.read()) !=-1) {	   
	  System.out.print((char)len); 	   
   }
   isr.close();
   System.out.println();
}
public static void main(String[] args) throws IOException {
	write_utf_8();
	 read_utf_8();
}
}
