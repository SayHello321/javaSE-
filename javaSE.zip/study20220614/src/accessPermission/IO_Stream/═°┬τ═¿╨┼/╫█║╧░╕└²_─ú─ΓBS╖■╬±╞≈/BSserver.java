package accessPermission.IO_Stream.网络通信.综合案例_模拟BS服务器;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/*B/S架构即浏览器和服务器的架构
 * 开启服务器后，浏览器输入http://127.0.0.1:8080/web/Git.html*/
public class BSserver {
	private static void BSserverShow() throws IOException{
	 ServerSocket ss =new ServerSocket(8080);
     Socket socket= ss.accept();
     InputStream is = socket.getInputStream();
     BufferedReader br=new BufferedReader(new InputStreamReader(is));
     String firstLine =br.readLine();//读取第一行浏览器地址
	 System.out.println(firstLine);
	      
	 String [] pathArray = firstLine.split(" ");//空格必须打出来
//	 System.out.println("pathArray[1]:"+pathArray[1]);
	 String htmlPath = pathArray[1].substring(1);//把"/"去掉
	 System.out.println("htmlPath:"+htmlPath);
	 
	 //创建本地的字节输入流，绑定尧都区的html路径
//	 File file =new File(htmlPath);
//	 System.out.println(file.getAbsolutePath());
//	 System.out.println(file.exists());
	FileInputStream fis =new FileInputStream(htmlPath);
	 //使用Socket中的方法获取OutputStream对象
	OutputStream os =socket.getOutputStream();
	
	/*下面是HTML后面学到是的固定写法，是HTTP协议响应头*/
	os.write("HTTP/1.1 200 OK\r\n".getBytes());
	os.write("Content-Type:text/html\r\n".getBytes());
    os.write("\r\n".getBytes());//必须写入空行，否则浏览器不解析
    
    //一读一写复制文件，把html文件回写到客户
  byte[]bytes=new byte[1024];
  int len=0;
  while((len=fis.read(bytes) )!=-1) {
 	 os.write(bytes, 0, len);
  }
  
  //释放资源
  fis.close();
  socket.close();
  ss.close();
	}
public static void main(String[] args) throws IOException {
	BSserverShow();
}
}
