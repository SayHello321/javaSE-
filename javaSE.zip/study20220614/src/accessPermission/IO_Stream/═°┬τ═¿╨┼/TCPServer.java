package accessPermission.IO_Stream.网络通信;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/*1.java.net.severSocket:此类实现服务器嵌套字，接受客户的请求，读取客户的数据，给客户端回写数据
 *2.构造方法
 *  serverSocket(int port); 创建绑定特定端口的服务器套接字，服务器必须明确哪个客户端在请求服务器
 *3.成员方法
 *   返回Socket类型  severSocket.accept(); 侦听并接受到此套接字的连接
 *4.服务器端实现步骤
 *  ①创建服务器severSocket对象
 *  ②用severSocket中的方法accept获取Socket对象
 *  ③使用Socket对象getInputStream()获取输入流对象InputStream
 *  ④用网络字节输入流对象InputStream中的read读取客户端发来的数据
 *  ⑤用Socket对象中的方法getOutputStream()获取网络输出流对象
 *  ⑥用网络输出流对象OutputStream write,给客户端回写数据
 *  ⑦释放资源（Socket,socketServer）
 *  注意：必须先启动服务器，等待客户端连结,而且客户端和服务器一般是两个程序，4个I/O流 
 *       read()如果读不到结束标记会进入阻塞状态，用while读时候会进入死循环*/
public class TCPServer {
public static void server() throws IOException {
	ServerSocket ss = new ServerSocket(10);
    Socket socket = ss.accept();
    //2.服务器读取命令，完成第一次握手
    InputStream is=socket.getInputStream();
    byte[]b=new byte[1024];
    int len=is.read(b);
    System.out.println(new String(b,0,len));
    //3.服务器收到命令后回写命令
    OutputStream os = socket.getOutputStream();
    os.write("server to client".getBytes());
    socket.close();
    ss.close();
}
public static void main(String[] args) throws IOException {
	//先启动服务器等待客户端连结，再启动客户端
	server() ;
	
}
}
