package accessPermission.IO_Stream.网络通信;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
/*网络协议种类：
  ① UDP协议:发送端发送数据，接收端不会反馈是否接受到，消耗资源小，效率高，偶尔丢失一两个数据包，用于音频、视频
  ② TCP协议：进行三次握手，，是面向连接的通信协议，保证连接的可靠性，无差错。
  1.java.net.Socket：此类实现实现客户端套接字，包括IP地址和端口号
 *2. 构造方法：
 * Socket(String host,int port); 
 *   host:服务器主机IP地址/名称
 *   port:服务器的端口号
 *3.成员方法：
 *OutputStream getOutputStream(); 返回嵌套字的输出流
 *InputStream  getInputStream();  返回嵌套字的输入流   
 *4.实现步骤
 * ①创建Socket对象，绑服务器及端口
 * ②用Socket对象中的方法getOutputStream()获取网络输出流对象
 * ③用网络输出流对象OutputStream write,给服务器发送据
 * ④使用Socket对象getInputStream()获取输入流对象InputStream
 * ⑤用网络字节输入流对象InputStream中的read读取服务器发来的数据
 * ⑥释放Socket资源 socket.close();
 * 注意：
 *   ① 客户端和服务器必须使用socket的网络流，不能自己创建对象使用
 *   ② 经过三次握手正常启动，开始数据交互，如果没有启动会抛出异常 
 *   ③127.0.0.1是本机地址
 *   */
public class TCPClient {
  public static void client() throws IOException,ConnectException {
	Socket socket =new Socket("127.0.0.1",10);
	//1.客户端发送命令到服务器
    OutputStream os = socket.getOutputStream();
    os.write("client to server".getBytes());
    //4.客户端读取服务器回写的命令完成第二次握手
    InputStream is =socket.getInputStream();
    byte[]b=new byte[1024];
    int len=is.read(b);
    System.out.println(new String(b,0,len));
    socket.close();
}
  public static void main(String[] args) throws IOException {
		
	  client();
		
	}
}
