package accessPermission.IO_Stream.网络通信.URL;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.MalformedInputException;

/*1. URL:(Uniform Resource Locator )统一资源定位器的简称，表示Internet某一资源的地址，可以访问Internet的各种网络资源。
 *   URL格式： 协议名://资源名
 *   协议名包括：http、ftp、file等，资源名包括主机名、端口名、文件名
 * URL类：java.net.URL
 *2. 构造方法：
 *   ① URL(String spec)  throws MalformedURLException
       从 String表示形成一个 URL对象。  
     ② URL(String protocol, String host, int port, String file)   throws MalformedURLException
       创建 URL从指定对象 protocol ， host ， port数，和 file 。  
     ③ URL(String protocol, String host, int port, String file, URLStreamHandler handler)  throws MalformedURLException
       建 URL从指定对象 protocol ， host ， port数， file和 handler 。  
     ④ URL(String protocol, String host, String file)  throws MalformedURLException
       从指定的 protocol名称， host名称和 file名称创建一个URL。  
     ⑤ URL(URL context, String spec)  throws MalformedURLException
       通过在指定的上下文中解析给定的规范来创建一个URL。  
     ⑥ URL(URL context, String spec, URLStreamHandler handler)  throws MalformedURLException
       通过在指定上下文中使用指定的处理程序解析给定规范来创建URL。  
      注意：MalformedURLException抛出以表示发生格式不正确的网址。 在规范字符串中找不到任何合法协议，或者无法解析字符串
 *3.方法摘要
 *  InputStream openStream()     打开与此 URL ，并返回一个 InputStream ，以便从该连接读取。 
 *  String getFile()             获取此 URL的文件名。  
    String getHost()             获取此 URL的主机名（如适用）。  
    String getPath()             获取此 URL的路径部分。  
    int getPort()                获取此 URL的端口号。  
    int getDefaultPort()         获取与此 URL的协议的默认端口号。 
    String getProtocol()         获取此 URL的协议名称。     
  */
public class URL_demo {
   public static void showURL() {
	   URL url =null;
	   try { 
		    url =new URL("http://www.url.org:8080/demo/info/");
		
	} catch (MalformedURLException e) {
		e.printStackTrace();
	}
	   if(url!=null) {
		   System.out.println("协议名： "+url.getProtocol());
		   System.out.println("主机名： "+url.getHost());
		   System.out.println("端口号： "+url.getPort());
		   System.out.println("文件名： "+url.getFile());
		   
	   }
   }
   
   public static void getInputstream() {
	 URL url = null;
	 try {
		url = new URL("http://www.microsoft.com/");
//		InputStreamReader isr =new InputStreamReader(url.openConnection().getInputStream());
//		 int len =0;		   
//		   while((len=isr.read()) !=-1) {	   
//			  System.out.print((char)len); 	   
//		   }
//		   isr.close();
//		   System.out.println();
//	} catch (MalformedURLException e) {
//     	e.printStackTrace();
		BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
		String input;
		while((input=br.readLine())!=null){
			System.out.println(input);
		}
	}catch (IOException f) {
     	f.printStackTrace();
	}
	 
	
	
}
   public static void main(String[] args) {
//	   showURL();
	   getInputstream();
}
}
