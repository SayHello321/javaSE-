package accessPermission.IO_Stream.网络通信.综合案例_文件上传原理;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
/*数据源：客户端上传的数据
 * 服务器硬盘：src\\accessPermission\\IO_Stream\\网络通信\\综合案例_文件上传原理\\server.jpg*/
public class server {
	public static boolean stopServer=false;
	public static int add=0;
	 private static void serverShow() throws IOException{
		 //②step2 读取客户网络输出数据，写入服务端硬盘
		 ServerSocket ss =new ServerSocket(13);
		 //开启线程任务，执行多次上传
		
	     /*为了提高效率，使用多线程，客户端没上传一个文件，开启一个新线程*/
		 new Thread(new Runnable() {
			@Override
			public void run() { //接口中run()没有抛出，所以只能Try..catch
				 try {
				 while(true) {   
						File file =new File("src\\accessPermission\\IO_Stream\\网络通信\\综合案例_文件上传原理");
						if(!file.exists()) {  //判断硬盘目录是否存在，不存在创建一个
							file.mkdirs();
						}
						/*为了多次上传和防止上传数据被重写覆盖，要自定义文件名,格式：日期_毫秒数_随机数(1~100).jpg*/
						String filename =new SimpleDateFormat("yyyyMMdd").format(new Date())+"_"+System.currentTimeMillis()+(new Random().nextInt(100)+1)+".jpg";
						FileOutputStream fos =new FileOutputStream(file+"\\"+filename);
					    
					    Socket socket =ss.accept();
					    InputStream is =socket.getInputStream();
					  
					    byte[]byte1 =new byte[1024*150];	    
					    int len =0;
					    while((len=is.read(byte1))!=-1) {
					    	System.out.println(new String(byte1,0,len));
					        fos.write(byte1,0,len);
					      }
					   					    
					    //③step3将本地硬盘数据读取到网络字节输入流中，供客户端读取
					    OutputStream os =socket.getOutputStream();
					    add++;
					    String tag ="第"+add+"个文件"+"上传成功！";
					    os.write(tag.getBytes());	
					    fos.close();
					    socket.close();
					   
						 }
				 }catch(IOException e) {
					 e.printStackTrace();
				 }
				 
			}
			
		 }).start();
		 
		if(stopServer==true) {			    
	    ss.close();//多次上传服务器不用关闭，一直保持开启监听状态
		}
		}
	 public static void main(String[] args) throws IOException{
		 serverShow();
	}
	 
}
