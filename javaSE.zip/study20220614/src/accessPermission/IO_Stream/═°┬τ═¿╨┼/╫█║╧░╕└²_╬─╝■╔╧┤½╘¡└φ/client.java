package accessPermission.IO_Stream.网络通信.综合案例_文件上传原理;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/* 1. 任务：实现本地文件的网络上传和下载
 * 2. 明确：①数据源：src\accessPermission\IO_Stream\网络通信\综合案例_文件上传原理\网络上传原理.jpg 
 *         ②目的地：服务器
 * 3.实现步骤
 *   ①创建一个本地的字节输入流FileInputStream,绑定要读取的数据
 *   ②创建Socket对象，构造方法中绑定IP地址和端口号
 *   ③使用Socket中的方法getOutputStream获取网络字节输出流OutputStream的对象
 *   ④使用本地字节输入流FileInputStream对象中的方法read读取本地文件
 *   ⑤使用网络字节输出流OutputStream对象中的方法write，把读取到的文件上传到服务器
 *   ⑥使用Socket中的方法getInputStream获取网络字节输入流InputStream对象
 *   ⑦使用网络字节输入流InputStream中对象中的方法read读取服务回写的数据
 *   ⑧释放资源（FileIntputStream,socket）
 *  */
public class client {
 private static void clientShow() throws IOException {
	 //①step1,将本地上传至服务器
	FileInputStream fis =new FileInputStream("src\\accessPermission\\IO_Stream\\网络通信\\综合案例_文件上传原理\\网络上传原理.jpg");
    Socket socket =new Socket("127.0.0.1",13);
    OutputStream os =socket.getOutputStream();
    byte[]byte1 =new byte[1024*150];
    int len =0;
    while((len=fis.read(byte1))!=-1) {   		    
            os.write(byte1,0,len);
    }
    socket.shutdownOutput();//禁用此套接字的输出流
    
    //④step4,从服务器下载，即读取服务器回写的数据
    InputStream is =socket.getInputStream();
    byte[]byte2 =new byte[1024*150];
    int len2 =0; //(char)0==null
    while((len2=is.read(byte2))!=-1) { //注意：此时若读取不到结束标记-1，传给服务器端也没结束标记-1，会进入死循环
    	System.out.println(new String (byte2,0,len2));
    }
    socket.close();
    fis.close();
}
 public static void main(String[] args) throws IOException {
	 clientShow();
}
}
