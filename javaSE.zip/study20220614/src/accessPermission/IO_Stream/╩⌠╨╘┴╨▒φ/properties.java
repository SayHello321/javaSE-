package accessPermission.IO_Stream.属性列表;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Properties;
import java.util.Set;

/*1.java.util.Properties extends Hashtable<k,v> implements Map<k,v>
 *  唯一和IO流相结合的集合，属性列表中的键和值都是字符串，相当于文件处理的一个集合容器
 *2.构造方法
 *  ① Object setProperty(String key, String value)  调用 Hashtable 的方法 put。
 *    String getProperty(String key)                根据建找值，相当于Map中的get(key)
 *    Set<String> stringPropertyNames()    返回此属性列表中的键集，其中该键及其对应值是字符串，如果在主属性列表中未找到同名的键，则还包括默认属性列表中不同的键。 
    ② void store(OutputStream out, String comments)           
       字节流： 不能写中文，以适合使用 load(InputStream) 方法加载到 Properties 表中的格式，将此 Properties 表中的属性列表（键和元素对）写入输出流。 
      void store(Writer writer, String comments)       
       字符流： 可以写中文，以适合使用 load(Reader) 方法的格式，将此 Properties 表中的属性列表（键和元素对）写入输出字符。
       comments:默认Unicode，不能使用中文，否则乱码 ，一般使用""空字符串
    ③  void load(InputStream inStream)    字节流，不能读取中文键值对，从输入流中读取属性列表（键和元素对）。 
       void load(Reader reader)           字符流，能读取中文键值对，按简单的面向行的格式从输入字符流中读取属性列表（键和元素对）。 

 */

public class properties {
private static void property() {
	Properties pro =new Properties();
	pro.setProperty("李华", "15");
	pro.setProperty("李利", "16");
	pro.setProperty("李仙", "16");
	Set<String>set =pro.stringPropertyNames();
	
	for(String key :set) {
	String age =pro.getProperty(key);
    System.out.println(key+":"+age+"岁");
    }
	
}
  private static void store_demo() {
	  //1.用store方法将properties属性列表中的内容按字符流写道文件中，缓冲区-->硬盘
	  Properties pro =new Properties();
		pro.setProperty("李华", "15");
		pro.setProperty("李利", "16");
		pro.setProperty("李仙", "16");
	  try {
		FileWriter fw = new FileWriter("src\\accessPermission\\IO_Stream\\IO\\properties.txt");
		pro.store(fw, "properties demo");
		fw.flush();
		fw.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
}
  private static void load_demo() {
	  //用load方法将硬盘上的内容按字符流读到缓冲区
	  try {
	     Properties pro =new Properties();  
		FileReader fr =new FileReader("src\\accessPermission\\IO_Stream\\IO\\properties.txt");
		
		try {
			pro.load(fr);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//遍历集合Properties看是否读取成功！
		Set<String>set =pro.stringPropertyNames();	
		System.out.println("是否load成功————————————————————————————————————————————————————————————————");
		for(String key :set) {
		String age =pro.getProperty(key);		
	    System.out.println(key+":"+age+"岁");
	    }
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }  
 public static void main(String[] args) {
//	 property();
	 store_demo();
	 load_demo();
}
}
