package accessPermission.IO_Stream.打印流;

import java.io.FileNotFoundException;
import java.io.PrintStream;

/*1.PrintStream:打印流
 * 特点：
 *  ①只负责输出，不负责输入
 *  ②永远不会抛出IOException
 *  ③特有方法print 、println
 *2、构造方法
 *   printStream(File file)          创建指定文件且不带自动刷新的新打印流
 *   printStream(OutputStream out)   创建指定文件且不带自动刷新的新打印流
 *   printStream(String fileName)    创建指定文件且不带自动刷新的新打印流
 *   printStream(String fileName,Sting csn)
 *   printStream(OutputStream out ,boolean autoFlush)                 注释：autoFlush为true，每写入byte数组，都会刷新缓冲区
 *   printStream(OutputStream out,boolean autoFlush,String encoding)  注释：encodingz为字符编码的名称
 *3.继承自父类的方法
 *  void close();
 *  void flush();
 *  void write(int b)
 *  void write(byte[]b);
 *  void (byte[]b,int off ,int len )从指定的字节数组写入len字节，从偏移量off开始输出到此输出流
 *  注意：用父类write写数据，查看数据的时候会查编码表97->a
 *  如果使用自己特有方法print/println方法写数据，数据原样输出97 ->97
 *4.System下方法
 *  static void :System.setOut(PrintStream out)  重新分配标准输出流
 *  static void :System.setIn(InputStream in)  重新分配标准输入流 */
public class printStream {
	public static void demoPrint() throws FileNotFoundException {
		PrintStream ps =new PrintStream("src\\accessPermission\\IO_Stream\\IO\\printStream.txt");
		//继承父类方法
		ps.write(97);
		//自己特有方法
		ps.println();	
		ps.println("M");
		ps.println('f');
		ps.print(6.6);
		ps.close();
	}
	public static void demo_setOut() throws FileNotFoundException {
		System.out.println("控制台输出");
		PrintStream ps =new PrintStream("src\\accessPermission\\IO_Stream\\IO\\打印流目的地.txt");
		System.setOut(ps);
		System.out.println("打印流目的地输出！");
		ps.close();
	}
public static void main(String[] args) throws FileNotFoundException {
	demoPrint();
	demo_setOut();
}
}
