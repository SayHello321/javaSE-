package accessPermission.IO_Stream.序列化流;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/* 1.对象的序列化流：以流的方式writeObject(obj)把对象写入文件中
 * ObjectOutputStream extends OutputStream
 * 构造方法：objectOutputStream(OutputStream,out)
 * 特有成员方法：writeObject(Object obj);将指定对象写入OutputStream流
 * 2.Serializable:序列化接口，序列化和反序列化的所有类都要通过序列化接口标记
 * */
public class objectOutputStream {
private static void writeobject() throws IOException {
	ObjectOutputStream 	oos =new ObjectOutputStream(new FileOutputStream("src\\accessPermission\\IO_Stream\\IO\\序列化写入.txt",false));
    Person person =new Person("张飞", 44); //person已被序列化
    oos.writeObject(person);
    oos.close();
}
public static void main(String[] args) throws IOException {
	writeobject();
}
}
