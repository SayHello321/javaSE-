package accessPermission.IO_Stream.序列化流;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

/*1.反序列化流:把文件中保存的对象，以流的方式读取出来 ，返回Object obj =new Person(name,age)
 *2.成员方法
 *  readObject();
 *3.构造方法 
 *  ObjectInputStream(InputStream in)
 *4关键字transient
 *  被transient修饰的变量不能被序列化，不如将age用transient修饰，反序列化读到的age = 0
 *  static、transient修饰age都为0，只是修饰符的含义和作用不同
 *5.seriaVersionID序列号
 *  反序列化的时候会将Person.class中的序列号和序列化写入.txt的序列号比较，
 *  每次修改类的定义都会生成新的序列号，如果不一样会出现序列化冲突：InvalidClassExceptipon
 *  解决办法：手动定义序列号。Serializable接口规定：必须显示地声明seriaVersionID，必须是静态的（static）,最终final的long字段*/
public class objectInputStream {
private static void readobject() throws IOException, ClassNotFoundException {
	ObjectInputStream ois =new ObjectInputStream(new FileInputStream("src\\accessPermission\\IO_Stream\\IO\\序列化写入.txt"));
    Object obj =ois.readObject();
    ois.close();
    System.out.println(obj);
    Person person =(Person)obj;
    System.out.println("print: name = "+person.getName()+",age = "+person.getAge());
}
public static void main(String[] args) throws ClassNotFoundException, IOException {
	readobject();
}
}
