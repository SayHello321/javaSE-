package accessPermission.IO_Stream.序列化流.序列化集合案例;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import accessPermission.IO_Stream.序列化流.Person;

/*1.序列化集合：
 * 应用场景：当我们想在文件中保存多个对象的时候，可以把多个对象存储到一个集合中，对集合进行序列和反序列
 *2.步骤：
 *  ①定义一个存储Person的ArrayList集合
 *  ②往集合中添加对象
 *  ③创建序列化流ObjectOutputStream，用writeObject(obj)对集合序列化
 *  ④创建反序列化流ObjectInputStream,用readObject()读取文件中保存的集合
 *  ⑤将接手Object类型转换成ArrayList类型，遍历输出 */
public class StreamArray {
	
private static void processing() throws IOException {
	//1.step1
	List<Person>list =new ArrayList<>();
    Collections.addAll(list,new Person("刘备",53),new Person("黄忠",88),new Person("关羽",60));
	ObjectOutputStream oos =new ObjectOutputStream(new FileOutputStream("src\\accessPermission\\IO_Stream\\序列化流\\序列化集合案例\\序列化集合写入.txt",false));
    ObjectInputStream  ois =new ObjectInputStream(new FileInputStream("src\\accessPermission\\IO_Stream\\序列化流\\序列化集合案例\\序列化集合写入.txt"));
    oos.writeObject(list); 
    
    try {
		Object obj =ois.readObject();
		ArrayList<Person>personList=( ArrayList<Person>)obj;//向下转型
		System.out.println(personList);
		System.out.println(personList.get(0));
//		for(Person p :personList) {
//			System.out.println(p);
//		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    ois.close();
    oos.close();
//    int len =0;
//     while((len=ois.read()) !=-1) {
//    	 
//     }
}
public static void main(String[] args) throws IOException {
	processing();
}
}
