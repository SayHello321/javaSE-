package accessPermission.IO_Stream.excel;

import java.util.ArrayList;
import java.util.List;

public class excelTest {
public static List<User>getUsers(){
	List<User>users =new ArrayList<>();
	users.add(new User("张飞","123456"));
	users.add(new User("刘备","444444"));
	users.add(new User("孙尚香","555555"));
   return users;
}
public static void main(String[] args) {
	//1.创建workbook对应excel文件
//	HSSFWorkbook workbook = new HSSFWorkbook();

}
}
