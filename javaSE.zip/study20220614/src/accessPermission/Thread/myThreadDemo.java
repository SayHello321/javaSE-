package accessPermission.Thread;

import java.util.Iterator;

/*1.创建Thread子类
 *2.在thread子类中重写run方法，设置线程任务
 *3.创建线程类子类对象
 *4.调用Thread类中的方法start方法，开启新的线程，执行run方法 ，void start();使用该线程开始执行，虚拟机调用该线程的run方法
 *  结果是：两个线程并发地执行，当前线程（main线程）和新线程
 *  注意：多次调用一个线程是非法的，线程结束后不能重新启动，JAVA属于抢占式调度，优先级高的先调用，同等优先级随机调用
 *   
 * */
public class myThreadDemo {
	
 public static void main(String[] args) throws InterruptedException {
	myThread th = new myThread();
	//调用start方法，开启新线程
	th.start();//此方法之前调用run()；方法是单线程的
	th.run();
	for (int i = 0; i <15; i++) {
		System.out.println("main"+i);
		Thread.sleep(1000);//模拟秒表，1000毫秒，即1秒
	} 
//	th.stop();//此方法本身就是线程不安全	
//	myThread th1 = new myThread();//多线程之间互不影响，一个线程出了问题，其他线程不受影响
//	th1.start();
//	for (int i = 0; i < 10; i++) {
//		System.out.println("mutiThread"+i);	
//            }
	
	
 }
}
