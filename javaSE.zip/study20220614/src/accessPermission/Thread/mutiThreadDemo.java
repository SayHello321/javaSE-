package accessPermission.Thread;
/*开启多线程有两种方法：
 * ① 通过继承Thread类，重写run 方法，调用实现类的对象开启线程
 * ② 通过实现Runable类，通过实现类重写run方法，调用实现类的对象开启线程
 * */
public class mutiThreadDemo {

	 public static void main(String[] args) {
		 
		 //方法① ： 通过继承Thread类
		 
		 //线程名称 main,Thread-0,Thread-1,Thread-2 ，四个线程抢夺cpu资源
		 //创建子类对象
	/*	multiThread th0 =new multiThread();
		th0.setName("线程1");
		th0.start();
		
		multiThread th1 =new multiThread();
		th1.setName("线程2");
		th1.start();
		
		multiThread th2 =new multiThread();
		th2.setName("线程3");
		th2.start();
		
		//当前线程
		 System.out.println("当前线程："+Thread.currentThread().getName());	
	*/	 
		 
		//***************************************************************************************8
		 
		 //方法②：通过实现Runable类
		 //Runnableimpements类中run方法的线程
		 //1.创建对象
		Runnableimpements RR = new Runnableimpements();
		//2.创建Thread对象，将Runnableimpements类对象传参进去
		Thread thr =new Thread(RR);//好处是可以传不同的接口实现类
		//3.调用Thread的对象，开启线程
		thr.start();
		//主线程：
		 for (int j = 0; j < 15; j++) {
	    	 System.out.println(Thread.currentThread().getName()+"-->"+j);	
		}
		
		//***********************************************************************************************
		 
		//方法①-1：匿名内部类创建Thread类对象创建线程
//		 new Thread() {
//			@Override
//			public void run() {
//				 for (int j = 0; j < 15; j++) {
//			    	 System.out.println("匿名内部类线程-->"+j);	
//				}		
//			}
//			
//		 }.start();
		
		//***************************************************************************************************** 
		 
		//方法②-2 匿名局部内部类实现Runnable接口
//		 Runnable r= new Runnable() {   //r是实现类对象，不是接口
//			@Override
//			public void run() {
//					/*
//					 * for (int j = 0; j < 15; j++) { System.out.println("匿名局部内部类线程-->"+j); }
//					 */	
//				
//				Runnableimpements kk =new 	Runnableimpements();
//				kk.saleTicket();
//			}			 
//		 };
//		 new Thread(r).start();
		 
		//*****************************************************************************************************
	}
}
