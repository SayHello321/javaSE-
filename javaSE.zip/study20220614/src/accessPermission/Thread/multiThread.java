package accessPermission.Thread;

public class multiThread extends Thread{
    
	
	public multiThread() {
		super();
		// TODO Auto-generated constructor stub
	}

	public multiThread(String name) {
		super(name); //带参，把参数给父类
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
    //1.获取线程名称
	
//	  String name =getName(); 
//	  System.out.println(name);
	 
	//2.获取线程名称	
//		Thread t =Thread.currentThread();
//		System.out.println(t);//Thread[Thread-0,5,main]
//		String ThreadName = t.getName();
//		System.out.println(ThreadName); //Thread-0
	//3.链式编程
	 	 System.out.println(Thread.currentThread().getName());	
	}

	 
	
}
