package accessPermission.Thread.等待唤醒案例;
/*
 * 注意：
 * ①消费者和生产者的任务必须在synchronized同步代码块里，等待和唤醒只能执行一个线程
 * ② 锁对象保证唯一这里是obj
 * ③只有锁对象才能使用wait()和notify()方法*/
import java.util.Scanner;
public class waitAndNotify {
	//1.建立Object对象
	static Object obj =new Object();
	private static int i=1;
	private final static int CUSTOMERNUMBER=10;
	static void customerThread() {
		//2.创建消费者线程
		new Thread () {
        //重写Thread类中的run方法
			@Override
			public void run() {	
				
				while(i<=CUSTOMERNUMBER) { //这里i<=10表示一天接客10个
				synchronized (obj) {
					
					System.out.println("提示：请输入您要的包子种类、数量，比如输入[韭菜馅：2个，豆腐馅1个]，按ehter键结束！");
					Scanner sr= new Scanner(System.in);
					String s = sr.next();
					
				System.out.println("第"+i+"号顾客说：老板我要"+s);				
				try {					
					obj.wait(); //线程锁进入无限等待模式
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				   }
				System.out.println("第"+i+"号顾客说：谢谢老板，准备开吃啦！");				
				System.out.println("第"+i+"号顾客离开,欢迎下次光临！");
				i++;
				System.out.println("***************************************************************************");
			  }
			 }	
			}			 	
		}.start();
	}
	
	static void producerThread() {
		//3.创建生产者线程
	  new Thread () {
		
        //重写Thread类中的run方法,设置线程任务
			@Override
			public void run() {	
					
				while(i<=CUSTOMERNUMBER) { //这里i<=10表示一天接客10个
				try {
					Thread.sleep(1*1000); //花1秒时间做包子
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {}
				
				synchronized (obj) {
			    if(i+1>=11) {
			    	System.out.println(i+"老板说：先生您好，包子做好了，请您享用！");	
			    	try {
			    		System.out.println("第"+i+"号顾客说：谢谢老板，准备开吃啦！");				
						System.out.println("第"+i+"号顾客离开,欢迎下次光临！");
						System.out.println("");
			    		System.out.println("-------------------本店已打烊！---------------");
						obj.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			    	
			    }else {
				System.out.println("老板说：先生您好，包子做好了，请您享用！");
			    obj.notify(); //线程锁进入唤醒模式，叫顾客吃包子					
			      }
				 }
		     	}
			}	
		}.start();
	}
	public static void main(String[] args) {
		customerThread(); 
		producerThread();
	
		
		
	}
  
	
	
}
