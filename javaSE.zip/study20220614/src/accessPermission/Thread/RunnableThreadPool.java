package accessPermission.Thread;

public class RunnableThreadPool implements Runnable {
	
public RunnableThreadPool() {
		super();
		// TODO Auto-generated constructor stub
	}

@Override
public void run() {
	 System.out.println("线程"+Thread.currentThread().getName()+"正在执行任务！");	
	
}
}
