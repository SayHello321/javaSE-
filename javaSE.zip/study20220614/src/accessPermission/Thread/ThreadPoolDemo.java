package accessPermission.Thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/*1.Executors:线程池的工厂类，用来生产线程池
 *   静态方法 static ExcutorService newFixedThreadPool(int nThreads);
 *   int nThreads : 设置固定的线程数
 *   ExecutorService(接口类)：返回的是ExcutorService接口的实现类对象 
 *2.ExecutorService：java.util.concurrent..ExcutorService线程池接口，获取线程，自动调用线程start方法，执行任务
 *  submit(Runnable task);  提交一个 Runnable 任务用于执行，并返回一个表示该任务的 Future。
 *  shutdown();         启动一次顺序关闭，执行以前提交的任务，但不接受新任务,不推荐使用。
 *3.使用步骤 
 *  ①使用Executors类下的静态方法生产一个固定线程数的线程池，用ExecutorService接口接受
 *  ②创建Runnable接口的实现类，重写run方法，设置线程任务
 *  ③利用ExecutorService的submit(实现类)方法传递线程任务
 *  ④用ExecutorService的shutdown()方法关闭线程池，一般不推荐此操作。
*/
public class ThreadPoolDemo {

	public static void main(String[] args) {
		/*两个线程执行3个任务，等到前两个执行任务完毕后会把空闲的线程随机分配给第三个任务*/
		
		//1.生产一个指定数量的线程池
		ExecutorService es =Executors.newFixedThreadPool(2);
		//2.提交Runnable任务用于执行
		es.submit(new RunnableThreadPool()); //任务1
		es.submit(new RunnableThreadPool()); //任务2
		es.submit(new RunnableThreadPool()); //任务3
		//关闭线程池
		es.shutdown();
	}
}
