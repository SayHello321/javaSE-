package accessPermission.Thread;
/* 解决线程安全问题的三种方法：
 * 1.同步代码块，解决线程安全问题
 * 格式：    synchronrized(锁对象){
 *           可能出现的线程安全问题代码块（不能共享的数据）    }  
 *2.自己也可以定义同步方法：可以用同步数据类型方法也可以在方法体内同步代码块，对象是实现类对象this
 *格式：public synchronized void 方法名称（）{ 代码块} 或者
 *    public void 方法名(){
 *    synchronized(this){ 代码块}
 *    }
 *   具体格式如下： 
 *    public static void 方法名(){
 *    synchronized(Runnableimpements.class){ 代码块}
 *    }
 * 3.lock接口：java.util.concurrent.locks
 *   lock L= new ReentrantLock();
 *   L.lock();
 *   可能出现线程安全的代码块；
 *   L.unlock();          */
public class Runnableimpements implements Runnable{
	
	private int ticket=100;
    
	public Runnableimpements() {
		super();
		// TODO Auto-generated constructor stub
	}
    Object obj =new Object();
    
    
	@Override
	public void run() {
		
//		synchronized (obj) {
//		 //下面是可能线程不安全的代码块
//	     for (int j = 0; j < 15; j++) {                                    
//	    	 System.out.println(Thread.currentThread().getName()+"-->"+j);	
//		  }
//	     
//		}
		 saleTicket();
		
	}
	
	//将saleTicket()方法在run方法中调用实现run方法的重写
	public synchronized void saleTicket(){ 
		//死循环，一卖票动作一直执行
		while(true) {
			//判断票存在
			if(ticket>0) {
				//让线程睡10ms
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("正在卖第"+ticket+"票");
				ticket--;
			}
		}
	}
	
}
