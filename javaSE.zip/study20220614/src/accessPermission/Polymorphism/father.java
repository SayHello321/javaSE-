package accessPermission.Polymorphism;

public class father {
public void method() {
	System.out.println("父类方法");
}
public void methodFather() {
	System.out.println("父类特有方法");
}
}
