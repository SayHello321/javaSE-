package accessPermission.Polymorphism.USB多态应用;

public class computer {

	public static void powerOff() {
		System.out.println("电脑关机！");
	}
	
	public static void powerOn() {
		System.out.println("电脑开机！");
	}
	
	public static void useDevice(USB usb) {
		usb.open();
		
		//用了多态，向下转型
		if(usb instanceof mouse) {
			mouse mouse = (mouse)usb;
			mouse.click();
		}else if(usb instanceof keyboard) { //不能直接else{}，除了鼠标、键盘可能有别的设备也可能调用这个方法
			keyboard keyboard =(keyboard)usb;
			keyboard.type();
		}
		
		usb.close();
	}
}
