package accessPermission.Polymorphism.USB多态应用;

public interface USB {

	
	 public abstract void close();
	 public abstract void open();
}
