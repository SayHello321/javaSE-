package accessPermission.Polymorphism.USB多态应用;
//键盘就是一个USB设备
public class keyboard implements USB {

	public static void type() {
		System.out.println("键盘输入______________________________");
	}

	@Override
	public void close() {
		System.out.println("关闭键盘!");
		
	}
	
	@Override
	public void open() {
		System.out.println("打开键盘!");
		
	}
	
	

}
