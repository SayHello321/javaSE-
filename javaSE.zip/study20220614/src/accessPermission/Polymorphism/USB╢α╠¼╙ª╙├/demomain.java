package accessPermission.Polymorphism.USB多态应用;

public class demomain {
    public static void change(double num) {
    	System.out.println(num);
    }
	public static void main(String[] args) {
		computer computer= new computer();
		computer.powerOn();//电脑开机		
		
//		mouse mouse = new mouse();//先提供一个鼠标供电脑使用
		USB usbMouse=new mouse();//多态，向上转型
		computer.useDevice(usbMouse);//通过USB接口使用鼠标
		
//		keyboard keyboard=new keyboard();//没有使用多态，相当于向上转型语句 USB usbkeyboard=new keyboaard();
//		computer.useDevice(keyboard); //正确，使用多态，发生了向上转型
		computer.useDevice(new keyboard());//使用匿名对象也是可以的，向上转型
		
		computer.powerOff();//电脑关机	
		System.out.println("================================");
		change(10);   // int-->double ，正确
		change(10.0); //double-->double，正确
		int x = 20;
		change(x);//正确
	}
	 
}
