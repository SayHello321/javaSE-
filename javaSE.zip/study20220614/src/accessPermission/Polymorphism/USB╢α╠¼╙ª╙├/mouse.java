package accessPermission.Polymorphism.USB多态应用;
//鼠标就是一个USB设备
public class mouse implements USB{
	
	
	public static void click () {
		System.out.println("鼠标点击________________________________");
	}
	@Override
	public  void close() {
		System.out.println("关闭鼠标!");
	}
	
	@Override

	public  void open() {
		System.out.println("打开鼠标!");
	}
}
