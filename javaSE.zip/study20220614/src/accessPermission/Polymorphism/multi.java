package accessPermission.Polymorphism;
/*1.多态（polymorphism）:父类引用指向子类对象  
 *2.向上转型 格式：父类名称 对象名 =new 子类名称（）；
 *       或   接口名称 对象名 =new 实现类名称（）；
 *   访问特点成员变量new 的谁访问谁，没有向上找，向上转换更大范围类型 比如int-->double；
 *   成员变量：编译看左边，运行看左边；
 *   成员方法：编译看左边，运行看右边；
 *3.向下转型 格式 子类名称 对象名 =（子类名称）父类对象名
 *  含义：将父类对象，【还原】成本来的子类对象； 
 *  注意事项：必须保证对象创建的时候本来就是子类；，不然就会报错； 
 * */
public class multi {
public static void main(String[] args) {
	//向上转型，一定是安全的，弊端是不能访问子类特有方法
	System.out.println("向上转型如下: ========================================");
	father fath=new son1();
	fath.method();
	fath.methodFather();
	/*father中没有成员方法methodSon,所以报错；
    fath.methodSon();
    */
	
	System.out.println("向下转型如下: ========================================");
	//向下转型，还原动作
	son1 s1=(son1)fath;//父类本来是son1
	s1.methodSon1();
//	son2 s2=(son2)fath;//父类本来是son1，非要还原成son2,错误
//	s2.methodSon2();
}
}
