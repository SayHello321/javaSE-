package accessPermission.Polymorphism;
/*  instanceof: 转型，判断父类引用的哪个子类
 *  格式： 对象 instanceof 类名称
 *  这将会得到一个boolean值，判断前面对象能不能作为后面类的实例；
 * */
public class demoInstanceof {
	
	public static void giveMeASon(father fa) {
		if(fa instanceof son2) {
			son2 s2 =(son2)fa;
			s2.methodSon2();//子类2特有方法
		}
		if(fa instanceof son1) {
			son1 s1 =(son1)fa;
			s1.methodSon1();//子类1特有方法
		}	
	}
	
   public static void main(String[] args) {
	//向上转型
	father fa=new son1();//本来是son1，所以向下只能调用methodson1();
	fa.method();//子类1方法
	
	//向下转型，做判断fa 是否可以作为son2的实例对象，判断fa本来是不是son2；
	if(fa instanceof son2) {
		son2 s2 =(son2)fa;
		s2.methodSon2();//子类2特有方法
	}
	if(fa instanceof son1) {
		son1 s1 =(son1)fa;
		s1.methodSon1();//子类1特有方法
	}
	
	giveMeASon(new son2());//没有特别要求转换哪个子类，随便传一个子类向下转 
}
   
}
