package accessPermission.Polymorphism;

public class son1 extends father{
	public void method() {
		System.out.println("子类1方法");
	}
	public void methodSon1() {
		System.out.println("子类1特有方法");
	}
}
