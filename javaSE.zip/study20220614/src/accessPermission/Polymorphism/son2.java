package accessPermission.Polymorphism;

public class son2 extends father {

	@Override
	public void method() {
		System.out.println("子类2方法 ");
	}
	public void methodSon2() {
		System.out.println("子类2特有方法");
	}
}
