package AIC;
import accessPermission.Math.FLASH_method;
public class audio_read {
	
	static String GPIOA9_capture="11111111111111111111111111111111111111111111111111111111111111111001001110100000010010100011001000001100100110011010011001101000001100100000110010000001001010110000100101000010101100001001010000101000011010100101101011000110100111110010000001001011011010100000110010000111101000001100100000110010100011001000001100100110001010011000101000001100100000110010101110101000000100101011110010000001001000001100100001111010010011001000011100100000110010010000101000001100100100001010000011001001000010101011000010010100001010000110101001011010110001101001111100100000010011111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111100100111010000001001010001100100000110010011001101001100110110000011001000101100100000010010101100001001010000101101101010000011001000011110100000110010000011001010001100100000110010011000101001100010100000110100010110010101110101000000100101011110010000001001000001100100001111010000011001010001100100110110010011000101001001100100001110010010011001000011100101011000010010100001010000110101001011010110001101001111100100000010011111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111101011000010010100001010000110101001011010110001101001111100100000010010010011101000000100101000110010000011001001100110100110011010000011001000011100100000010010101100001001010000101101101010000011001000011110100000110010000011001010001100100000110010011000101001100010100000110010000111001010111011100000100101011110010000001001000001100100001111010000011001010001100100110110010100000101000001100101000110010110011001000101100101011000010010100001010000110101001011010110001101001111100100000010011111111111";
	static String[] GPIOA9_CAP=GPIOA9_capture.split("");
	static int[] GPIOA9_array=stringToIntArray(GPIOA9_CAP);
	
	public static  int[] audioRead(int []array){
	    int[] arrayB=new int[142];
        int i=0;
        int k=0;

        while(i<array.length)
        {
            if((array[i]==0)&&(array[i+9]==1))
            {
                if(k<arrayB.length)
                {
                    arrayB[k]=((array[i+1]*1+array[i+2]*2+array[i+3]*4+array[i+4]*8+array[i+5]*16+array[i+6]*32+array[i+7]*64+array[i+8]*128));//&0xFF
                
                }
                i+=10;
                k++;

            }
            else
            {
                i++;
            }
        }
        for(int h =0;h<arrayB.length;h++) {
        if(arrayB[h]==48&&arrayB[h+1]==49&&arrayB[h+2]==54&&arrayB[h+3]==65){
       	 System.out.println("h是: "+h); }
       }
        
        byte d0_1=(byte)arrayB[35],d0_2=(byte)arrayB[36],d0_3=(byte)arrayB[37],d0_4=(byte)arrayB[38],d0_5=(byte)arrayB[39],d0_6=(byte)arrayB[40],d0_7=(byte)arrayB[41],d0_8=(byte)arrayB[42];
        byte d1_1=(byte)arrayB[77],d1_2=(byte)arrayB[78],d1_3=(byte)arrayB[79],d1_4=(byte)arrayB[80],d1_5=(byte)arrayB[81],d1_6=(byte)arrayB[82],d1_7=(byte)arrayB[83],d1_8=(byte)arrayB[84];
        byte d2_1=(byte)arrayB[126],d2_2=(byte)arrayB[127],d2_3=(byte)arrayB[128],d2_4=(byte)arrayB[129],d2_5=(byte)arrayB[130],d2_6=(byte)arrayB[131],d2_7=(byte)arrayB[132],d2_8=(byte)arrayB[133];
        //        System.out.println("d0_1: "+d0_1);
        byte[] bytes= {d0_1,d0_2,d0_3,d0_4,d0_5,d0_6,d0_7,d0_8,32,d1_1,d1_2,d1_3,d1_4,d1_5,d1_6,d1_7,d1_8,32,d2_1,d2_2,d2_3,d2_4,d2_5,d2_6,d2_7,d2_8};
        String DATA=new String(bytes);
        System.out.println("DATA0~DATA2: "+DATA);
        //打印十进制
        for(int j=0;j<arrayB.length;j++)
        {

            if(j==0){
                System.out.print("captureData_deci: ["+arrayB[0]+",");
            }
            else if(j==arrayB.length-1){
                System.out.println(arrayB[arrayB.length-1]+"]");
            }
            else{
                System.out.print(arrayB[j]+",");
            }

        }
        //打印16进制
        for(int j=0;j<arrayB.length;j++){
			   if(j==0){
				   System.out.print("captureData_hex: ["+Integer.toHexString(arrayB[0])+",");
			   }
				else if(j==arrayB.length-1){
					System.out.println(Integer.toHexString(arrayB[arrayB.length-1])+"]");
				}
				else{
					System.out.print(Integer.toHexString(arrayB[j])+",");
				}
				
				}
         return arrayB;

   }
	public static void main(String[]args){
		int[] demoarray =new int[]{53,54,55};
		int number1_1=demoarray[0]<<4;
        int number1_2=demoarray[0]&0xf;
        System.out.println(number1_1);
        System.out.println(number1_2);
		FLASH_method fl=new FLASH_method();
		fl.printArray(GPIOA9_array);
		audioRead(GPIOA9_array);
		
		
	}
	public static int [] stringToIntArray(String[] arr) {//字符串数组转成int数组
		 int[] array=new int[arr.length];
		 for(int i=0;i<arr.length;i++) {
			 array[i]=Integer.parseInt(arr[i]);
		 }
		 return array;
	 }
}
