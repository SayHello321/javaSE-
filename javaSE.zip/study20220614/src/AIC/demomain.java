package AIC;

public class demomain {
public static void main(String[] args) {
	int a=229;
	int b=(a>>2)&0xf;
	System.out.println(b);
	System.out.println(0x1ff-1);
}
}
