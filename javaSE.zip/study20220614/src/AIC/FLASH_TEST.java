/*package common.testMethod;
import java.util.Map;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupPattern;
import xoc.dta.ParameterGroup;
import xoc.dta.ParameterGroupCollection;
import xoc.dta.TestMethod;
import xoc.dta.annotations.In;
import xoc.dta.datatypes.MultiSiteDouble;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDigInOutCaptureResults;
import xoc.dta.resultaccess.datatypes.BitSequence.BitOrder;
import xoc.dta.resultaccess.datatypes.MultiSiteBitSequence;
import xoc.dta.testdescriptor.IParametricTestDescriptor;
public class FLASH_TEST extends TestMethod {

   private  static int[] arrayB=new int[102];
   private  static int repeat=10000;
   private  static long[] arrayA =new long [repeat];
    public IMeasurement measurement;
   // public IMeasurement measurement2;
//    public IParametricTestDescriptor testDescriptor;
//    public IFunctionalTestDescriptor testDescriptor1;
    public Long someParameter;
    public Double someParameter1;
    public String someParameter2;
    public Boolean someParameter3;

    public IParametricTestDescriptor ptd_flash;


    int xMode=1;
    double samplingFreq=4.8e7;

    public class freqGroup extends ParameterGroup{
        public IParametricTestDescriptor ptd_freq;
    }

    public ParameterGroupCollection<freqGroup> freqGroupCollection=new ParameterGroupCollection<freqGroup>();

    @In public String tmuActionName ="";
    @In public int oversamplFac=1;

    @In
    public String mainSpec;
    public String vector="11111";
    @In
    public String pattern_name;

    public IParametricTestDescriptor ptdFreqSigPA0;

    @Override
    public void setup() {
        IDeviceSetup ds1 = DeviceSetupFactory.createInstance();
       // IDeviceSetup ds2 = DeviceSetupFactory.createInstance();

//        double period=1/samplingFreq;


        ds1.addDigInOut("GPIOA9").result().capture().setEnabled(true);
       // ISetupWavetable wvt=ds1.addDigInOut("PA0").addWavetable(1);
      //  wvt.addStateCharDescription('C', DriveAction.FNZ,ReceiveAction.C);
       // wvt.addStateCharDescription('X', DriveAction.FNZ,ReceiveAction.X);
      //  ds1.addDigInOut("PA0").timing().setPeriodDeviation(period).setD1("0 ns").setR1("0 ns");


        ISetupPattern pattern_GPIOA9=ds1.createPattern(1, "GPIOA9");
        pattern_GPIOA9.genVecBegin(repeat);
        for (int i=0;i<xMode;i++) {
            pattern_GPIOA9.addVector("C");

        }

        pattern_GPIOA9.genVecEnd();
       //ISetupPattern pat_001=ds1.getPatternRef("common.pattern.dump_rc48m_freq");
        //pat_001.replaceVectors(0, "00110"+vector+"001111","00110"+vector+"001111","00110"+vector+"001111","00110"+vector+"001111");


        ds1.importSpec(mainSpec);
        ds1.sequentialBegin();
     //   ds1.patternCall(pattern_name);
        ds1.parallelBegin();
        ds1.patternCall("common.pattern.FLASH");
        ds1.patternCall(pattern_GPIOA9);
        ds1.parallelEnd();
        ds1.sequentialEnd();
        measurement.setSetups(ds1);


//        SDIO sdio = ProtocolAccess.getProtocolInterface(SDIO.class);
//        sdio.setSignals("PA0", "PA2", "PA3", "PA1", "PA4", "PA5");
//        sdio.createSetup(ds1, measurement);
//        sdio.transactionSequenceBegin();
//        {
//
//
//            sdio.sdio_read();
//
//            }
//
//
//           // spi.Spi_read(03, "reg33");
//
//        sdio.transactionSequenceEnd();
    //    ISetupPattern pat_002=ds2.getPatternRef("common.pattern.dump_rc48m_freq");
//        pat_002.replaceVectors(0, "00110"+vector+"001111","00110"+vector+"001111","00110"+vector+"001111","00110"+vector+"001111");

        // TODO Auto-generated method stub
       // ds2.addDigInOut("PA18").result().capture().setEnabled(true);
      //  ds2.importSpec(mainSpec);
      //  ds2.parallelBegin();
      //  ds2.patternCall("common.pattern.dump_rc48m_freq");
      //  ds2.patternCall(pat);
       // ds2.parallelEnd();
        //measurement2.setSetups(ds2);

    }

//    @Override
//    public void update() {
//
//        ptdFreqSigPA0.setHighLimit(4.9e7).setLowLimit(4.7e7).setTestText("FrequencyPA18");
//
//    }

    @Override
    public void execute() {

        measurement.execute();
        IDigInOutCaptureResults digCapture=measurement.digInOut("GPIOA9").preserveCaptureResults();
        Map<String,MultiSiteBitSequence> bitsOfAllSignals=digCapture.getSerialBitsAsBitSequence();
        println("GPIOA9_bitsCapture: "+bitsOfAllSignals);
        println();
        releaseTester();

        String TSName = context.getTestSuiteName();
        println("============================================================================");
        println("=====================" + TSName + " results======================");
        println("============================================================================");


        MultiSiteDouble flash_evluate= new MultiSiteDouble();


        //*******************************************************************************************
        for (int site : context.getActiveSites()) {

        arrayA = bitsOfAllSignals.get("GPIOA9").get(site).toLongArray(1, BitOrder.LEFT_TO_RIGHT);
        int[] array1=seek(arrayA); //capture data is arrayB
//        int[] arrayChange=LongToIntArray(arrayA);
         printArray(array1);//print arrayA
//        printArray(array1);//print arrayB
       //*********************************************************************************************
        int[]arrayGPIOA9_address1 = {0x72,0x20,0x34,0x30,0x30,0x36,0x30,0x30,0x31,0x34,0x0D,0x0A,0x5B,0x30,0x78,0x34,0x30,0x30,0x36,0x30,0x30,0x31,//pattern1_expecte_address
                0x34,0x5D,0x20,0x3D,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x38,0x32,0x31,0x0D,0x0A,0x0D,0x0A,0x4F,0x4B,0x0D,0x0A,0x42,0x6F,0x6F,0x74,0x20,0x3E,

         0x72,0x20,0x34,0x30,0x30,0x35,0x41,0x35,0x43,0x20,0x0D,0x0A,0x5B,0x30,0x78,0x30,0x34,0x30,0x30,0x35,0x41,0x35,0x43,0x5D,0x20,0x3D,  //pattern2_expected_address
         0x20,0x30,0x78,0x46,0x46,0x46,0x46,0x46,0x46,0x46,0x46,0x0D,0x0A,0x0D,0x0A,0x4F,0x4B,0x0D,0x0A,0x42,0x6F,0x6F,0x74,0x20,0x3E};
//        int couter=0;
//        for(int i =0;i<arrayA.length;){//arrayA.length
//        if(arrayA[i]==0&&couter<arrayB.length){//&&arrayA[i+2]==0     &&arrayA[i+47]==1
//        do {
//            arrayB[couter]=(int)((arrayA[i+7]*1+arrayA[i+12]*2+arrayA[i+17]*4+arrayA[i+22]*8+arrayA[i+27]*16+arrayA[i+32]*32+arrayA[i+37]*64+arrayA[i+42]*128));//&0xFF
//           // println("arrayB["+couter+"] = "+Integer.toHexString(arrayB[couter]));
//            couter+=1;
//            i+=50;
//        }while(couter<arrayB.length);
//
//        }
//        else {
//            i++;
//        }
//         }
//        for(int j=0;j<arrayB.length;j++) {
//            if(j==0) {
//                print("site: "+site+" ["+Integer.toHexString(arrayB[0])+",");
//            }
//            else if(j==arrayB.length-1) {
//                println(Integer.toHexString(arrayB[arrayB.length-1])+"]");
//            }
//            else {
//                print(Integer.toHexString(arrayB[j])+",");
//            }
//        }


        boolean judgement=judge(array1,arrayGPIOA9_address1);
        double flash_test_result;
         if(judgement==true) {
             flash_test_result=1;
             println("flash pass");}

         else {
             flash_test_result=0;
             println("flash fail");
         }

         flash_evluate.set(site,flash_test_result) ;

        }

        ptd_flash.evaluate(flash_evluate);

    }

//    public static  int[] seek(long []array){
//       int[] arrayB=new int[102];
//       int couter=0;
//       for(int i =0;i<array.length;){
//       if(array[i]==0&&array[i+2]==0&&array[i+47]==1&&couter<102){
//       do {
//           arrayB[couter]=(int)((array[i+7]*1+array[i+12]*2+array[i+17]*4+array[i+22]*8+array[i+27]*16+array[i+32]*32+array[i+37]*64+array[i+42]*128));//&0xFF
//          // println("arrayB["+couter+"] = "+Integer.toHexString(arrayB[couter]));
//           
//       }while(couter<102);
//           couter+=1;
//           i+=50;
//       }
//       else {
//           i++;
//       }
//        }
//         return arrayB;
//
//   }


   public static  int[] seek(long []array){
         int[] arrayB=new int[102];
         int i=0;
         int k=0;

         while(i<array.length)
         {
             if((array[i]==0)&&(array[i+1]==0)&&(array[i+2]==0))
             {
                 if(k<arrayB.length)
                 {
                     arrayB[k]=(int)((array[i+7]*1+array[i+12]*2+array[i+17]*4+array[i+22]*8+array[i+27]*16+array[i+32]*32+array[i+37]*64+array[i+42]*128));//&0xFF

                 }
                 i+=50;
                 k++;

             }
             else
             {
                 i++;
             }
         }
         for(int j=0;j<arrayB.length;j++)
         {

             if(j==0){
                 System.out.print("site "+" captureData: ["+arrayB[0]+",");
             }
             else if(j==arrayB.length-1){
                 System.out.println(arrayB[arrayB.length-1]+"]");
             }
             else{
                 System.out.print(arrayB[j]+",");
             }

         }

          return arrayB;

    }
      public static boolean judge(int[]array1,int[]array2){
           boolean boo=false;
           for(int i=0;i<102;i++) {

               if(array1[i]==array2[i]) {
                   boo=true;
               }
               else {
                   boo=false;
               }
          }
           return boo;
        }

      public static void printArray(int[] array) {

          for(int j=0;j<array.length;j++) {
              if(j==0) {
                  print("captureData[site_n]: ["+Integer.toHexString(array[0])+",");
              }
              else if(j==array.length-1) {
                  println(Integer.toHexString(array[array.length-1])+"]");
              }
              else {
                  print(Integer.toHexString(array[j])+",");
              }
          }

      }

      public static int[] LongToIntArray(long[]array) {
          int[]temp=new int[array.length];
          for(int i=0;i<array.length;i++) {
              temp[i]=(int)array[i];

          }

         return temp;
      }

}
*/