package AIC;

public class FLASH {
	public static  int[] findArray(int []array){
        int[] arrayB=new int[102];
        int i=0;
        int k=0;

        while(i<array.length)
        {
            if((array[i]==0)&&(array[i+1]==0)&&(array[i+2]==0))
            {
                if(k<arrayB.length)
                {
                    arrayB[k]=(int)((array[i+7]*1+array[i+12]*2+array[i+17]*4+array[i+22]*8+array[i+27]*16+array[i+32]*32+array[i+37]*64+array[i+42]*128));//&0xFF

                }
                i+=50;
                k++;

            }
            else
            {
                i++;
            }
        }
        for(int j=0;j<arrayB.length;j++)
        {

            if(j==0){
                System.out.print("site "+" captureData: ["+arrayB[0]+",");
            }
            else if(j==arrayB.length-1){
                System.out.println(arrayB[arrayB.length-1]+"]");
            }
            else{
                System.out.print(arrayB[j]+",");
            }

        }

         return arrayB;

   }
	public static void main(String[]args){
		
	}
}
