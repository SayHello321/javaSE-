
public class demo1 {
void eat() {
	System.out.println("banana");
}
void jump(){
	System.out.println("jump");
}
}
